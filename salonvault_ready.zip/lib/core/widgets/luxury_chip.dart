import 'package:flutter/material.dart';

/// A chip styled according to the luxury design language.
///
/// When [selected] is true the chip is filled with the primary
/// colour; otherwise only a border is visible. It uses a subtle
/// animation for state changes. Use [onSelected] to toggle
/// selection.
class LuxuryChip extends StatefulWidget {
  /// The string label of the chip.  Ignored if [child] is provided.
  final String? label;

  /// A custom child widget to display inside the chip.  If provided
  /// this overrides [label].  Many call sites previously passed a
  /// [Text] widget directly which is incompatible with a String
  /// parameter; allowing a widget here preserves those use cases.
  final Widget? child;

  /// Whether the chip is currently selected.
  final bool selected;

  /// Called when the user taps the chip to toggle its selected state.
  final ValueChanged<bool> onSelected;

  const LuxuryChip({
    this.label,
    this.child,
    required this.selected,
    required this.onSelected,
    Key? key,
  })  : assert(label != null || child != null,
            'Either label or child must be provided'),
        super(key: key);

  @override
  State<LuxuryChip> createState() => _LuxuryChipState();
}

class _LuxuryChipState extends State<LuxuryChip> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.colorScheme.primary;
    final onPrimary = theme.colorScheme.onPrimary;
    return MouseRegion(
      onEnter: (_) => setState(() => _hovering = true),
      onExit: (_) => setState(() => _hovering = false),
      child: AnimatedScale(
        scale: _hovering ? 1.05 : 1.0,
        duration: const Duration(milliseconds: 150),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
          decoration: BoxDecoration(
            color: widget.selected ? primary : Colors.transparent,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: primary, width: 1.0),
            boxShadow: _hovering
                ? [
                    BoxShadow(
                      color: primary.withOpacity(0.3),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    )
                  ]
                : [],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: InkWell(
            borderRadius: BorderRadius.circular(24),
            onTap: () => widget.onSelected(!widget.selected),
            child: widget.child ??
                Text(
                  widget.label!,
                  style: theme.textTheme.bodyMedium?.copyWith(
                        color: widget.selected ? onPrimary : primary,
                        fontWeight: FontWeight.w500,
                      ),
                ),
          ),
        ),
      ),
    );
  }
}