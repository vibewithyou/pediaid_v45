import 'package:flutter/material.dart';

/// A reusable card widget following the luxury design language.
///
/// It supports an optional leading icon or image, a title and an optional
/// subtitle. The card has rounded corners, a subtle shadow and uses the
/// surface colour of the current theme.
class LuxuryCard extends StatefulWidget {
  /// Optional leading widget, typically an icon or image.
  final Widget? leading;

  /// The title of the card.  Must be provided if [child] is null.
  final String? title;

  /// Optional subtitle displayed beneath [title].  Ignored when [child] is set.
  final String? subtitle;

  /// Optional trailing widget aligned to the end of the row.
  final Widget? trailing;

  /// A fully custom child to render inside the card.  When [child] is
  /// provided the title, subtitle, leading and trailing fields are
  /// ignored, allowing the card to be used as a general container.
  final Widget? child;

  /// Optional margin to apply around the card.  This can be used in
  /// parent layouts to separate cards without wrapping them in
  /// additional padding widgets.
  final EdgeInsetsGeometry? margin;

  /// Callback invoked when the card is tapped.  If null, the card
  /// will not respond to taps.
  final VoidCallback? onTap;

  const LuxuryCard({
    this.leading,
    this.title,
    this.subtitle,
    this.trailing,
    this.child,
    this.margin,
    this.onTap,
    super.key,
  })  : assert(child != null || title != null,
            'Either child or title must be provided');

  @override
  State<LuxuryCard> createState() => _LuxuryCardState();
}

class _LuxuryCardState extends State<LuxuryCard> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    // Build the core card widget (without outer margin).
    Widget buildCoreCard() {
      return Semantics(
        button: widget.onTap != null,
        // Provide a descriptive label combining the title and subtitle if present.
        label: widget.child != null
            ? null
            : (widget.subtitle != null
                ? '${widget.title}, ${widget.subtitle}'
                : widget.title ?? ''),
        child: MouseRegion(
          onEnter: (_) => setState(() => _hovering = true),
          onExit: (_) => setState(() => _hovering = false),
          child: AnimatedScale(
            scale: _hovering ? 1.02 : 1.0,
            duration: const Duration(milliseconds: 150),
            child: InkWell(
              onTap: widget.onTap,
              child: Container(
                decoration: BoxDecoration(
                  color: theme.cardTheme.color,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: theme.brightness == Brightness.dark
                          ? theme.colorScheme.primary.withOpacity(_hovering ? 0.3 : 0.2)
                          : Colors.black.withOpacity(_hovering ? 0.25 : 0.15),
                      blurRadius: _hovering ? 10 : 6,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(16),
                child: widget.child ??
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (widget.leading != null) ...[
                          Padding(
                            padding: const EdgeInsets.only(right: 16),
                            child: SizedBox(
                                width: 32,
                                height: 32,
                                child: widget.leading),
                          ),
                        ],
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (widget.title != null)
                                Text(
                                  widget.title!,
                                  style: theme.textTheme.headlineMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              if (widget.subtitle != null) ...[
                                const SizedBox(height: 4),
                                Text(
                                  widget.subtitle!,
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ],
                            ],
                          ),
                        ),
                        if (widget.trailing != null) ...[
                          Padding(
                            padding: const EdgeInsets.only(left: 16.0),
                            child: widget.trailing!,
                          ),
                        ],
                      ],
                    ),
              ),
            ),
          ),
        ),
      );
    }

    final Widget card = buildCoreCard();
    // Apply optional margin if provided.
    if (widget.margin != null) {
      return Padding(
        padding: widget.margin!,
        child: card,
      );
    }
    return card;
  }
}