import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';

/// Defines the visual style of a [LuxuryButton].
///
/// The [filled] variant renders a solid button with the primary colour
/// from the current theme, while the [outlined] variant draws only
/// the outline and uses a transparent background. Prior to adding this
/// enum, the widget exposed a boolean `filled` parameter.  The enum
/// allows for clearer semantics and room for future extension.
enum LuxuryButtonVariant { filled, outlined }

/// A custom button that reflects the luxury styling of SalonManager.
///
/// This widget renders a rounded rectangle with a gold border. When
/// [filled] is true the button is filled with the primary colour (gold
/// in dark mode, champagne in light mode). Otherwise only the outline
/// is coloured and the background is transparent. The text colour is
/// chosen automatically based on the [filled] state.
class LuxuryButton extends StatefulWidget {
  /// The primary text label of the button.  Ignored if [child] is provided.
  final String? label;

  /// An alternative name for [label].  Many call sites previously used
  /// the parameter name `text`.  To preserve API compatibility, both
  /// `label` and `text` map to the same underlying value.  If both
  /// are provided, `label` takes precedence.
  final String? text;

  /// A custom child widget to display inside the button.  If provided
  /// then the value of [label] or [text] is ignored.  This is useful
  /// for including icons, loaders, or more complex layouts.
  final Widget? child;

  /// The callback invoked when the button is tapped.  If null, the
  /// button will be disabled and rendered with reduced opacity.
  final VoidCallback? onPressed;

  /// The stylistic variant of the button.  Defaults to
  /// [LuxuryButtonVariant.filled].
  final LuxuryButtonVariant variant;

  /// The internal padding of the button’s content.
  final EdgeInsetsGeometry padding;

  const LuxuryButton({
    this.label,
    this.text,
    this.child,
    required this.onPressed,
    this.variant = LuxuryButtonVariant.filled,
    this.padding = const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
    super.key,
  })  : assert(label != null || text != null || child != null,
            'Either label, text or child must be provided');

  @override
  State<LuxuryButton> createState() => _LuxuryButtonState();
}

class _LuxuryButtonState extends State<LuxuryButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.colorScheme.primary;
    final onPrimary = theme.colorScheme.onPrimary;
    final bool isFilled = widget.variant == LuxuryButtonVariant.filled;
    // Determine which label to display.  The `label` field takes
    // precedence over `text` for backwards compatibility.  If neither
    // is provided, fall back to a generic description.
    final String? displayLabel = widget.label ?? widget.text;
    // Wrap the entire button in a Semantics widget so that assistive
    // technologies can properly announce it as a button. The label
    // defaults to the provided text when [label] is not null. If a
    // custom child is supplied instead of a label, fall back to a
    // generic description. This improves accessibility for screen
    // readers and other ATs.
    return Semantics(
      button: true,
      enabled: widget.onPressed != null,
      label: displayLabel ?? 'action button',
      child: MouseRegion(
        onEnter: (_) => setState(() => _hovering = true),
        onExit: (_) => setState(() => _hovering = false),
        child: AnimatedScale(
          scale: _hovering ? 1.02 : 1.0,
          duration: const Duration(milliseconds: 150),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            curve: Curves.easeOut,
            decoration: BoxDecoration(
              color: isFilled ? primary : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: primary, width: 1.5),
              boxShadow: _hovering
                  ? [
                      BoxShadow(
                        color: primary.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ]
                  : [],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: widget.onPressed,
                child: Container(
                  padding: widget.padding,
                  alignment: Alignment.center,
                  child: widget.child ??
                      (displayLabel != null
                          ? Text(
                              displayLabel,
                              style: theme.textTheme.labelLarge?.copyWith(
                                color: isFilled ? onPrimary : primary,
                                letterSpacing: 1.1,
                                fontWeight: FontWeight.w600,
                              ),
                            )
                          : const SizedBox()),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}