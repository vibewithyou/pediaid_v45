# SalonManager - Architecture

## Überblick
Multi-Salon PWA-first Flutter Platform mit RBAC, modernem Schwarz/Gold-Design und sauberer Architektur.

## Tech Stack
- **State Management**: Riverpod
- **Routing**: go_router (Guards: Auth, Role)
- **HTTP Client**: Dio (vorbereitet, Mock-Daten)
- **Map**: flutter_map + Leaflet
- **Design**: Custom Theme (Schwarz #000000, Gold #FFD700), Dark/Light Mode

## Architektur
```
lib/
├── core/
│   ├── theme/          # Schwarz/Gold Theme, Dark/Light Mode
│   ├── routing/        # go_router Config + Guards
│   ├── env/            # Environment Config
│   └── errors/         # Result<T,Failure> Pattern
├── services/
│   └── api/            # Dio Client + Interceptors (Mock)
├── models/             # Data Models (User, Salon, Service, Booking, etc.)
└── features/
    ├── auth/           # Login, Register, PasswordReset
    ├── rbac/           # Role-based Access Control
    ├── salon_profile/  # SelectSalon, SalonHome (Info, Services, Team)
    ├── search_map/     # MapSearch mit Filtern
    ├── booking/        # 5-Step Wizard (Service, Stylist, Slot, Notes, Confirm)
    ├── loyalty/        # Punkte-Card + Historie
    └── pos/            # POS Checkout Stub
```

## Features (MVP)

### 1. Authentication & Onboarding
- Login, Register, Password Reset (UI + Mock Service)
- Role-aware Redirect nach Login

### 2. Salon Selection & Profile
- SelectSalon: Suche + Liste
- SalonHome: Hero Header, Tabs (Info, Services, Team, Aktionen)

### 3. Map Search
- MapSearch: flutter_map mit List-Drawer
- Filter: Entfernung, Preis, Bewertungen, freie Termine

### 4. Booking Wizard (5 Steps)
- Step 1: Service wählen
- Step 2: Stylist optional + Dauer/Preis
- Step 3: Slot-Auswahl (Kalender)
- Step 4: Notiz + bis zu 5 Bilder (Validation)
- Step 5: Review & Bestätigung (Mock)

### 5. Loyalty & Profile
- MyProfile: Name, Kontakt
- Loyalty: Punkte-Card + Historie

### 6. POS (Stub)
- POSCheckout: Warenkorb, Summe, Steuern (19%/7%)
- Button: Generate Invoice (Mock)

### 7. Legal
- Impressum, Datenschutz (statische Platzhalter)

## Roles
- `owner` (Platform-Owner)
- `platform_admin`
- `salon_owner`
- `salon_manager`
- `stylist`
- `customer`

## Data Models
- User (id, name, email, role, created_at, updated_at)
- Salon (id, name, address, lat, lng, rating, images, created_at, updated_at)
- Service (id, salon_id, name, duration, price, description)
- Stylist (id, salon_id, user_id, name, avatar, specialties)
- Booking (id, user_id, salon_id, service_id, stylist_id?, slot, notes, images, status)
- LoyaltyTransaction (id, user_id, salon_id, points, description, date)

## Implementation Steps
1. ✅ Dependencies (Riverpod, go_router, Dio, flutter_map, shared_preferences)
2. ✅ Core: Theme (Schwarz/Gold, Dark/Light)
3. ✅ Core: Routing (go_router + Guards)
4. ✅ Core: Env + Error Handling
5. ✅ Services: Dio API Client (Mock)
6. ✅ Models: All Data Models
7. ✅ Auth Feature: Login, Register, PasswordReset
8. ✅ RBAC: Role Guards
9. ✅ Salon Profile: SelectSalon, SalonHome
10. ✅ Search Map: MapSearch mit Filtern
11. ✅ Booking: 5-Step Wizard
12. ✅ Loyalty: Profile + Punkte
13. ✅ POS: Checkout Stub
14. ✅ Legal: Impressum, Datenschutz
15. ✅ Mock Data: Salons, Services, Stylists, Slots
16. ✅ Testing: Routing Guards, Theme Provider
17. ✅ Compile & Fix

## Design Principles
- Schwarz/Gold Palette (#000000, #FFD700)
- Großzügige Abstände (16-32px)
- Elegante Schriftarten (Playfair Display, Lato)
- Responsive (Web + Mobile)
- Kein Material Design
- Custom Components (Buttons, Inputs, Cards)

## TODO (Backend Integration)
- [ ] Laravel API Endpoints `/api/v1/*`
- [ ] Auth: JWT Token Management
- [ ] Salons: CRUD + Search
- [ ] Bookings: Create, Update, Cancel
- [ ] Loyalty: Points Calculation
- [ ] POS: Invoice Generation (GoBD)
- [ ] Image Upload (S3/Local)
- [ ] Push Notifications
- [ ] Real-time Slot Availability
