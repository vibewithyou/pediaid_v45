import 'package:salonvault/core/errors/failures.dart';
import 'package:salonvault/core/errors/result.dart';
import 'package:salonvault/models/loyalty_transaction.dart';

class LoyaltyService {
  // TODO: Replace with actual API calls when Laravel backend is ready
  // Endpoint: GET /api/v1/loyalty/balance?user_id={userId}
  // Endpoint: GET /api/v1/loyalty/transactions?user_id={userId}
  // Endpoint: POST /api/v1/loyalty/redeem

  static final _mockTransactions = [
    LoyaltyTransaction(
      id: '1',
      userId: '1',
      salonId: '1',
      points: 50,
      description: 'Booking completed: Haircut & Styling',
      date: DateTime.now().subtract(const Duration(days: 7)),
      createdAt: DateTime.now().subtract(const Duration(days: 7)),
      updatedAt: DateTime.now().subtract(const Duration(days: 7)),
    ),
    LoyaltyTransaction(
      id: '2',
      userId: '1',
      salonId: '1',
      points: 120,
      description: 'Booking completed: Hair Coloring',
      date: DateTime.now().subtract(const Duration(days: 30)),
      createdAt: DateTime.now().subtract(const Duration(days: 30)),
      updatedAt: DateTime.now().subtract(const Duration(days: 30)),
    ),
    LoyaltyTransaction(
      id: '3',
      userId: '1',
      salonId: '2',
      points: -50,
      description: 'Redeemed: 10 EUR discount',
      date: DateTime.now().subtract(const Duration(days: 45)),
      createdAt: DateTime.now().subtract(const Duration(days: 45)),
      updatedAt: DateTime.now().subtract(const Duration(days: 45)),
    ),
  ];

  Future<Result<int>> getUserPoints(String userId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final total = _mockTransactions
          .where((t) => t.userId == userId)
          .fold(0, (sum, t) => sum + t.points);
      return Result.success(total);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to fetch points: $e'));
    }
  }

  Future<Result<List<LoyaltyTransaction>>> getUserTransactions(String userId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 400));
      final transactions = _mockTransactions
          .where((t) => t.userId == userId)
          .toList()
        ..sort((a, b) => b.date.compareTo(a.date));
      return Result.success(transactions);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to fetch transactions: $e'));
    }
  }

  Future<Result<void>> redeemPoints(String userId, int points, String description) async {
    try {
      await Future.delayed(const Duration(milliseconds: 500));
      final transaction = LoyaltyTransaction(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        userId: userId,
        salonId: '1',
        points: -points,
        description: description,
        date: DateTime.now(),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      _mockTransactions.add(transaction);
      return Result.success(null);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to redeem points: $e'));
    }
  }
}
