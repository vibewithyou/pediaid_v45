import 'package:shared_preferences/shared_preferences.dart';
import 'package:salonvault/core/errors/failures.dart';
import 'package:salonvault/core/errors/result.dart';
import 'package:salonvault/models/user.dart';

class AuthService {
  static const _keyUserId = 'user_id';
  static const _keyUserEmail = 'user_email';

  // TODO: Replace with actual API authentication when Laravel backend is ready
  // Endpoint: POST /api/v1/auth/login
  // Endpoint: POST /api/v1/auth/register
  // Endpoint: POST /api/v1/auth/logout
  // Endpoint: POST /api/v1/auth/refresh
  // Endpoint: POST /api/v1/auth/password/reset

  Future<Result<User>> login(String email, String password) async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      
      // Mock user based on email
      final user = User(
        id: '1',
        name: 'Demo User',
        email: email,
        role: email.contains('admin') ? UserRole.platformAdmin : UserRole.customer,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyUserId, user.id);
      await prefs.setString(_keyUserEmail, user.email);

      return Result.success(user);
    } catch (e) {
      return Result.failure(AuthFailure('Login failed: $e'));
    }
  }

  Future<Result<User>> register(String name, String email, String password) async {
    try {
      await Future.delayed(const Duration(seconds: 1));

      final user = User(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: name,
        email: email,
        role: UserRole.customer,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyUserId, user.id);
      await prefs.setString(_keyUserEmail, user.email);

      return Result.success(user);
    } catch (e) {
      return Result.failure(AuthFailure('Registration failed: $e'));
    }
  }

  Future<Result<void>> resetPassword(String email) async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      return Result.success(null);
    } catch (e) {
      return Result.failure(AuthFailure('Password reset failed: $e'));
    }
  }

  Future<Result<void>> logout() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_keyUserId);
      await prefs.remove(_keyUserEmail);
      return Result.success(null);
    } catch (e) {
      return Result.failure(AuthFailure('Logout failed: $e'));
    }
  }

  Future<Result<User?>> getCurrentUser() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getString(_keyUserId);
      final userEmail = prefs.getString(_keyUserEmail);

      if (userId == null || userEmail == null) {
        return Result.success(null);
      }

      final user = User(
        id: userId,
        name: 'Demo User',
        email: userEmail,
        role: userEmail.contains('admin') ? UserRole.platformAdmin : UserRole.customer,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      return Result.success(user);
    } catch (e) {
      return Result.failure(AuthFailure('Failed to get current user: $e'));
    }
  }

  Future<bool> isAuthenticated() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey(_keyUserId);
  }
}
