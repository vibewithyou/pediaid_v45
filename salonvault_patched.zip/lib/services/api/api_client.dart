import 'package:dio/dio.dart';
import 'package:salonvault/core/env/env.dart';

class ApiClient {
  late final Dio _dio;

  ApiClient() {
    _dio = Dio(BaseOptions(
      baseUrl: Env.apiBaseUrl,
      connectTimeout: Duration(milliseconds: int.parse(Env.apiTimeout)),
      receiveTimeout: Duration(milliseconds: int.parse(Env.apiTimeout)),
      headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
    ));

    _dio.interceptors.add(LogInterceptor(
      requestBody: !Env.isProduction,
      responseBody: !Env.isProduction,
    ));

    // TODO: Add AuthInterceptor for JWT Token Management
    // _dio.interceptors.add(AuthInterceptor());
  }

  Future<Response> get(String path, {Map<String, dynamic>? queryParameters}) async {
    // TODO: Replace with actual API call when Laravel backend is ready
    throw UnimplementedError('API not implemented yet. Use mock data.');
  }

  Future<Response> post(String path, {dynamic data}) async {
    // TODO: Replace with actual API call when Laravel backend is ready
    throw UnimplementedError('API not implemented yet. Use mock data.');
  }

  Future<Response> put(String path, {dynamic data}) async {
    // TODO: Replace with actual API call when Laravel backend is ready
    throw UnimplementedError('API not implemented yet. Use mock data.');
  }

  Future<Response> delete(String path) async {
    // TODO: Replace with actual API call when Laravel backend is ready
    throw UnimplementedError('API not implemented yet. Use mock data.');
  }
}
