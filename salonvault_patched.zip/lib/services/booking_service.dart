import 'package:salonvault/core/errors/failures.dart';
import 'package:salonvault/core/errors/result.dart';
import 'package:salonvault/models/booking.dart';
import 'package:salonvault/models/reschedule_option.dart';

class BookingService {
  // TODO: Replace with actual API calls when Laravel backend is ready
  // Endpoint: GET /api/v1/bookings
  // Endpoint: POST /api/v1/bookings
  // Endpoint: PUT /api/v1/bookings/{id}
  // Endpoint: DELETE /api/v1/bookings/{id}
  // Endpoint: GET /api/v1/salons/{salonId}/slots?date={date}&service_id={serviceId}

  final List<Booking> _mockBookings = [];

  // Utility for tests and seeding
  List<Booking> debugAll() => _mockBookings;

  Future<Result<List<DateTime>>> getAvailableSlots(
    String salonId,
    String serviceId,
    DateTime date,
  ) async {
    try {
      await Future.delayed(const Duration(milliseconds: 500));
      
      final slots = <DateTime>[];
      final startHour = 9;
      final endHour = 18;
      
      for (var hour = startHour; hour < endHour; hour++) {
        slots.add(DateTime(date.year, date.month, date.day, hour, 0));
        slots.add(DateTime(date.year, date.month, date.day, hour, 30));
      }
      
      return Result.success(slots);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to fetch slots: $e'));
    }
  }

  Future<Result<Booking>> createBooking({
    required String userId,
    required String salonId,
    required String serviceId,
    String? stylistId,
    required DateTime slot,
    String? notes,
    List<String>? images,
  }) async {
    try {
      await Future.delayed(const Duration(milliseconds: 800));

      final booking = Booking(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        userId: userId,
        salonId: salonId,
        serviceId: serviceId,
        stylistId: stylistId,
        slot: slot,
        notes: notes,
        images: images ?? [],
        // New bookings start as pending until stylist confirms
        status: BookingStatus.pending,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      _mockBookings.add(booking);
      return Result.success(booking);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to create booking: $e'));
    }
  }

  Future<Result<List<Booking>>> getUserBookings(String userId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 400));
      final bookings = _mockBookings.where((b) => b.userId == userId).toList();
      return Result.success(bookings);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to fetch bookings: $e'));
    }
  }

  Future<Result<void>> cancelBooking(String bookingId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final index = _mockBookings.indexWhere((b) => b.id == bookingId);
      if (index != -1) {
        _mockBookings[index] = _mockBookings[index].copyWith(
          status: BookingStatus.cancelled,
          updatedAt: DateTime.now(),
        );
      }
      return Result.success(null);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to cancel booking: $e'));
    }
  }

  // New mock methods for management flows
  // TODO(API): PUT /api/v1/bookings/{id}/confirm
  Future<Result<Booking>> confirmBooking(String bookingId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final idx = _mockBookings.indexWhere((b) => b.id == bookingId);
      if (idx == -1) throw Exception('Booking not found');
      final updated = _mockBookings[idx].copyWith(
        status: BookingStatus.confirmed,
        updatedAt: DateTime.now(),
      );
      _mockBookings[idx] = updated;
      return Result.success(updated);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to confirm booking: $e'));
    }
  }

  // TODO(API): PUT /api/v1/bookings/{id}/decline
  Future<Result<Booking>> declineBooking(String bookingId, {String? reason}) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final idx = _mockBookings.indexWhere((b) => b.id == bookingId);
      if (idx == -1) throw Exception('Booking not found');
      final updated = _mockBookings[idx].copyWith(
        status: BookingStatus.declined,
        updatedAt: DateTime.now(),
        notes: [if (_mockBookings[idx].notes != null) _mockBookings[idx].notes!, if (reason != null) 'Declined: $reason'].join('\n').trim(),
      );
      _mockBookings[idx] = updated;
      return Result.success(updated);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to decline booking: $e'));
    }
  }

  // Fetch reschedule options, e.g., next 3 free half-hour slots around original time
  // TODO(API): GET /api/v1/bookings/{id}/reschedule-options
  Future<Result<List<RescheduleOption>>> getRescheduleOptions(String bookingId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 250));
      final b = _mockBookings.firstWhere((e) => e.id == bookingId);
      final base = b.slot;
      final options = <RescheduleOption>[
        RescheduleOption(slot: base.add(const Duration(days: 1)), label: 'Morgen, gleiche Uhrzeit'),
        RescheduleOption(slot: DateTime(base.year, base.month, base.day, 10, 0).add(const Duration(days: 2)), label: 'Übermorgen 10:00'),
        RescheduleOption(slot: base.add(const Duration(days: 3, hours: 2)), label: '+3 Tage, +2h'),
      ];
      return Result.success(options);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to get options: $e'));
    }
  }

  // Suggest a reschedule; marks booking as rescheduleRequested with proposed slot
  // TODO(API): PUT /api/v1/bookings/{id}/reschedule
  Future<Result<Booking>> suggestReschedule(String bookingId, DateTime newSlot) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final idx = _mockBookings.indexWhere((b) => b.id == bookingId);
      if (idx == -1) throw Exception('Booking not found');
      final updated = _mockBookings[idx].copyWith(
        status: BookingStatus.rescheduleRequested,
        updatedAt: DateTime.now(),
        notes: [if (_mockBookings[idx].notes != null) _mockBookings[idx].notes!, 'Reschedule suggested: ${newSlot.toIso8601String()}'].join('\n').trim(),
      );
      _mockBookings[idx] = updated;
      return Result.success(updated);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to reschedule: $e'));
    }
  }

  // Accept a reschedule by setting new slot and confirming
  // TODO(API): PUT /api/v1/bookings/{id}/apply-reschedule
  Future<Result<Booking>> applyReschedule(String bookingId, DateTime newSlot) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final idx = _mockBookings.indexWhere((b) => b.id == bookingId);
      if (idx == -1) throw Exception('Booking not found');
      final updated = _mockBookings[idx].copyWith(
        slot: newSlot,
        status: BookingStatus.confirmed,
        updatedAt: DateTime.now(),
      );
      _mockBookings[idx] = updated;
      return Result.success(updated);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to apply reschedule: $e'));
    }
  }

  // Attach media refs to booking images
  // TODO(API): POST /api/v1/bookings/{id}/media
  Future<Result<Booking>> attachMedia(String bookingId, List<String> mediaRefs) async {
    try {
      await Future.delayed(const Duration(milliseconds: 200));
      final idx = _mockBookings.indexWhere((b) => b.id == bookingId);
      if (idx == -1) throw Exception('Booking not found');
      final current = _mockBookings[idx];
      final updated = current.copyWith(
        images: [...current.images, ...mediaRefs].toSet().toList(),
        updatedAt: DateTime.now(),
      );
      _mockBookings[idx] = updated;
      return Result.success(updated);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to attach media: $e'));
    }
  }

  // For stylist queue views
  // TODO(API): GET /api/v1/stylists/{id}/bookings?status=pending|confirmed|rescheduleRequested
  Future<Result<List<Booking>>> getStylistBookings(String stylistId, {BookingStatus? status}) async {
    try {
      await Future.delayed(const Duration(milliseconds: 250));
      var list = _mockBookings.where((b) => b.stylistId == stylistId).toList();
      if (status != null) list = list.where((b) => b.status == status).toList();
      return Result.success(list);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to fetch stylist bookings: $e'));
    }
  }

  Future<Result<Booking>> getBooking(String bookingId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 150));
      final b = _mockBookings.firstWhere((e) => e.id == bookingId);
      return Result.success(b);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to get booking: $e'));
    }
  }
}
