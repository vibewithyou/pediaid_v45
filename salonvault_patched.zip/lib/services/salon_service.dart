import 'package:salonvault/core/errors/failures.dart';
import 'package:salonvault/core/errors/result.dart';
import 'package:salonvault/models/salon.dart';
import 'package:salonvault/models/service.dart';
import 'package:salonvault/models/stylist.dart';

class SalonServiceAPI {
  // TODO: Replace with actual API calls when Laravel backend is ready
  // Endpoint: GET /api/v1/salons
  // Endpoint: GET /api/v1/salons/{id}
  // Endpoint: GET /api/v1/salons/search?q={query}&lat={lat}&lng={lng}&radius={radius}

  static final _mockSalons = [
    Salon(
      id: '1',
      name: 'Golden Scissors',
      address: 'Kurfürstendamm 123, Berlin',
      lat: 52.5045,
      lng: 13.2911,
      rating: 4.8,
      reviewCount: 245,
      description: 'Premium hair salon in the heart of Berlin',
      images: ['https://picsum.photos/400/300?random=1'],
      phone: '+49 30 12345678',
      email: 'info@goldenscissors.de',
      openingHours: {
        'Monday': '09:00 - 19:00',
        'Tuesday': '09:00 - 19:00',
        'Wednesday': '09:00 - 19:00',
        'Thursday': '09:00 - 20:00',
        'Friday': '09:00 - 20:00',
        'Saturday': '10:00 - 18:00',
        'Sunday': 'Closed',
      },
      createdAt: DateTime.now().subtract(const Duration(days: 365)),
      updatedAt: DateTime.now(),
    ),
    Salon(
      id: '2',
      name: 'Luxury Hair Lounge',
      address: 'Friedrichstraße 45, Berlin',
      lat: 52.5200,
      lng: 13.3889,
      rating: 4.6,
      reviewCount: 189,
      description: 'Modern salon with experienced stylists',
      images: ['https://picsum.photos/400/300?random=2'],
      phone: '+49 30 98765432',
      email: 'contact@luxuryhair.de',
      openingHours: {
        'Monday': '10:00 - 20:00',
        'Tuesday': '10:00 - 20:00',
        'Wednesday': '10:00 - 20:00',
        'Thursday': '10:00 - 21:00',
        'Friday': '10:00 - 21:00',
        'Saturday': '09:00 - 19:00',
        'Sunday': '11:00 - 17:00',
      },
      createdAt: DateTime.now().subtract(const Duration(days: 300)),
      updatedAt: DateTime.now(),
    ),
    Salon(
      id: '3',
      name: 'Elegance Studio',
      address: 'Alexanderplatz 1, Berlin',
      lat: 52.5219,
      lng: 13.4132,
      rating: 4.9,
      reviewCount: 312,
      description: 'Award-winning salon for all your beauty needs',
      images: ['https://picsum.photos/400/300?random=3'],
      phone: '+49 30 55555555',
      email: 'hello@elegance.de',
      openingHours: {
        'Monday': '08:00 - 18:00',
        'Tuesday': '08:00 - 18:00',
        'Wednesday': '08:00 - 18:00',
        'Thursday': '08:00 - 19:00',
        'Friday': '08:00 - 19:00',
        'Saturday': '09:00 - 17:00',
        'Sunday': 'Closed',
      },
      createdAt: DateTime.now().subtract(const Duration(days: 500)),
      updatedAt: DateTime.now(),
    ),
  ];

  static final _mockServices = [
    SalonService(
      id: '1',
      salonId: '1',
      name: 'Haircut & Styling',
      description: 'Professional haircut with styling',
      durationMinutes: 60,
      price: 65.0,
      category: 'Hair',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    SalonService(
      id: '2',
      salonId: '1',
      name: 'Hair Coloring',
      description: 'Full hair coloring service',
      durationMinutes: 120,
      price: 120.0,
      category: 'Hair',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    SalonService(
      id: '3',
      salonId: '1',
      name: 'Beard Trim',
      description: 'Professional beard trimming',
      durationMinutes: 30,
      price: 25.0,
      category: 'Beard',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    SalonService(
      id: '4',
      salonId: '2',
      name: 'Premium Cut',
      description: 'Luxury haircut experience',
      durationMinutes: 75,
      price: 85.0,
      category: 'Hair',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    SalonService(
      id: '5',
      salonId: '3',
      name: 'Balayage',
      description: 'Modern balayage coloring technique',
      durationMinutes: 150,
      price: 180.0,
      category: 'Hair',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
  ];

  static final _mockStylists = [
    Stylist(
      id: '1',
      salonId: '1',
      userId: '10',
      name: 'Maria Schmidt',
      avatar: 'https://i.pravatar.cc/150?img=1',
      bio: 'Senior stylist with 10+ years experience',
      specialties: ['Haircuts', 'Coloring', 'Styling'],
      rating: 4.9,
      reviewCount: 156,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    Stylist(
      id: '2',
      salonId: '1',
      userId: '11',
      name: 'Thomas Müller',
      avatar: 'https://i.pravatar.cc/150?img=2',
      bio: 'Expert in modern cuts and beard styling',
      specialties: ['Haircuts', 'Beard'],
      rating: 4.7,
      reviewCount: 98,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    Stylist(
      id: '3',
      salonId: '2',
      userId: '12',
      name: 'Anna Weber',
      avatar: 'https://i.pravatar.cc/150?img=3',
      bio: 'Specialist in coloring techniques',
      specialties: ['Coloring', 'Balayage'],
      rating: 4.8,
      reviewCount: 123,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
  ];

  Future<Result<List<Salon>>> getAllSalons() async {
    try {
      await Future.delayed(const Duration(milliseconds: 500));
      return Result.success(_mockSalons);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to fetch salons: $e'));
    }
  }

  Future<Result<Salon>> getSalonById(String id) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final salon = _mockSalons.firstWhere((s) => s.id == id);
      return Result.success(salon);
    } catch (e) {
      return Result.failure(ServerFailure('Salon not found'));
    }
  }

  Future<Result<List<Salon>>> searchSalons(String query) async {
    try {
      await Future.delayed(const Duration(milliseconds: 400));
      final results = _mockSalons
          .where((s) => s.name.toLowerCase().contains(query.toLowerCase()) ||
              s.address.toLowerCase().contains(query.toLowerCase()))
          .toList();
      return Result.success(results);
    } catch (e) {
      return Result.failure(ServerFailure('Search failed: $e'));
    }
  }

  Future<Result<List<SalonService>>> getServicesBySalon(String salonId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final services = _mockServices.where((s) => s.salonId == salonId).toList();
      return Result.success(services);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to fetch services: $e'));
    }
  }

  Future<Result<List<Stylist>>> getStylistsBySalon(String salonId) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final stylists = _mockStylists.where((s) => s.salonId == salonId).toList();
      return Result.success(stylists);
    } catch (e) {
      return Result.failure(ServerFailure('Failed to fetch stylists: $e'));
    }
  }
}
