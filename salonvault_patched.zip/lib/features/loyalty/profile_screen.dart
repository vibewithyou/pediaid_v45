import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/language_provider.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final user = authState.user;
    final locale = ref.watch(localeProvider);
    final local = AppLocalizations.of(context);

    return Scaffold(
      appBar: AppBar(title: Text(local.translate('profile_title'))),
      body: user == null
          ? Center(child: Text(local.translate('not_logged_in')))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Center(
                  child: CircleAvatar(
                    radius: 60,
                    backgroundColor: AppColors.gold,
                    child: Icon(Icons.person, size: 60, color: AppColors.black),
                  ),
                ),
                const SizedBox(height: 24),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(local.translate('personal_information'), style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: 16),
                        _InfoRow(label: local.translate('name'), value: user.name),
                        const SizedBox(height: 12),
                        _InfoRow(label: local.translate('email'), value: user.email),
                        const SizedBox(height: 12),
                        _InfoRow(label: local.translate('phone'), value: user.phone ?? local.translate('not_provided')),
                        const SizedBox(height: 12),
                        _InfoRow(label: local.translate('role'), value: user.role.name),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: Column(
                    children: [
                      ListTile(
                        leading: Icon(Icons.receipt, color: AppColors.gold),
                        title: Text(local.translate('legal_impressum')),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => context.push('/impressum'),
                      ),
                      ListTile(
                        leading: Icon(Icons.chat_bubble, color: AppColors.gold),
                        title: Text(local.translate('messages')),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => context.push('/chat'),
                      ),
                      ListTile(
                        leading: Icon(Icons.privacy_tip, color: AppColors.gold),
                        title: Text(local.translate('privacy_policy')),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => context.push('/privacy'),
                      ),
                      if (user.role.name == 'platformAdmin' || user.role.name == 'salonOwner')
                        ListTile(
                          leading: Icon(Icons.point_of_sale, color: AppColors.gold),
                          title: Text(local.translate('pos_system')),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => context.push('/pos'),
                        ),
                      // Link to help/FAQ page
                      ListTile(
                        leading: Icon(Icons.help_outline, color: AppColors.gold),
                        title: Text(local.translate('help_faq')),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => context.push('/help'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Language selection
                Card(
                  child: ListTile(
                    leading: Icon(Icons.language, color: AppColors.gold),
                    title: Text(local.translate('change_language')),
                    trailing: Text(local.translate('lang_${locale.languageCode}')),
                    onTap: () => _showLanguageSheet(context, ref, local),
                  ),
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () async {
                    await ref.read(authStateProvider.notifier).logout();
                    if (context.mounted) {
                      context.go('/login');
                    }
                  },
                  icon: const Icon(Icons.logout),
                  label: Text(local.translate('logout')),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.errorRed,
                    foregroundColor: AppColors.white,
                  ),
                ),
              ],
            ),
    );
  }

  void _showLanguageSheet(BuildContext context, WidgetRef ref, AppLocalizations local) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              RadioListTile<Locale>(
                title: Text(local.translate('lang_de')),
                value: const Locale('de'),
                groupValue: ref.read(localeProvider),
                onChanged: (value) {
                  if (value != null) {
                    ref.read(localeProvider.notifier).setLocale(value);
                    Navigator.pop(ctx);
                  }
                },
              ),
              RadioListTile<Locale>(
                title: Text(local.translate('lang_en')),
                value: const Locale('en'),
                groupValue: ref.read(localeProvider),
                onChanged: (value) {
                  if (value != null) {
                    ref.read(localeProvider.notifier).setLocale(value);
                    Navigator.pop(ctx);
                  }
                },
              ),
              RadioListTile<Locale>(
                title: Text(local.translate('lang_tr')),
                value: const Locale('tr'),
                groupValue: ref.read(localeProvider),
                onChanged: (value) {
                  if (value != null) {
                    ref.read(localeProvider.notifier).setLocale(value);
                    Navigator.pop(ctx);
                  }
                },
              ),
              RadioListTile<Locale>(
                title: Text(local.translate('lang_ru')),
                value: const Locale('ru'),
                groupValue: ref.read(localeProvider),
                onChanged: (value) {
                  if (value != null) {
                    ref.read(localeProvider.notifier).setLocale(value);
                    Navigator.pop(ctx);
                  }
                },
              ),
              RadioListTile<Locale>(
                title: Text(local.translate('lang_ar')),
                value: const Locale('ar'),
                groupValue: ref.read(localeProvider),
                onChanged: (value) {
                  if (value != null) {
                    ref.read(localeProvider.notifier).setLocale(value);
                    Navigator.pop(ctx);
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ),
      ],
    );
  }
}
