import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/core/providers/loyalty_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';

class LoyaltyScreen extends ConsumerWidget {
  const LoyaltyScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final user = authState.user;

    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please login to view loyalty points')),
      );
    }

    final pointsAsync = ref.watch(userPointsProvider(user.id));
    final transactionsAsync = ref.watch(userTransactionsProvider(user.id));

    return Scaffold(
      appBar: AppBar(title: const Text('Loyalty Program')),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(userPointsProvider);
          ref.invalidate(userTransactionsProvider);
        },
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Points overview card
            LuxuryCard(
              leading: const Icon(Icons.card_giftcard, color: AppColors.gold),
              title: pointsAsync.when(
                data: (points) => '$points',
                loading: () => '…',
                error: (e, _) => '–',
              ),
              subtitle: 'Your Points',
              trailing: LuxuryButton(
                label: 'Redeem',
                filled: false,
                onPressed: () async {
                  final redeemed = await showDialog<bool>(
                    context: context,
                    builder: (_) => _RedeemDialog(userId: user.id),
                  );
                  if (redeemed == true && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Redeemed points (mock)')));
                    ref.invalidate(userPointsProvider);
                    ref.invalidate(userTransactionsProvider);
                  }
                },
              ),
            ),
            const SizedBox(height: 24),
            Text('Transaction History', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 16),
            transactionsAsync.when(
              data: (transactions) {
                if (transactions.isEmpty) {
                  return const Center(child: Text('No transactions yet'));
                }
                return Column(
                  children: transactions.map((transaction) {
                    final isPositive = transaction.points > 0;
                    final color = isPositive ? AppColors.successGreen : AppColors.errorRed;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: LuxuryCard(
                        leading: CircleAvatar(
                          backgroundColor: color.withOpacity(0.2),
                          child: Icon(isPositive ? Icons.add : Icons.remove, color: color),
                        ),
                        title: transaction.description,
                        subtitle: '${transaction.date.day.toString().padLeft(2, '0')}/${transaction.date.month.toString().padLeft(2, '0')}/${transaction.date.year}',
                        trailing: Text(
                          '${isPositive ? '+' : ''}${transaction.points}',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: color, fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => Center(child: Text('Error: $error')),
            ),
            const SizedBox(height: 24),
            // Gift cards & bundles section
            Text('Gift Cards & Bundles', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 16),
            // In a real app, cards would be loaded from API. Here we define a placeholder list.
            ..._buildGiftAndBundleCards(context),
            const SizedBox(height: 24),
            // Invite a friend button
            LuxuryButton(
              label: 'Invite a Friend',
              filled: false,
              onPressed: () {
                _showInviteFriendDialog(context);
              },
            ),
            const SizedBox(height: 16),
            // Birthday bonus example card
            _buildBirthdayBonusCard(context),
          ],
        ),
      ),
    );
  }

  /// Build a list of gift card and bundle cards. This uses static data for the
  /// demo but will later be populated from the backend. Each card shows a
  /// voucher code, remaining balance or sessions, and an action to redeem.
  List<Widget> _buildGiftAndBundleCards(BuildContext context) {
    final List<Map<String, String>> giftCards = [
      {
        'code': 'GC-12345',
        'balance': '€50',
      },
    ];
    final List<Map<String, String>> bundles = [
      {
        'name': '10x Massage',
        'remaining': '6 of 10',
      },
    ];
    final List<Widget> widgets = [];
    for (final gc in giftCards) {
      widgets.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: LuxuryCard(
            leading: const Icon(Icons.card_giftcard, color: AppColors.gold),
            title: 'Gift Card ${gc['code']}',
            subtitle: 'Balance: ${gc['balance']}',
            trailing: LuxuryButton(
              label: 'Redeem',
              filled: false,
              onPressed: () {
                // In real app, this would redeem from backend
                // TODO(tobiasbecker2025): Redeem gift card via backend
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Redeem gift card (mock)')),
                );
              },
            ),
          ),
        ),
      );
    }
    for (final b in bundles) {
      widgets.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: LuxuryCard(
            leading: const Icon(Icons.all_inclusive, color: AppColors.gold),
            title: b['name']!,
            subtitle: 'Remaining: ${b['remaining']}',
            trailing: LuxuryButton(
              label: 'Use',
              filled: false,
              onPressed: () {
                // TODO(tobiasbecker2025): Use a session of bundle via backend
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Use bundle session (mock)')),
                );
              },
            ),
          ),
        ),
      );
    }
    if (widgets.isEmpty) {
      widgets.add(const Text('No gift cards or bundles yet'));
    }
    return widgets;
  }

  /// Show a dialog for inviting a friend. It displays a referral code and
  /// provides a share button (not functional). Later the code will be sent via backend.
  void _showInviteFriendDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          title: const Text('Invite a Friend'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('Share this code with your friend to earn bonus points when they book their first appointment.'),
              SizedBox(height: 8),
              SelectableText('REF-98765', style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
            LuxuryButton(
              label: 'Share',
              filled: true,
              onPressed: () {
                // TODO(tobiasbecker2025): share referral code via platform share
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Referral shared (mock)')));
              },
            ),
          ],
        );
      },
    );
  }

  /// Build a card showing a birthday bonus. In a real app this would be
  /// conditional on current date and user birthday. Here we always show it.
  Widget _buildBirthdayBonusCard(BuildContext context) {
    return LuxuryCard(
      leading: const Icon(Icons.cake, color: AppColors.gold),
      title: 'Happy Birthday! 🎂',
      subtitle: 'We added 50 bonus points to your account',
      trailing: LuxuryButton(
        label: 'Thank you',
        filled: false,
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enjoy your bonus!')));
        },
      ),
    );
  }
}

class _RedeemDialog extends ConsumerStatefulWidget {
  final String userId;
  const _RedeemDialog({required this.userId});

  @override
  ConsumerState<_RedeemDialog> createState() => _RedeemDialogState();
}

class _RedeemDialogState extends ConsumerState<_RedeemDialog> {
  final _pointsController = TextEditingController(text: '50');
  final _descController = TextEditingController(text: 'Voucher');
  bool _loading = false;

  @override
  void dispose() {
    _pointsController.dispose();
    _descController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Redeem Points'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _pointsController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(hintText: 'Points'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _descController,
            decoration: const InputDecoration(hintText: 'Description'),
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: _loading
              ? null
              : () async {
                  final points = int.tryParse(_pointsController.text.trim());
                  if (points == null || points <= 0) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Enter a valid points amount')),
                    );
                    return;
                  }
                  setState(() => _loading = true);
                  final service = ref.read(loyaltyServiceProvider);
                  final result = await service.redeemPoints(widget.userId, points, _descController.text.trim());
                  setState(() => _loading = false);
                  result.fold(
                    (f) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: ${f.message}'))),
                    (_) => Navigator.of(context).pop(true),
                  );
                },
          child: _loading ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Redeem'),
        ),
      ],
    );
  }
}
