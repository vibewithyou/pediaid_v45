import 'dart:math';

import '../models.dart';

abstract class StylistRepository {
  Future<List<StylistAppointment>> fetchTodayAppointments();
  Future<StylistAppointment> confirmAppointment(String id);
  Future<StylistAppointment> declineAppointment(String id);
  Future<CustomerQuickInfo> fetchCustomerQuickInfo(String customerId);
  Future<void> addQuickNote(String customerId, String note);
}

class MockStylistRepository implements StylistRepository {
  final Map<String, StylistAppointment> _appointments = {};
  final Map<String, CustomerQuickInfo> _customers = {};

  MockStylistRepository() {
    // seed with sample data
    final now = DateTime.now();
    final samples = [
      (
        id: 'a1',
        start: DateTime(now.year, now.month, now.day, 9, 0),
        durMin: 45,
        cid: 'c1',
        cname: 'Anna Müller',
        service: 'Haarschnitt Damen'
      ),
      (
        id: 'a2',
        start: DateTime(now.year, now.month, now.day, 10, 0),
        durMin: 30,
        cid: 'c2',
        cname: 'Max Schneider',
        service: 'Bart & Konturen'
      ),
      (
        id: 'a3',
        start: DateTime(now.year, now.month, now.day, 11, 15),
        durMin: 60,
        cid: 'c3',
        cname: 'Lina Köster',
        service: 'Färben & Styling'
      ),
    ];
    for (final s in samples) {
      _appointments[s.id] = StylistAppointment(
        id: s.id,
        start: s.start,
        duration: Duration(minutes: s.durMin),
        customerId: s.cid,
        customerName: s.cname,
        serviceName: s.service,
      );
    }
    _customers['c1'] = const CustomerQuickInfo(
      id: 'c1',
      name: 'Anna Müller',
      notes: ['Mag leises Ambiente', 'Empfindliche Kopfhaut'],
      allergies: ['Nickel'],
      loyaltyPoints: 120,
      recentImageUrls: [],
    );
    _customers['c2'] = const CustomerQuickInfo(
      id: 'c2',
      name: 'Max Schneider',
      notes: ['Sportlich, schnell'],
      allergies: [],
      loyaltyPoints: 40,
      recentImageUrls: [],
    );
    _customers['c3'] = const CustomerQuickInfo(
      id: 'c3',
      name: 'Lina Köster',
      notes: ['Neue Farbe testen'],
      allergies: ['Pollen'],
      loyaltyPoints: 200,
      recentImageUrls: [],
    );
  }

  @override
  Future<List<StylistAppointment>> fetchTodayAppointments() async {
    await Future<void>.delayed(const Duration(milliseconds: 200));
    final sorted = _appointments.values.toList()
      ..sort((a, b) => a.start.compareTo(b.start));
    return sorted;
  }

  @override
  Future<StylistAppointment> confirmAppointment(String id) async {
    await Future<void>.delayed(const Duration(milliseconds: 120));
    final appt = _appointments[id];
    if (appt == null) throw StateError('Appointment not found');
    final updated = appt.copyWith(status: AppointmentStatus.confirmed);
    _appointments[id] = updated;
    return updated;
  }

  @override
  Future<StylistAppointment> declineAppointment(String id) async {
    await Future<void>.delayed(const Duration(milliseconds: 120));
    final appt = _appointments[id];
    if (appt == null) throw StateError('Appointment not found');
    final updated = appt.copyWith(status: AppointmentStatus.declined);
    _appointments[id] = updated;
    return updated;
  }

  @override
  Future<CustomerQuickInfo> fetchCustomerQuickInfo(String customerId) async {
    await Future<void>.delayed(const Duration(milliseconds: 200));
    final info = _customers[customerId];
    if (info == null) throw StateError('Customer not found');
    return info;
  }

  @override
  Future<void> addQuickNote(String customerId, String note) async {
    await Future<void>.delayed(const Duration(milliseconds: 100));
    final info = _customers[customerId];
    if (info == null) throw StateError('Customer not found');
    final newNotes = [...info.notes, note];
    _customers[customerId] = CustomerQuickInfo(
      id: info.id,
      name: info.name,
      notes: newNotes,
      allergies: info.allergies,
      loyaltyPoints: info.loyaltyPoints + Random().nextInt(3),
      recentImageUrls: info.recentImageUrls,
    );
  }
}
