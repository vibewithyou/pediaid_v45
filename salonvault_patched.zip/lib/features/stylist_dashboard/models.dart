import 'package:flutter/foundation.dart';

@immutable
class StylistAppointment {
  final String id;
  final DateTime start;
  final Duration duration;
  final String customerId;
  final String customerName;
  final String serviceName;
  final AppointmentStatus status;

  const StylistAppointment({
    required this.id,
    required this.start,
    required this.duration,
    required this.customerId,
    required this.customerName,
    required this.serviceName,
    this.status = AppointmentStatus.pending,
  });

  StylistAppointment copyWith({
    DateTime? start,
    Duration? duration,
    String? customerId,
    String? customerName,
    String? serviceName,
    AppointmentStatus? status,
  }) {
    return StylistAppointment(
      id: id,
      start: start ?? this.start,
      duration: duration ?? this.duration,
      customerId: customerId ?? this.customerId,
      customerName: customerName ?? this.customerName,
      serviceName: serviceName ?? this.serviceName,
      status: status ?? this.status,
    );
  }
}

enum AppointmentStatus { pending, confirmed, declined, completed }

@immutable
class CustomerQuickInfo {
  final String id;
  final String name;
  final List<String> notes; // short hints
  final List<String> allergies;
  final int loyaltyPoints;
  final List<String> recentImageUrls; // could be assets/urls

  const CustomerQuickInfo({
    required this.id,
    required this.name,
    this.notes = const [],
    this.allergies = const [],
    this.loyaltyPoints = 0,
    this.recentImageUrls = const [],
  });
}
