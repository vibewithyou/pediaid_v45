import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../widgets/today_appointments.dart';
import '../widgets/quick_actions.dart';

class StylistDashboardScreen extends ConsumerWidget {
  const StylistDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Arbeitsboard'),
      ),
      body: SingleChildScrollView(
        key: const Key('stylist_dashboard_body'),
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            TodayAppointments(),
            SizedBox(height: 12),
            QuickActions(),
          ],
        ),
      ),
    );
  }
}
