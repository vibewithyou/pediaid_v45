import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/stylist_state.dart';
import '../widgets/customer_mini_card.dart';

class CustomerQuickView extends ConsumerWidget {
  const CustomerQuickView({super.key, required this.customerId});
  final String customerId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final info = ref.watch(customerQuickInfoProvider(customerId));
    return Scaffold(
      appBar: AppBar(title: const Text('Karteikarte')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: info.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, st) => Center(child: Text('Fehler: $e')),
          data: (d) => ListView(
            key: const Key('customer_quick_view_list'),
            children: [
              CustomerMiniCard(info: d),
            ],
          ),
        ),
      ),
    );
  }
}
