import 'package:flutter/material.dart';

import '../models.dart';

class CustomerMiniCard extends StatelessWidget {
  const CustomerMiniCard({super.key, required this.info});
  final CustomerQuickInfo info;

  @override
  Widget build(BuildContext context) {
    return Card(
      key: const Key('customer_mini_card'),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.person, color: Colors.blue),
                const SizedBox(width: 8),
                Text(info.name, style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                Chip(
                  label: Text('${info.loyaltyPoints} Punkte'),
                  avatar: const Icon(Icons.stars, color: Colors.amber),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (info.notes.isNotEmpty) ...[
              Text('Hinweise', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: info.notes.map((n) => Chip(label: Text(n))).toList(),
              ),
              const SizedBox(height: 12),
            ],
            if (info.allergies.isNotEmpty) ...[
              Text('Allergien', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: info.allergies.map((a) => Chip(label: Text(a), avatar: const Icon(Icons.warning, color: Colors.red))).toList(),
              ),
              const SizedBox(height: 12),
            ],
            Text('Letzte Bilder', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            _RecentImages(urls: info.recentImageUrls),
          ],
        ),
      ),
    );
  }
}

class _RecentImages extends StatelessWidget {
  const _RecentImages({required this.urls});
  final List<String> urls;

  @override
  Widget build(BuildContext context) {
    if (urls.isEmpty) {
      return Container(
        height: 84,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.withValues(alpha: 0.3)),
        ),
        child: const Text('Keine Bilder'),
      );
    }
    return SizedBox(
      height: 84,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: urls.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final u = urls[index];
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(u, width: 84, height: 84, fit: BoxFit.cover),
          );
        },
      ),
    );
  }
}
