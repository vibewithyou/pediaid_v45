import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models.dart';
import '../state/stylist_state.dart';

class TodayAppointments extends ConsumerWidget {
  const TodayAppointments({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appts = ref.watch(todayAppointmentsProvider);
    return Card(
      key: const Key('today_appointments_card'),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.event_available, color: Colors.blue),
                const SizedBox(width: 8),
                Text('Heute', style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                IconButton(
                  tooltip: 'Aktualisieren',
                  onPressed: () => ref.read(todayAppointmentsProvider.notifier).refresh(),
                  icon: const Icon(Icons.refresh, color: Colors.grey),
                ),
              ],
            ),
            const SizedBox(height: 8),
            appts.when(
              loading: () => const Center(child: Padding(
                padding: EdgeInsets.all(16.0),
                child: CircularProgressIndicator(),
              )),
              error: (e, st) => Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text('Fehler: $e'),
              ),
              data: (items) {
                if (items.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text('Keine Termine heute'),
                  );
                }
                return ListView.separated(
                  key: const Key('today_appointments_list'),
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final a = items[index];
                    return _AppointmentTile(appt: a);
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _AppointmentTile extends ConsumerWidget {
  const _AppointmentTile({required this.appt});
  final StylistAppointment appt;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    String fmtTime(DateTime dt) =>
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    final statusColor = switch (appt.status) {
      AppointmentStatus.pending => Colors.orange,
      AppointmentStatus.confirmed => Colors.green,
      AppointmentStatus.declined => Colors.red,
      AppointmentStatus.completed => Colors.grey,
    };

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
      leading: CircleAvatar(
        backgroundColor: statusColor.withValues(alpha: 0.15),
        child: Text(fmtTime(appt.start),
            style: Theme.of(context).textTheme.labelSmall),
      ),
      title: Text('${appt.customerName} • ${appt.serviceName}'),
      subtitle: Text('${appt.duration.inMinutes} Min'),
      trailing: Wrap(
        spacing: 8,
        children: [
          if (appt.status == AppointmentStatus.pending)
            IconButton(
              key: Key('confirm_${appt.id}'),
              tooltip: 'Bestätigen',
              icon: const Icon(Icons.check_circle, color: Colors.green),
              onPressed: () => ref.read(todayAppointmentsProvider.notifier).confirm(appt.id),
            ),
          if (appt.status == AppointmentStatus.pending)
            IconButton(
              key: Key('decline_${appt.id}'),
              tooltip: 'Ablehnen',
              icon: const Icon(Icons.cancel, color: Colors.red),
              onPressed: () => ref.read(todayAppointmentsProvider.notifier).decline(appt.id),
            ),
          Icon(Icons.circle, size: 12, color: statusColor),
        ],
      ),
      onTap: () {
        // Navigate to customer quick view
        context.push('/stylist/customer/${appt.customerId}');
      },
    );
  }
}
