import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/stylist_state.dart';

class QuickActions extends ConsumerWidget {
  const QuickActions({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      key: const Key('quick_actions_card'),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.flash_on, color: Colors.amber),
                const SizedBox(width: 8),
                Text('Schnelle Aktionen', style: Theme.of(context).textTheme.titleLarge),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                _ActionChip(
                  key: const Key('action_add_note'),
                  icon: Icons.note_add,
                  label: 'Notiz anlegen',
                  onTap: () async {
                    // Simple demo: add a note to c1
                    final repo = ref.read(stylistRepositoryProvider);
                    await repo.addQuickNote('c1', 'Kurze Notiz vom Dashboard');
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Notiz hinzugefügt')),
                      );
                    }
                  },
                ),
                _ActionChip(
                  key: const Key('action_take_photo'),
                  icon: Icons.photo_camera,
                  label: 'Foto aufnehmen',
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Foto aufnehmen'),
                        content: const Text('Kamera-UI Platzhalter (Web freundlich).'),
                        actions: [
                          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Schließen')),
                        ],
                      ),
                    );
                  },
                ),
                _ActionChip(
                  key: const Key('action_open_gallery'),
                  icon: Icons.collections,
                  label: 'Galerie öffnen',
                  onTap: () => Navigator.of(context).pushNamed('/gallery'),
                ),
                _ActionChip(
                  key: const Key('action_open_chat'),
                  icon: Icons.chat,
                  label: 'Chat starten',
                  onTap: () => Navigator.of(context).pushNamed('/chat'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionChip extends StatelessWidget {
  const _ActionChip({super.key, required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.withValues(alpha: 0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.blue),
            const SizedBox(width: 8),
            Text(label),
          ],
        ),
      ),
    );
  }
}
