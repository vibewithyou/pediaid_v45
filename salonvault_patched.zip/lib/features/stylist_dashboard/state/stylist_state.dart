import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/stylist_repository.dart';
import '../models.dart';

// Repository provider (mock by default)
final stylistRepositoryProvider = Provider<StylistRepository>((ref) {
  return MockStylistRepository();
});

// Appointments list state
final todayAppointmentsProvider = AsyncNotifierProvider.autoDispose
    <TodayAppointmentsNotifier, List<StylistAppointment>>(TodayAppointmentsNotifier.new);

class TodayAppointmentsNotifier extends AsyncNotifier<List<StylistAppointment>> {
  @override
  Future<List<StylistAppointment>> build() async {
    final repo = ref.read(stylistRepositoryProvider);
    return repo.fetchTodayAppointments();
  }

  Future<void> refresh() async {
    state = const AsyncLoading<List<StylistAppointment>>();
    state = await AsyncValue.guard(() async {
      final repo = ref.read(stylistRepositoryProvider);
      return repo.fetchTodayAppointments();
    });
  }

  Future<void> confirm(String apptId) async {
    final repo = ref.read(stylistRepositoryProvider);
    // optimistic update
    final current = state.value ?? [];
    state = AsyncData(current
        .map((e) => e.id == apptId
            ? e.copyWith(status: AppointmentStatus.confirmed)
            : e)
        .toList());
    await repo.confirmAppointment(apptId);
  }

  Future<void> decline(String apptId) async {
    final repo = ref.read(stylistRepositoryProvider);
    final current = state.value ?? [];
    state = AsyncData(current
        .map((e) => e.id == apptId
            ? e.copyWith(status: AppointmentStatus.declined)
            : e)
        .toList());
    await repo.declineAppointment(apptId);
  }
}

// Customer quick info provider (parameterized by customerId)
final customerQuickInfoProvider = FutureProvider.family.autoDispose<CustomerQuickInfo, String>((ref, id) async {
  final repo = ref.read(stylistRepositoryProvider);
  return repo.fetchCustomerQuickInfo(id);
});
