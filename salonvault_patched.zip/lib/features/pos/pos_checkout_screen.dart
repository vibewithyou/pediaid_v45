import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';
import 'package:salonvault/features/pos/invoice_preview_screen.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

class POSCheckoutScreen extends StatefulWidget {
  const POSCheckoutScreen({super.key});

  @override
  State<POSCheckoutScreen> createState() => _POSCheckoutScreenState();
}

class _POSCheckoutScreenState extends State<POSCheckoutScreen> {
  final List<_CartItem> _cartItems = [];

  // Controller for tip input. Users can optionally add a tip to the total
  // before splitting payments. The tip is entered as a numeric amount in
  // euros. If left empty or invalid, the tip defaults to 0. The tip is
  // included in the grand total and affects the remaining balance.
  final TextEditingController _tipController = TextEditingController();

  /// Shows a dialog for entering a custom POS item. The user can specify
  /// a name and price; the tax rate is provided. When saved, the item
  /// is added to the cart. Invalid input triggers a localized error message.
  void _showAddItemDialog(double taxRate) {
    final l = AppLocalizations.of(context);
    String itemName = '';
    String priceStr = '';
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(l.translate('add_item')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: InputDecoration(
                    labelText: l.translate('item_name'),
                    hintText: l.translate('enter_name'),
                  ),
                  onChanged: (v) => itemName = v,
                ),
                TextField(
                  decoration: InputDecoration(
                    labelText: l.translate('item_price'),
                    hintText: l.translate('enter_price'),
                  ),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (v) => priceStr = v,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(l.translate('cancel')),
            ),
            ElevatedButton(
              onPressed: () {
                final price = double.tryParse(priceStr.replaceAll(',', '.'));
                if (itemName.trim().isEmpty || price == null || price < 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(l.translate('error_invalid_input'))),
                  );
                  return;
                }
                _addItem(itemName.trim(), price, taxRate);
                Navigator.pop(context);
              },
              child: Text(l.translate('save')),
            ),
          ],
        );
      },
    );
  }

  void _addItem(String name, double price, double taxRate) {
    setState(() {
      _cartItems.add(_CartItem(name: name, price: price, taxRate: taxRate));
    });
  }

  double get _subtotal => _cartItems.fold(0, (sum, item) => sum + item.price);
  double get _tax19 => _cartItems
      .where((item) => item.taxRate == 0.19)
      .fold(0, (sum, item) => sum + (item.price * item.taxRate));
  double get _tax7 => _cartItems
      .where((item) => item.taxRate == 0.07)
      .fold(0, (sum, item) => sum + (item.price * item.taxRate));
  double get _total => _subtotal + _tax19 + _tax7;

  /// Parses the tip amount from the text input. Returns 0 if the input
  /// cannot be parsed to a double. The tip is always non-negative.
  double get _tip {
    final val = double.tryParse(_tipController.text.replaceAll(',', '.')) ?? 0.0;
    return val < 0 ? 0 : val;
  }

  /// Computes the grand total including tip. This value is used as the
  /// upper bound for the deposit slider.
  double get _grandTotal => _total + _tip;

  // The deposit portion for split payments. Users can choose to pay a
  // portion of the total upfront (e.g. as a deposit or down payment).
  double _deposit = 0.0;

  /// Computes the remaining amount after deposit. If deposit is
  /// negative or exceeds the total, it is clamped to [0, _total].
  double get _remaining {
    final d = _deposit.clamp(0, _total);
    // Remaining is calculated against the grand total (including tip).
    final grandDeposit = _deposit.clamp(0, _grandTotal);
    return _grandTotal - grandDeposit;
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l.translate('pos_checkout'))),
      body: Column(
        children: [
          Expanded(
            child: _cartItems.isEmpty
                ? Center(
                    child: Text(
                      l.translate('cart_empty'),
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _cartItems.length,
                    itemBuilder: (context, index) {
                      final item = _cartItems[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: LuxuryCard(
                          title: item.name,
                          subtitle: 'Tax: ${(item.taxRate * 100).toInt()}%',
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '€${item.price.toStringAsFixed(2)}',
                                style: const TextStyle(
                                  color: AppColors.gold,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete),
                                onPressed: () => setState(() => _cartItems.removeAt(index)),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Column(
              children: [
                _SummaryRow(label: l.translate('subtotal'), value: _subtotal),
                const SizedBox(height: 8),
                _SummaryRow(label: l.translate('tax_19'), value: _tax19),
                const SizedBox(height: 8),
                _SummaryRow(label: l.translate('tax_7'), value: _tax7),
                const Divider(height: 24),
                _SummaryRow(label: l.translate('total'), value: _total, isTotal: true),
                const SizedBox(height: 8),
                // Tip input row. Allows the user to enter a tip amount that
                // will be added to the total. The tip is optional and
                // defaults to 0.00. This uses a LuxuryInput for styling.
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(l.translate('tip'), style: Theme.of(context).textTheme.bodyLarge),
                    SizedBox(
                      width: 120,
                      child: LuxuryInput(
                        controller: _tipController,
                        hintText: '€0.00',
                        keyboardType: TextInputType.numberWithOptions(decimal: true),
                        onChanged: (_) {
                          setState(() {
                            // Update deposit clamp if user changes tip
                            if (_deposit > _grandTotal) {
                              _deposit = _grandTotal;
                            }
                          });
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                _SummaryRow(label: l.translate('grand_total'), value: _grandTotal, isTotal: true),
                // Split payment controls. Allow the user to choose how much
                // of the total should be paid as a deposit. When there are
                // items in the cart, the slider becomes visible. The deposit
                // amount and remaining due are displayed below.
                if (_cartItems.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(l.translate('deposit'), style: Theme.of(context).textTheme.bodyLarge),
                      Text('€${_deposit.toStringAsFixed(2)}', style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppColors.gold)),
                    ],
                  ),
                  Slider(
                    min: 0,
                    max: _grandTotal,
                    divisions: 100,
                    value: _deposit.clamp(0, _grandTotal),
                    onChanged: (val) {
                      setState(() {
                        _deposit = val;
                      });
                    },
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(l.translate('remaining'), style: Theme.of(context).textTheme.bodyLarge),
                      Text('€${_remaining.toStringAsFixed(2)}', style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppColors.gold)),
                    ],
                  ),
                ],
                const SizedBox(height: 16),
                // Item actions: Add items and generate invoice
                Row(
                  children: [
                    Expanded(
                      child: LuxuryButton(
                        label: l.translate('add_item_19'),
                        filled: false,
                        onPressed: () {
                          _showAddItemDialog(0.19);
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: LuxuryButton(
                        label: l.translate('add_item_7'),
                        filled: false,
                        onPressed: () {
                          _showAddItemDialog(0.07);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: LuxuryButton(
                        label: l.translate('generate_invoice'),
                        filled: true,
                        onPressed: _cartItems.isEmpty
                            ? null
                            : () {
                                final msg = l.translate('invoice_generated');
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('$msg – Deposit: €${_deposit.toStringAsFixed(2)}, Remaining: €${_remaining.toStringAsFixed(2)}, Tip: €${_tip.toStringAsFixed(2)}'),
                                  ),
                                );
                              },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: LuxuryButton(
                        label: l.translate('preview_invoice'),
                        filled: false,
                        onPressed: _cartItems.isEmpty
                            ? null
                            : () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => POSInvoicePreviewScreen(
                                      items: List<_CartItem>.from(_cartItems),
                                      subtotal: _subtotal,
                                      tax19: _tax19,
                                      tax7: _tax7,
                                      tip: _tip,
                                      deposit: _deposit,
                                    ),
                                  ),
                                );
                              },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CartItem {
  final String name;
  final double price;
  final double taxRate;

  _CartItem({required this.name, required this.price, required this.taxRate});
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final double value;
  final bool isTotal;

  const _SummaryRow({
    required this.label,
    required this.value,
    this.isTotal = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: isTotal
              ? Theme.of(context).textTheme.headlineMedium
              : Theme.of(context).textTheme.bodyLarge,
        ),
        Text(
          '€${value.toStringAsFixed(2)}',
          style: isTotal
              ? Theme.of(context).textTheme.headlineMedium?.copyWith(color: AppColors.gold)
              : Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppColors.gold),
        ),
      ],
    );
  }
}
