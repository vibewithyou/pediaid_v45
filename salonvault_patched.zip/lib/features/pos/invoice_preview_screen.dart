import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

/// A simple invoice preview screen. This screen accepts the list of cart
/// items and cost breakdowns and displays them in a formatted manner.
/// A real implementation would render a PDF document and allow sharing or
/// downloading. For now, this serves as a placeholder UI with all values
/// clearly shown. Backend integration is indicated via TODO markers.
class POSInvoicePreviewScreen extends StatelessWidget {
  final List<dynamic> items;
  final double subtotal;
  final double tax19;
  final double tax7;
  final double tip;
  final double deposit;

  const POSInvoicePreviewScreen({
    super.key,
    required this.items,
    required this.subtotal,
    required this.tax19,
    required this.tax7,
    required this.tip,
    required this.deposit,
  });

  double get _total => subtotal + tax19 + tax7;
  double get _grandTotal => _total + tip;
  double get _remaining => _grandTotal - deposit;

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l.translate('invoice_preview'))),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(l.translate('invoice_details'), style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                ...items.asMap().entries.map((entry) {
                    final item = entry.value;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: LuxuryCard(
                        title: item.name,
                        subtitle: 'Tax: ${(item.taxRate * 100).toInt()}%',
                        trailing: Text(
                          '€${item.price.toStringAsFixed(2)}',
                          style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  }),
                  const Divider(height: 24),
                  _SummaryRow(label: l.translate('subtotal'), value: subtotal),
                  const SizedBox(height: 8),
                  _SummaryRow(label: l.translate('tax_19'), value: tax19),
                  const SizedBox(height: 8),
                  _SummaryRow(label: l.translate('tax_7'), value: tax7),
                  const SizedBox(height: 8),
                  _SummaryRow(label: l.translate('tip'), value: tip),
                  const Divider(height: 24),
                  _SummaryRow(label: l.translate('grand_total'), value: _grandTotal, isTotal: true),
                  const SizedBox(height: 8),
                  _SummaryRow(label: l.translate('deposit'), value: deposit),
                  const SizedBox(height: 8),
                  _SummaryRow(label: l.translate('remaining'), value: _remaining, isTotal: true),
                ],
              ),
            ),
            const SizedBox(height: 12),
            LuxuryButton(
              label: l.translate('download_pdf'),
              filled: true,
              onPressed: () {
                // TODO(tobiasbecker2025): generate and download PDF invoice via backend or local rendering.
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(l.translate('pdf_download_not_implemented'))),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final double value;
  final bool isTotal;

  const _SummaryRow({required this.label, required this.value, this.isTotal = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: Theme.of(context).textTheme.bodyLarge),
        Text(
          '€${value.toStringAsFixed(2)}',
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: isTotal ? AppColors.gold : null,
                fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              ),
        ),
      ],
    );
  }
}