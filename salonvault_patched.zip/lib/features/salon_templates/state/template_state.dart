import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../entities.dart';
import '../data/template_repository.dart';

final templateRepositoryProvider = Provider<TemplateRepository>((ref) => InMemoryTemplateRepository());

class TemplateStore extends Notifier<Map<String, TemplateState>> {
  TemplateRepository get _repo => ref.read(templateRepositoryProvider);

  @override
  Map<String, TemplateState> build() => {};

  TemplateState? getState(String salonId) => state[salonId];

  Future<void> ensureLoaded(String salonId) async {
    final current = state[salonId];
    if (current != null && !current.isLoading) return;
    state = {
      ...state,
      salonId: TemplateState(salonId: salonId, template: SalonTemplate.defaultForDemo(), isLoading: true),
    };
    try {
      final t = await _repo.getTemplate(salonId);
      state = {
        ...state,
        salonId: TemplateState(salonId: salonId, template: t, isLoading: false),
      };
    } catch (e) {
      state = {
        ...state,
        salonId: TemplateState(salonId: salonId, template: SalonTemplate.defaultForDemo(), isLoading: false, error: e.toString()),
      };
    }
  }

  Future<void> setTokens(String salonId, SalonThemeTokens tokens) async {
    final current = state[salonId];
    if (current == null) return;
    final updated = current.template.copyWith(tokens: tokens);
    await _save(salonId, updated);
  }

  Future<void> setDark(String salonId, bool dark) => setTokens(salonId, state[salonId]!.template.tokens.copyWith(dark: dark));
  Future<void> setPrimary(String salonId, Color color) => setTokens(salonId, state[salonId]!.template.tokens.copyWith(primary: color));
  Future<void> setAccent(String salonId, Color color) => setTokens(salonId, state[salonId]!.template.tokens.copyWith(accent: color));
  Future<void> setLogo(String salonId, String? base64) => setTokens(salonId, state[salonId]!.template.tokens.copyWith(logoBase64: base64));

  Future<void> reorderBlocks(String salonId, List<LayoutBlock> newOrder) async {
    final current = state[salonId];
    if (current == null) return;
    final normalized = [
      for (var i = 0; i < newOrder.length; i++) newOrder[i].copyWith(order: i),
    ];
    await _save(salonId, current.template.copyWith(blocks: normalized));
  }

  Future<void> updateBlock(String salonId, String id, {bool? visible, Map<String, dynamic>? data}) async {
    final current = state[salonId];
    if (current == null) return;
    final updatedBlocks = current.template.blocks.map((b) {
      if (b.id != id) return b;
      return b.copyWith(visible: visible ?? b.visible, data: data ?? b.data);
    }).toList();
    await _save(salonId, current.template.copyWith(blocks: updatedBlocks));
  }

  Future<void> _save(String salonId, SalonTemplate template) async {
    await _repo.saveTemplate(salonId, template);
    final current = state[salonId];
    if (current == null) return;
    state = {
      ...state,
      salonId: current.copyWith(template: template),
    };
  }
}

final templateStoreProvider = NotifierProvider<TemplateStore, Map<String, TemplateState>>(TemplateStore.new);

final salonTemplateProvider = Provider.family<TemplateState?, String>((ref, salonId) {
  // Trigger load on first watch
  ref.read(templateStoreProvider.notifier).ensureLoaded(salonId);
  final map = ref.watch(templateStoreProvider);
  return map[salonId];
});

class TemplateState {
  final String salonId;
  final SalonTemplate template;
  final bool isLoading;
  final String? error;

  const TemplateState({
    required this.salonId,
    required this.template,
    this.isLoading = false,
    this.error,
  });

  TemplateState copyWith({
    SalonTemplate? template,
    bool? isLoading,
    String? error,
  }) => TemplateState(
        salonId: salonId,
        template: template ?? this.template,
        isLoading: isLoading ?? this.isLoading,
        error: error,
      );
}
