import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../salon_templates/entities.dart';

abstract class TemplateRepository {
  Future<SalonTemplate> getTemplate(String salonId);
  Future<void> saveTemplate(String salonId, SalonTemplate template);
}

class InMemoryTemplateRepository implements TemplateRepository {
  final Map<String, SalonTemplate> _cache = {};
  static const _prefsPrefix = 'templates/';

  @override
  Future<SalonTemplate> getTemplate(String salonId) async {
    if (_cache.containsKey(salonId)) return _cache[salonId]!;

    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('$_prefsPrefix$salonId');
    if (raw != null) {
      try {
        final jsonMap = jsonDecode(raw) as Map<String, dynamic>;
        final t = SalonTemplate.fromJson(jsonMap);
        _cache[salonId] = t;
        return t;
      } catch (_) {
        // fall through to default
      }
    }
    final def = SalonTemplate.defaultForDemo();
    _cache[salonId] = def;
    return def;
  }

  @override
  Future<void> saveTemplate(String salonId, SalonTemplate template) async {
    _cache[salonId] = template;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('$_prefsPrefix$salonId', jsonEncode(template.toJson()));
  }
}
