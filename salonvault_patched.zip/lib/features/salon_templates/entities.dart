import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';

/// Layout block types supported by Salon templates
enum LayoutBlockType { info, services, team, promo, gallery }

class LayoutBlock {
  final String id;
  final LayoutBlockType type;
  final int order;
  final bool visible;
  final Map<String, dynamic> data; // arbitrary settings like title, subtitle, cta

  const LayoutBlock({
    required this.id,
    required this.type,
    required this.order,
    this.visible = true,
    this.data = const {},
  });

  LayoutBlock copyWith({
    String? id,
    LayoutBlockType? type,
    int? order,
    bool? visible,
    Map<String, dynamic>? data,
  }) => LayoutBlock(
        id: id ?? this.id,
        type: type ?? this.type,
        order: order ?? this.order,
        visible: visible ?? this.visible,
        data: data ?? this.data,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'order': order,
        'visible': visible,
        'data': data,
      };

  factory LayoutBlock.fromJson(Map<String, dynamic> json) => LayoutBlock(
        id: json['id'] as String,
        type: LayoutBlockType.values.firstWhere((e) => e.name == json['type']),
        order: json['order'] as int,
        visible: json['visible'] as bool? ?? true,
        data: (json['data'] as Map?)?.cast<String, dynamic>() ?? const {},
      );
}

/// Branding tokens per salon
class SalonThemeTokens {
  final Color primary;
  final Color accent;
  final bool dark;
  final String? logoBase64; // Stored locally for demo; could be URL later

  const SalonThemeTokens({
    required this.primary,
    required this.accent,
    required this.dark,
    this.logoBase64,
  });

  SalonThemeTokens copyWith({
    Color? primary,
    Color? accent,
    bool? dark,
    String? logoBase64,
  }) => SalonThemeTokens(
        primary: primary ?? this.primary,
        accent: accent ?? this.accent,
        dark: dark ?? this.dark,
        logoBase64: logoBase64 ?? this.logoBase64,
      );

  Map<String, dynamic> toJson() => {
        'primary': _colorToHex(primary),
        'accent': _colorToHex(accent),
        'dark': dark,
        'logo': logoBase64,
      };

  factory SalonThemeTokens.fromJson(Map<String, dynamic> json) => SalonThemeTokens(
        primary: _hexToColor(json['primary'] as String? ?? '#FFD700'),
        accent: _hexToColor(json['accent'] as String? ?? '#000000'),
        dark: json['dark'] as bool? ?? false,
        logoBase64: json['logo'] as String?,
      );

  static String _colorToHex(Color c) => '#${c.value.toRadixString(16).padLeft(8, '0')}';
  static Color _hexToColor(String hex) {
    var v = hex.replaceAll('#', '');
    if (v.length == 6) v = 'ff$v';
    return Color(int.parse(v, radix: 16));
  }
}

/// Root template object per salon
class SalonTemplate {
  final SalonThemeTokens tokens;
  final List<LayoutBlock> blocks;

  const SalonTemplate({required this.tokens, required this.blocks});

  SalonTemplate copyWith({SalonThemeTokens? tokens, List<LayoutBlock>? blocks}) =>
      SalonTemplate(tokens: tokens ?? this.tokens, blocks: blocks ?? this.blocks);

  Map<String, dynamic> toJson() => {
        'tokens': tokens.toJson(),
        'blocks': blocks.map((b) => b.toJson()).toList(),
      };

  factory SalonTemplate.fromJson(Map<String, dynamic> json) => SalonTemplate(
        tokens: SalonThemeTokens.fromJson(json['tokens'] as Map<String, dynamic>),
        blocks: ((json['blocks'] as List? ?? const [])
                .whereType<Map>()
                .map((e) => e.cast<String, dynamic>()))
            .map(LayoutBlock.fromJson)
            .toList(),
      );

  static SalonTemplate defaultForDemo() {
    return SalonTemplate(
      tokens: const SalonThemeTokens(
        primary: Color(0xFFFFD700), // gold
        accent: Color(0xFF000000), // black
        dark: false,
      ),
      blocks: const [
        LayoutBlock(id: 'info', type: LayoutBlockType.info, order: 0, visible: true, data: {'title': 'Über uns'}),
        LayoutBlock(id: 'services', type: LayoutBlockType.services, order: 1, visible: true, data: {'title': 'Services'}),
        LayoutBlock(id: 'team', type: LayoutBlockType.team, order: 2, visible: true, data: {'title': 'Team'}),
        LayoutBlock(id: 'promo', type: LayoutBlockType.promo, order: 3, visible: true, data: {'title': 'Aktionen'}),
        LayoutBlock(id: 'gallery', type: LayoutBlockType.gallery, order: 4, visible: true, data: {'title': 'Galerie'}),
      ],
    );
  }
}

/// Helper to base64 encode/decode logo bytes
String? imageBytesToBase64(Uint8List? bytes) => bytes == null ? null : base64Encode(bytes);
Uint8List? base64ToImageBytes(String? b64) => b64 == null ? null : base64Decode(b64);
