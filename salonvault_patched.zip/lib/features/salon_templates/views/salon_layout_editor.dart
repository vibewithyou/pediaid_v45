import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/features/salon_templates/entities.dart';
import 'package:salonvault/features/salon_templates/state/template_state.dart';

class SalonLayoutEditor extends ConsumerWidget {
  const SalonLayoutEditor({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentSalonId = ref.watch(selectedSalonProvider);
    if (currentSalonId == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Layout')),
        body: const Center(child: Text('Bitte zuerst einen Salon auswählen.')),
      );
    }

    final state = ref.watch(salonTemplateProvider(currentSalonId));
    if (state == null || state.isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final blocks = [...state.template.blocks]..sort((a, b) => a.order.compareTo(b.order));
    return Scaffold(
          appBar: AppBar(title: const Text('Layout')),
          body: ReorderableListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: blocks.length,
            onReorder: (oldIndex, newIndex) {
              final updated = [...blocks];
              if (newIndex > oldIndex) newIndex -= 1;
              final item = updated.removeAt(oldIndex);
              updated.insert(newIndex, item);
              ref.read(templateStoreProvider.notifier).reorderBlocks(currentSalonId, updated);
            },
            itemBuilder: (context, index) {
              final b = blocks[index];
              return Card(
                key: ValueKey(b.id),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.drag_indicator),
                          const SizedBox(width: 8),
                          Expanded(child: Text(_labelFor(b.type), style: Theme.of(context).textTheme.headlineMedium)),
                          Switch(value: b.visible, onChanged: (v) => ref.read(templateStoreProvider.notifier).updateBlock(currentSalonId, b.id, visible: v)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      _BlockEditor(
                        block: b,
                        onChanged: (data) => ref.read(templateStoreProvider.notifier).updateBlock(currentSalonId, b.id, data: data),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        );
  }

  String _labelFor(LayoutBlockType t) {
    switch (t) {
      case LayoutBlockType.info:
        return 'Info';
      case LayoutBlockType.services:
        return 'Services';
      case LayoutBlockType.team:
        return 'Team';
      case LayoutBlockType.promo:
        return 'Aktionen';
      case LayoutBlockType.gallery:
        return 'Galerie';
    }
  }
}

class _BlockEditor extends StatefulWidget {
  final LayoutBlock block;
  final void Function(Map<String, dynamic>) onChanged;
  const _BlockEditor({required this.block, required this.onChanged});

  @override
  State<_BlockEditor> createState() => _BlockEditorState();
}

class _BlockEditorState extends State<_BlockEditor> {
  late TextEditingController title;
  late TextEditingController subtitle;
  late TextEditingController ctaLabel;
  late TextEditingController ctaRoute;

  @override
  void initState() {
    super.initState();
    title = TextEditingController(text: widget.block.data['title'] as String? ?? '');
    subtitle = TextEditingController(text: widget.block.data['subtitle'] as String? ?? '');
    ctaLabel = TextEditingController(text: widget.block.data['ctaLabel'] as String? ?? '');
    ctaRoute = TextEditingController(text: widget.block.data['ctaRoute'] as String? ?? '');
  }

  @override
  void dispose() {
    title.dispose();
    subtitle.dispose();
    ctaLabel.dispose();
    ctaRoute.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(
          controller: title,
          decoration: const InputDecoration(labelText: 'Titel'),
          onChanged: (_) => _commit(),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: subtitle,
          decoration: const InputDecoration(labelText: 'Untertitel'),
          onChanged: (_) => _commit(),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: ctaLabel,
                decoration: const InputDecoration(labelText: 'CTA Label'),
                onChanged: (_) => _commit(),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: ctaRoute,
                decoration: const InputDecoration(labelText: 'CTA Route (z.B. /booking)'),
                onChanged: (_) => _commit(),
              ),
            )
          ],
        )
      ],
    );
  }

  void _commit() {
    widget.onChanged({
      ...widget.block.data,
      'title': title.text,
      'subtitle': subtitle.text,
      'ctaLabel': ctaLabel.text,
      'ctaRoute': ctaRoute.text,
    });
  }
}
