import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

/// Editor for the "Über uns" section and team members of a salon.
///
/// Allows salon owners/managers to write a brief description and
/// manage a list of team members (name, role, biography, optional
/// photo). Data is saved per salon using SharedPreferences. Later
/// this should be moved to the backend.
class AboutTeamEditor extends ConsumerStatefulWidget {
  const AboutTeamEditor({super.key});

  @override
  ConsumerState<AboutTeamEditor> createState() => _AboutTeamEditorState();
}

class _AboutTeamEditorState extends ConsumerState<AboutTeamEditor> {
  final _aboutController = TextEditingController();
  List<Map<String, dynamic>> _team = [];
  String? _salonId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      _salonId = ref.read(selectedSalonProvider);
      if (_salonId != null) {
        await _load();
      }
    });
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final id = _salonId!;
    _aboutController.text = prefs.getString('about_us_$id') ?? '';
    final teamJson = prefs.getString('team_members_$id');
    if (teamJson != null) {
      try {
        final List decoded = jsonDecode(teamJson) as List;
        setState(() {
          _team = decoded.cast<Map<String, dynamic>>();
        });
      } catch (_) {
        // ignore malformed data
      }
    }
  }

  Future<void> _save() async {
    final id = _salonId;
    if (id == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bitte wählen Sie zuerst einen Salon aus.')), 
      );
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('about_us_$id', _aboutController.text);
    await prefs.setString('team_members_$id', jsonEncode(_team));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Über uns & Team gespeichert')), 
    );
  }

  Future<void> _addOrEditMember({Map<String, dynamic>? member, int? index}) async {
    final nameCtrl = TextEditingController(text: member?['name'] ?? '');
    final roleCtrl = TextEditingController(text: member?['role'] ?? '');
    final bioCtrl = TextEditingController(text: member?['bio'] ?? '');
    String? imageBase64 = member?['image'] as String?;
    await showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: Text(member == null ? 'Teammitglied hinzufügen' : 'Teammitglied bearbeiten'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameCtrl,
                      decoration: const InputDecoration(labelText: 'Name'),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: roleCtrl,
                      decoration: const InputDecoration(labelText: 'Rolle'),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: bioCtrl,
                      decoration: const InputDecoration(labelText: 'Beschreibung'),
                      maxLines: 3,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        if (imageBase64 != null)
                          Container(
                            width: 60,
                            height: 60,
                            margin: const EdgeInsets.only(right: 12),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade300),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Image.memory(base64Decode(imageBase64), fit: BoxFit.cover),
                          ),
                        ElevatedButton.icon(
                          onPressed: () async {
                            final picker = ImagePicker();
                            final picked = await picker.pickImage(source: ImageSource.gallery);
                            if (picked != null) {
                              final bytes = await picked.readAsBytes();
                              setStateDialog(() {
                                imageBase64 = base64Encode(bytes);
                              });
                            }
                          },
                          icon: const Icon(Icons.upload),
                          label: Text(imageBase64 == null ? 'Foto wählen' : 'Foto ändern'),
                        ),
                        if (imageBase64 != null)
                          IconButton(
                            onPressed: () {
                              setStateDialog(() {
                                imageBase64 = null;
                              });
                            },
                            icon: const Icon(Icons.delete),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Abbrechen'),
                ),
                ElevatedButton(
                  onPressed: () {
                    final newMember = <String, dynamic>{
                      'name': nameCtrl.text.trim(),
                      'role': roleCtrl.text.trim(),
                      'bio': bioCtrl.text.trim(),
                      'image': imageBase64,
                    };
                    setState(() {
                      if (index != null) {
                        _team[index] = newMember;
                      } else {
                        _team.add(newMember);
                      }
                    });
                    Navigator.of(context).pop();
                  },
                  child: const Text('Speichern'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _aboutController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final id = ref.watch(selectedSalonProvider);
    final local = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(local.translate('about_us_team_title'))),
      body: id == null
          ? Center(child: Text(local.translate('please_select_salon')))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(local.translate('about_us'), style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 8),
                LuxuryInput(
                  controller: _aboutController,
                  hintText: local.translate('description_placeholder'),
                  maxLines: 6,
                ),
                const SizedBox(height: 24),
                Text(local.translate('team'), style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 8),
                ..._team.asMap().entries.map((entry) {
                  final idx = entry.key;
                  final m = entry.value;
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: m['image'] != null
                          ? CircleAvatar(backgroundImage: MemoryImage(base64Decode(m['image'])))
                          : const CircleAvatar(child: Icon(Icons.person)),
                      title: Text(m['name'] ?? ''),
                      subtitle: Text(m['role'] ?? ''),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: () => _addOrEditMember(member: m, index: idx),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () {
                              setState(() {
                                _team.removeAt(idx);
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                }),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: ElevatedButton.icon(
                    onPressed: () => _addOrEditMember(),
                    icon: const Icon(Icons.add),
                    label: Text(local.translate('add_team_member')),
                  ),
                ),
                const SizedBox(height: 32),
                LuxuryButton(
                  filled: true,
                  label: local.translate('save'),
                  onPressed: _save,
                ),
              ],
            ),
    );
  }
}