import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/features/salon_templates/entities.dart';
import 'package:salonvault/features/salon_templates/state/template_state.dart';

class SalonBrandingEditor extends ConsumerWidget {
  const SalonBrandingEditor({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentSalonId = ref.watch(selectedSalonProvider);
    if (currentSalonId == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Branding')),
        body: const Center(child: Text('Bitte zuerst einen Salon auswählen.')),
      );
    }

    final state = ref.watch(salonTemplateProvider(currentSalonId));
    if (state == null || state.isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final tokens = state.template.tokens;
    return Scaffold(
          appBar: AppBar(title: const Text('Branding')), 
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _PreviewCard(tokens: tokens),
              const SizedBox(height: 16),
              _ColorSection(
                label: 'Primärfarbe',
                selected: tokens.primary,
                onSelect: (c) => ref.read(templateStoreProvider.notifier).setPrimary(currentSalonId, c),
              ),
              const SizedBox(height: 12),
              _ColorSection(
                label: 'Akzentfarbe',
                selected: tokens.accent,
                onSelect: (c) => ref.read(templateStoreProvider.notifier).setAccent(currentSalonId, c),
              ),
              const SizedBox(height: 24),
              SwitchListTile(
                title: const Text('Dunkles Design'),
                value: tokens.dark,
                onChanged: (v) => ref.read(templateStoreProvider.notifier).setDark(currentSalonId, v),
              ),
              const SizedBox(height: 16),
              _LogoUploader(
                base64Logo: tokens.logoBase64,
                onPick: (b64) => ref.read(templateStoreProvider.notifier).setLogo(currentSalonId, b64),
                onClear: () => ref.read(templateStoreProvider.notifier).setLogo(currentSalonId, null),
              ),
            ],
          ),
        );
  }
}

class _PreviewCard extends StatelessWidget {
  final SalonThemeTokens tokens;
  const _PreviewCard({required this.tokens});

  @override
  Widget build(BuildContext context) {
    final textColor = tokens.dark ? Colors.white : Colors.black;
    return Card(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [tokens.primary, tokens.accent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            if (tokens.logoBase64 != null)
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Image.memory(
                  base64ToImageBytes(tokens.logoBase64!)!,
                  width: 56,
                  height: 56,
                  fit: BoxFit.contain,
                ),
              ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Vorschau', style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: textColor)),
                  const SizedBox(height: 4),
                  Text('Buttons, Texte und Highlights passen sich an.', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: textColor.withValues(alpha: 0.8))),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, children: [
                    ElevatedButton(onPressed: () {}, child: const Text('Primary CTA')),
                    OutlinedButton(onPressed: () {}, child: const Text('Secondary')),
                  ]),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class _ColorSection extends StatelessWidget {
  final String label;
  final Color selected;
  final void Function(Color) onSelect;
  const _ColorSection({required this.label, required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final swatches = <Color>[
      const Color(0xFFFFD700),
      const Color(0xFF000000),
      const Color(0xFFFFFFFF),
      Colors.blue,
      Colors.green,
      Colors.pink,
      Colors.purple,
      Colors.teal,
      Colors.orange,
      Colors.brown,
      Colors.indigo,
      Colors.red,
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: swatches
              .map((c) => GestureDetector(
                    onTap: () => onSelect(c),
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: c,
                        shape: BoxShape.circle,
                        border: Border.all(color: selected == c ? Colors.amber : Colors.grey, width: selected == c ? 3 : 1),
                      ),
                    ),
                  ))
              .toList(),
        )
      ],
    );
  }
}

class _LogoUploader extends StatelessWidget {
  final String? base64Logo;
  final void Function(String?) onPick;
  final VoidCallback onClear;
  const _LogoUploader({required this.base64Logo, required this.onPick, required this.onClear});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Logo', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Row(
              children: [
                if (base64Logo != null)
                  Container(
                    width: 64,
                    height: 64,
                    margin: const EdgeInsets.only(right: 12),
                    decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8)),
                    child: Image.memory(base64ToImageBytes(base64Logo!)!, fit: BoxFit.contain),
                  ),
                ElevatedButton.icon(
                  onPressed: () async {
                    final res = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
                    if (res != null && res.files.single.bytes != null) {
                      final Uint8List bytes = res.files.single.bytes!;
                      onPick(imageBytesToBase64(bytes));
                    }
                  },
                  icon: const Icon(Icons.upload),
                  label: const Text('Logo hochladen'),
                ),
                const SizedBox(width: 8),
                if (base64Logo != null)
                  OutlinedButton.icon(onPressed: onClear, icon: const Icon(Icons.delete, color: Colors.red), label: const Text('Entfernen')),
              ],
            )
          ],
        ),
      ),
    );
  }
}
