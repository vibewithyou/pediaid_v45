import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A simple gallery editor that allows salon managers to upload and manage
/// multiple images associated with their salon. Images are stored locally
/// as base64 strings using [SharedPreferences] under the key
/// `gallery_<salonId>`. This editor is intended for demonstration
/// purposes and does not upload images to a remote server.
class SalonGalleryEditor extends ConsumerStatefulWidget {
  const SalonGalleryEditor({super.key});

  @override
  ConsumerState<SalonGalleryEditor> createState() => _SalonGalleryEditorState();
}

class _SalonGalleryEditorState extends ConsumerState<SalonGalleryEditor> {
  List<String> _images = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadGallery();
  }

  Future<void> _loadGallery() async {
    final prefs = await SharedPreferences.getInstance();
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) {
      setState(() {
        _isLoading = false;
      });
      return;
    }
    final listString = prefs.getString('gallery_$salonId');
    if (listString != null) {
      final List<dynamic> decoded = json.decode(listString) as List<dynamic>;
      _images = decoded.whereType<String>().toList();
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _saveGallery() async {
    final prefs = await SharedPreferences.getInstance();
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    await prefs.setString('gallery_$salonId', json.encode(_images));
  }

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
    if (result != null && result.files.single.bytes != null) {
      final Uint8List bytes = result.files.single.bytes!;
      final String b64 = base64Encode(bytes);
      setState(() {
        _images.add(b64);
      });
      await _saveGallery();
    }
  }

  Future<void> _removeImage(int index) async {
    setState(() {
      _images.removeAt(index);
    });
    await _saveGallery();
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final salonId = ref.watch(selectedSalonProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(l.translate('gallery_title')),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : salonId == null
              ? Center(child: Text(l.translate('please_select_salon')))
              : _images.isEmpty
                  ? Center(child: Text(l.translate('gallery_empty')))
                  : GridView.builder(
                      padding: const EdgeInsets.all(16),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: 1,
                      ),
                      itemCount: _images.length,
                      itemBuilder: (context, index) {
                        final b64 = _images[index];
                        return Stack(
                          fit: StackFit.expand,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.memory(
                                base64Decode(b64),
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ),
                            Positioned(
                              top: 8,
                              right: 8,
                              child: GestureDetector(
                                onTap: () => _removeImage(index),
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: Colors.black54,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(Icons.delete, size: 20, color: Colors.white, semanticLabel: l.translate('delete')),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
      floatingActionButton: salonId == null
          ? null
          : FloatingActionButton.extended(
              onPressed: _pickImage,
              icon: const Icon(Icons.add_photo_alternate),
              label: Text(l.translate('add_image')),
            ),
    );
  }
}