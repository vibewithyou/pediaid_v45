import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';

class ManageDashboardScreen extends StatelessWidget {
  const ManageDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Manage • Dashboard')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: const [
              _LuxuryKpiCard(title: "Today's Appointments", value: '12'),
              _LuxuryKpiCard(title: 'Utilization', value: '78%'),
              _LuxuryKpiCard(title: 'Revenue', value: '€1,420'),
              _LuxuryKpiCard(title: 'Active Promotions', value: '3'),
              _LuxuryKpiCard(title: 'Cancelled', value: '1'),
              _LuxuryKpiCard(title: 'No‑Show Rate', value: '5%'),
              _LuxuryKpiCard(title: 'Avg Ticket', value: '€68'),
              _LuxuryKpiCard(title: 'Peak Hours', value: '09–11'),
              _LuxuryKpiCard(title: 'Gold Members', value: '42%'),
            ],
          ),
          const SizedBox(height: 24),
          // Simple bar chart placeholder for weekly revenue
          SizedBox(
            height: 220,
            child: LuxuryCard(
              title: 'Weekly Revenue',
              subtitle: null,
              leading: const Icon(Icons.show_chart, color: AppColors.gold),
              onTap: null,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 120,
            child: _FakeBarChart(),
          ),
          const SizedBox(height: 24),
          // Peak Hours bar chart
          SizedBox(
            height: 220,
            child: LuxuryCard(
              title: 'Peak Hours (Today)',
              subtitle: null,
              leading: const Icon(Icons.bar_chart, color: AppColors.gold),
              onTap: null,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 120,
            child: _PeakHourChart(),
          ),
          const SizedBox(height: 24),
          // Occupancy heatmap
          Text('Utilization Heatmap', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          _UtilizationHeatmap(),
          const SizedBox(height: 24),
          Text('Today', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          ...List.generate(5, (i) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: LuxuryCard(
                  leading: const Icon(Icons.event_available, color: AppColors.gold),
                  title: 'Customer #$i',
                  subtitle: 'Haircut • 14:00 - 15:00',
                  trailing: Text('€65', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.gold)),
                  onTap: () {
                    // TODO(tobiasbecker2025): navigate to appointment detail
                  },
                ),
              )),
          const SizedBox(height: 24),
          Text('Shortcuts', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              LuxuryCard(
                leading: const Icon(Icons.schedule, color: AppColors.gold),
                title: 'Scheduling',
                subtitle: 'Manage shifts',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/scheduling');
                },
              ),
              LuxuryCard(
                leading: const Icon(Icons.people, color: AppColors.gold),
                title: 'Customers',
                subtitle: 'Customer records',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/customers');
                },
              ),
              LuxuryCard(
                leading: const Icon(Icons.inventory_2, color: AppColors.gold),
                title: 'Inventory',
                subtitle: 'Stock & Suppliers',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/inventory');
                },
              ),
              LuxuryCard(
                leading: const Icon(Icons.campaign, color: AppColors.gold),
                title: 'Campaigns',
                subtitle: 'Promotions & Deals',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/campaigns');
                },
              ),
              LuxuryCard(
                leading: const Icon(Icons.design_services, color: AppColors.gold),
                title: 'Services',
                subtitle: 'Price list',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/services');
                },
              ),
              LuxuryCard(
                leading: const Icon(Icons.percent, color: AppColors.gold),
                title: 'Promotions',
                subtitle: 'Discounts & actions',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/promotions');
                },
              ),
              LuxuryCard(
                leading: const Icon(Icons.palette, color: AppColors.gold),
                title: 'Salon Designer',
                subtitle: 'Brand & Layout',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/designer');
                },
              ),
              // Staff extras quick link
              LuxuryCard(
                leading: const Icon(Icons.manage_accounts, color: AppColors.gold),
                title: 'Staff Extras',
                subtitle: 'Absences & Time',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/staff');
                },
              ),
              // Gift cards & Bundles quick link
              LuxuryCard(
                leading: const Icon(Icons.card_giftcard, color: AppColors.gold),
                title: 'Gift Cards',
                subtitle: 'Bundles & Vouchers',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/loyalty/gifts');
                },
              ),

              // Notification templates quick link
              LuxuryCard(
                leading: const Icon(Icons.email_outlined, color: AppColors.gold),
                title: 'Templates',
                subtitle: 'Email/Push/SMS',
                onTap: () {
                  Navigator.pushNamed(context, '/manage/templates/notifications');
                },
              ),
            ],
          ),

          const SizedBox(height: 24),
          Text('Quick Actions', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              LuxuryButton(
                label: 'Create Campaign',
                filled: false,
                onPressed: () {
                  // TODO(tobiasbecker2025): open campaign creation dialog
                },
              ),
              LuxuryButton(
                label: 'Order Stock',
                filled: false,
                onPressed: () {
                  Navigator.pushNamed(context, '/manage/inventory/orders');
                },
              ),
              LuxuryButton(
                label: 'New Shift',
                filled: false,
                onPressed: () {
                  Navigator.pushNamed(context, '/manage/scheduling');
                },
              ),
              LuxuryButton(
                label: 'Export Report PDF',
                filled: false,
                onPressed: () {
                  // TODO(tobiasbecker2025): generate report PDF
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Report PDF generated (mock)')));
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// KPI tile using LuxuryCard. Displays a metric name and its current value.
class _LuxuryKpiCard extends StatelessWidget {
  final String title;
  final String value;
  const _LuxuryKpiCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 200,
      child: LuxuryCard(
        leading: const Icon(Icons.assessment, color: AppColors.gold),
        title: value,
        subtitle: title,
      ),
    );
  }
}

/// Simple bar chart widget using colored bars. Replace with a real chart later.
class _FakeBarChart extends StatelessWidget {
  const _FakeBarChart();

  @override
  Widget build(BuildContext context) {
    // Example data for 7 days: values between 0 and 1
    final values = [0.6, 0.8, 0.4, 0.7, 0.9, 0.5, 0.3];
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: values.map((v) {
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Container(
              height: 100 * v + 20, // min height 20
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    Theme.of(context).colorScheme.primary.withOpacity(0.8),
                    Theme.of(context).colorScheme.primary.withOpacity(0.4),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// A simple bar chart representing peak hours of the day. Uses five
/// bars to visualize booking intensity at different time ranges.
class _PeakHourChart extends StatelessWidget {
  const _PeakHourChart();

  @override
  Widget build(BuildContext context) {
    // Example values for five time slots (e.g. 8–10, 10–12, ...)
    final values = [0.2, 0.6, 0.9, 0.5, 0.3];
    final labels = ['8–10', '10–12', '12–14', '14–16', '16–18'];
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(values.length, (i) {
        final v = values[i];
        return Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 90 * v + 20,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      Theme.of(context).colorScheme.primary.withOpacity(0.8),
                      Theme.of(context).colorScheme.primary.withOpacity(0.4),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text(labels[i], style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        );
      }),
    );
  }
}

/// Heatmap widget representing utilization across a week (rows) and day parts (columns).
class _UtilizationHeatmap extends StatelessWidget {
  const _UtilizationHeatmap();

  @override
  Widget build(BuildContext context) {
    // Example data: 7 days (rows) x 5 slots (columns)
    final data = [
      [0.2, 0.4, 0.6, 0.8, 0.5],
      [0.1, 0.3, 0.5, 0.7, 0.6],
      [0.4, 0.6, 0.9, 0.8, 0.7],
      [0.3, 0.5, 0.7, 0.4, 0.2],
      [0.5, 0.7, 0.8, 0.9, 0.6],
      [0.2, 0.4, 0.6, 0.5, 0.3],
      [0.1, 0.2, 0.3, 0.4, 0.2],
    ];
    return Column(
      children: data.map((row) {
        return Row(
          children: row.map((v) {
            return Expanded(
              child: Container(
                margin: const EdgeInsets.all(2),
                height: 20,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.2 + v * 0.6),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            );
          }).toList(),
        );
      }).toList(),
    );
  }
}

// Hidden copyright marker for legal protection.
// ignore: unused_element
const _tobiasBecker2025 = 'tobiasbecker2025';
