import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';

/// Data model representing a marketing campaign. Each campaign has a
/// title, description, optional start and end dates and an active flag.
class Campaign {
  String title;
  String description;
  DateTime? startDate;
  DateTime? endDate;
  bool active;

  Campaign({
    required this.title,
    required this.description,
    this.startDate,
    this.endDate,
    this.active = true,
  });

  factory Campaign.fromMap(Map<String, dynamic> map) {
    return Campaign(
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      startDate: map['startDate'] != null ? DateTime.parse(map['startDate']) : null,
      endDate: map['endDate'] != null ? DateTime.parse(map['endDate']) : null,
      active: map['active'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'startDate': startDate?.toIso8601String(),
      'endDate': endDate?.toIso8601String(),
      'active': active,
    };
  }
}

/// Screen allowing salon managers to create and manage marketing campaigns.
/// Campaigns are persisted per salon using SharedPreferences. Users can
/// add new campaigns, toggle their active status and delete them.
class CampaignsScreen extends ConsumerStatefulWidget {
  const CampaignsScreen({super.key});

  @override
  ConsumerState<CampaignsScreen> createState() => _CampaignsScreenState();
}

class _CampaignsScreenState extends ConsumerState<CampaignsScreen> {
  final List<Campaign> _campaigns = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadCampaigns());
  }

  /// Loads campaigns from SharedPreferences for the selected salon.
  Future<void> _loadCampaigns() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'campaigns_$salonId';
    final jsonStr = prefs.getString(key);
    if (jsonStr != null) {
      final List<dynamic> decoded = jsonDecode(jsonStr);
      setState(() {
        _campaigns.clear();
        _campaigns.addAll(decoded.map((e) => Campaign.fromMap(Map<String, dynamic>.from(e))));
      });
    }
  }

  /// Saves campaigns to SharedPreferences for the selected salon.
  Future<void> _saveCampaigns() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'campaigns_$salonId';
    final jsonStr = jsonEncode(_campaigns.map((c) => c.toMap()).toList());
    await prefs.setString(key, jsonStr);
  }

  void _toggleActive(int index, bool value) {
    setState(() {
      _campaigns[index].active = value;
    });
    _saveCampaigns();
  }

  void _deleteCampaign(int index) {
    setState(() {
      _campaigns.removeAt(index);
    });
    _saveCampaigns();
  }

  /// Shows a dialog to create a new campaign. Includes fields for title,
  /// description, optional start/end dates and an active toggle.
  void _showAddCampaignDialog() {
    final l = AppLocalizations.of(context);
    String title = '';
    String description = '';
    DateTime? startDate;
    DateTime? endDate;
    bool active = true;
    Future<void> pickDate({required bool isStart}) async {
      final now = DateTime.now();
      final initialDate = isStart ? now : (startDate ?? now);
      final picked = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: DateTime(now.year - 1),
        lastDate: DateTime(now.year + 5),
      );
      if (picked != null) {
        setState(() {});
        if (isStart) {
          startDate = picked;
        } else {
          endDate = picked;
        }
      }
    }
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text(l.translate('new_campaign')),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      decoration: InputDecoration(
                        labelText: l.translate('campaign_title'),
                        hintText: l.translate('campaign_title'),
                      ),
                      onChanged: (v) => title = v,
                    ),
                    TextField(
                      decoration: InputDecoration(
                        labelText: l.translate('campaign_description'),
                        hintText: l.translate('campaign_description'),
                      ),
                      minLines: 1,
                      maxLines: 3,
                      onChanged: (v) => description = v,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () async {
                              final now = DateTime.now();
                              final picked = await showDatePicker(
                                context: context,
                                initialDate: startDate ?? now,
                                firstDate: DateTime(now.year - 1),
                                lastDate: DateTime(now.year + 5),
                              );
                              if (picked != null) {
                                setState(() => startDate = picked);
                              }
                            },
                            child: Text(startDate == null
                                ? l.translate('start_date')
                                : '${startDate!.day.toString().padLeft(2, '0')}.${startDate!.month.toString().padLeft(2, '0')}.${startDate!.year}'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () async {
                              final now = DateTime.now();
                              final initial = endDate ?? startDate ?? now;
                              final picked = await showDatePicker(
                                context: context,
                                initialDate: initial,
                                firstDate: DateTime(now.year - 1),
                                lastDate: DateTime(now.year + 5),
                              );
                              if (picked != null) {
                                setState(() => endDate = picked);
                              }
                            },
                            child: Text(endDate == null
                                ? l.translate('end_date')
                                : '${endDate!.day.toString().padLeft(2, '0')}.${endDate!.month.toString().padLeft(2, '0')}.${endDate!.year}'),
                          ),
                        ),
                      ],
                    ),
                    SwitchListTile(
                      title: Text(l.translate('active')),
                      value: active,
                      onChanged: (val) => setState(() => active = val),
                      activeColor: AppColors.gold,
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(l.translate('cancel')),
                ),
                ElevatedButton(
                  onPressed: () {
                    final trimmedTitle = title.trim();
                    final trimmedDesc = description.trim();
                    if (trimmedTitle.isEmpty || trimmedDesc.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(l.translate('error_fill_fields'))),
                      );
                      return;
                    }
                    setState(() {
                      _campaigns.add(Campaign(
                        title: trimmedTitle,
                        description: trimmedDesc,
                        startDate: startDate,
                        endDate: endDate,
                        active: active,
                      ));
                    });
                    _saveCampaigns();
                    Navigator.pop(context);
                  },
                  child: Text(l.translate('save')),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l.translate('campaigns_title'))),
      body: _campaigns.isEmpty
          ? Center(
              child: Text(
                l.translate('no_campaigns'),
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _campaigns.length,
              itemBuilder: (context, i) {
                final c = _campaigns[i];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: LuxuryCard(
                    leading: Icon(
                      Icons.local_offer,
                      color: c.active ? AppColors.successGreen : AppColors.textGrey,
                    ),
                    title: c.title,
                    subtitle: c.description,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Switch(
                          value: c.active,
                          onChanged: (val) => _toggleActive(i, val),
                          activeColor: AppColors.gold,
                          activeTrackColor: AppColors.gold.withOpacity(0.3),
                          inactiveThumbColor: AppColors.mediumGrey,
                          inactiveTrackColor: AppColors.mediumGrey.withOpacity(0.3),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Theme.of(context).colorScheme.error),
                          tooltip: l.translate('delete_campaign'),
                          onPressed: () => _deleteCampaign(i),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddCampaignDialog,
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.black,
        icon: const Icon(Icons.add),
        label: Text(l.translate('new_campaign')),
      ),
    );
  }
}