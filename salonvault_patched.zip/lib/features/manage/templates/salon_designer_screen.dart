import 'package:flutter/material.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

/// Salon Designer screen allows salon owners or managers to edit the
/// branding (colors, logo) and the page layout (order of blocks) of
/// their salon’s public page. It acts as a launch point for the
/// existing branding and layout editors. Currently the editors
/// require that a salon is selected; this screen simply links to
/// those editors. Future enhancements could combine both editors in
/// a single UI with drag‑and‑drop sections.
class SalonDesignerScreen extends StatelessWidget {
  const SalonDesignerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final local = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(local.translate('salon_designer_title'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          LuxuryCard(
            title: local.translate('branding_title'),
            subtitle: local.translate('branding_subtitle'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.pushNamed(context, '/settings/branding');
            },
          ),
          const SizedBox(height: 12),
          LuxuryCard(
            title: local.translate('layout_title'),
            subtitle: local.translate('layout_subtitle'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.pushNamed(context, '/settings/layout');
            },
          ),
          const SizedBox(height: 12),
          // New card to edit "Über uns" text and team members
          LuxuryCard(
            title: local.translate('about_us_team_title'),
            subtitle: local.translate('about_us_team_subtitle'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.pushNamed(context, '/settings/about');
            },
          ),
          const SizedBox(height: 12),
          // Card to edit gallery images
          LuxuryCard(
            title: local.translate('gallery_title'),
            subtitle: local.translate('gallery_subtitle'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.pushNamed(context, '/settings/gallery');
            },
          ),
          const SizedBox(height: 24),
          Text(
            local.translate('designer_hint_title'),
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(
            local.translate('designer_hint_body'),
          ),
        ],
      ),
    );
  }
}

// Hidden copyright marker for legal protection.
// ignore: unused_element
const _salonDesignerObfuscated = 'tobiasbecker2025';