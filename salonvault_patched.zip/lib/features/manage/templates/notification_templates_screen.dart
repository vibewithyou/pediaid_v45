import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_chip.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';

/// A data model representing a notification template for reminders and
/// confirmations. Each template can be sent via a channel (email,
/// push or SMS) and contains a subject, body and an offset (days
/// before the appointment). Templates are persisted per salon.
class NotificationTemplate {
  String id;
  String name;
  String channel;
  String subject;
  String body;
  int daysBefore;

  NotificationTemplate({
    required this.id,
    required this.name,
    required this.channel,
    required this.subject,
    required this.body,
    required this.daysBefore,
  });

  factory NotificationTemplate.fromMap(Map<String, dynamic> map) {
    return NotificationTemplate(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      channel: map['channel'] ?? 'Email',
      subject: map['subject'] ?? '',
      body: map['body'] ?? '',
      daysBefore: map['daysBefore'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'channel': channel,
      'subject': subject,
      'body': body,
      'daysBefore': daysBefore,
    };
  }
}

/// A screen that allows salon managers to create, edit and delete
/// notification templates (e.g. appointment confirmations, reminders).
/// Data is stored locally in SharedPreferences and will later be
/// integrated with the backend API.
class NotificationTemplatesScreen extends ConsumerStatefulWidget {
  const NotificationTemplatesScreen({super.key});

  @override
  ConsumerState<NotificationTemplatesScreen> createState() => _NotificationTemplatesScreenState();
}

class _NotificationTemplatesScreenState extends ConsumerState<NotificationTemplatesScreen> {
  final List<NotificationTemplate> _templates = [];
  int _idCounter = 1;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadTemplates());
  }

  Future<void> _loadTemplates() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'notification_templates_$salonId';
    final jsonStr = prefs.getString(key);
    if (jsonStr != null) {
      final List<dynamic> decoded = jsonDecode(jsonStr);
      setState(() {
        _templates.clear();
        _templates.addAll(
          decoded.map((e) => NotificationTemplate.fromMap(Map<String, dynamic>.from(e))),
        );
        // update id counter based on max existing id
        for (final t in _templates) {
          final parsed = int.tryParse(t.id);
          if (parsed != null && parsed >= _idCounter) {
            _idCounter = parsed + 1;
          }
        }
      });
    }
  }

  Future<void> _saveTemplates() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'notification_templates_$salonId';
    final jsonStr = jsonEncode(_templates.map((t) => t.toMap()).toList());
    await prefs.setString(key, jsonStr);
  }

  void _deleteTemplate(int index) {
    setState(() {
      _templates.removeAt(index);
    });
    _saveTemplates();
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l.translate('notification_templates_title'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            l.translate('notification_templates_subtitle'),
            style: theme.textTheme.bodyMedium,
          ),
          const SizedBox(height: 24),
          // Existing templates
          if (_templates.isEmpty)
            Center(
              child: Text(l.translate('no_templates')),
            )
          else
            ..._templates.asMap().entries.map((entry) {
              final index = entry.key;
              final t = entry.value;
              // Determine channel icon
              IconData channelIcon;
              if (t.channel == 'Email' || t.channel == 'E-Mail') {
                channelIcon = Icons.email;
              } else if (t.channel == 'SMS') {
                channelIcon = Icons.sms;
              } else {
                channelIcon = Icons.notifications;
              }
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: LuxuryCard(
                  leading: Icon(channelIcon, color: AppColors.gold),
                  title: t.name,
                  subtitle:
                      '${l.translate('template_channel')}: ${_localizedChannel(l, t.channel)} • ${t.daysBefore == 0 ? l.translate('send_same_day') : '${t.daysBefore}${l.translate('days_before_suffix')}'}\n${l.translate('template_subject')}: ${t.subject}',
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: AppColors.gold),
                        onPressed: () => _openTemplateDialog(template: t),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteTemplate(index),
                      ),
                    ],
                  ),
                  onTap: () => _openTemplateDialog(template: t),
                ),
              );
            }),
          const SizedBox(height: 24),
          LuxuryButton(
            label: l.translate('new_template'),
            filled: false,
            onPressed: () => _openTemplateDialog(),
          ),
        ],
      ),
    );
  }

  /// Returns the localized name for the given channel key.
  String _localizedChannel(AppLocalizations l, String channel) {
    switch (channel) {
      case 'Push':
        return l.translate('channel_push');
      case 'SMS':
        return l.translate('channel_sms');
      case 'Email':
      case 'E-Mail':
      default:
        return l.translate('channel_email');
    }
  }

  /// Opens a dialog to create or edit a template. If [template] is null,
  /// a new template will be created. Otherwise the existing one is edited.
  void _openTemplateDialog({NotificationTemplate? template}) {
    final l = AppLocalizations.of(context);
    final isEditing = template != null;
    String name = template?.name ?? '';
    String channel = template?.channel ?? 'Email';
    String subject = template?.subject ?? '';
    String body = template?.body ?? '';
    int daysBefore = template?.daysBefore ?? 0;
    showDialog<void>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text(l.translate(isEditing ? 'edit_template' : 'new_template')),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    LuxuryInput(
                      controller: TextEditingController(text: name),
                      labelText: l.translate('template_name'),
                      onChanged: (v) => name = v,
                    ),
                    const SizedBox(height: 12),
                    // Channel selection using chips
                    Row(
                      children: [
                        for (final ch in ['Email', 'Push', 'SMS'])
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: LuxuryChip(
                              label: Text(_localizedChannel(l, ch)),
                              selected: channel == ch || (channel == 'E-Mail' && ch == 'Email'),
                              onSelected: (_) {
                                setState(() => channel = ch);
                              },
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    LuxuryInput(
                      controller: TextEditingController(text: subject),
                      labelText: l.translate('template_subject'),
                      onChanged: (v) => subject = v,
                    ),
                    const SizedBox(height: 12),
                    // Body field
                    TextField(
                      controller: TextEditingController(text: body),
                      maxLines: 5,
                      decoration: InputDecoration(
                        labelText: l.translate('template_body'),
                        border: const OutlineInputBorder(),
                      ),
                      onChanged: (v) => body = v,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Text(l.translate('days_before')),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Slider(
                            value: daysBefore.toDouble(),
                            min: 0,
                            max: 30,
                            divisions: 30,
                            label: daysBefore.toString(),
                            onChanged: (val) {
                              setState(() => daysBefore = val.toInt());
                            },
                          ),
                        ),
                        SizedBox(
                          width: 32,
                          child: Text(daysBefore.toString(), textAlign: TextAlign.center),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                LuxuryButton(
                  label: l.translate('cancel'),
                  filled: false,
                  onPressed: () => Navigator.pop(context),
                ),
                LuxuryButton(
                  label: l.translate('save'),
                  filled: true,
                  onPressed: () {
                    if (name.trim().isEmpty || subject.trim().isEmpty || body.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(l.translate('error_fill_fields'))),
                      );
                      return;
                    }
                    setState(() {
                      if (isEditing) {
                        // update existing
                        final idx = _templates.indexWhere((t) => t.id == template!.id);
                        if (idx != -1) {
                          _templates[idx] = NotificationTemplate(
                            id: template!.id,
                            name: name.trim(),
                            channel: channel,
                            subject: subject.trim(),
                            body: body.trim(),
                            daysBefore: daysBefore,
                          );
                        }
                      } else {
                        // add new
                        final newTemplate = NotificationTemplate(
                          id: _idCounter.toString(),
                          name: name.trim(),
                          channel: channel,
                          subject: subject.trim(),
                          body: body.trim(),
                          daysBefore: daysBefore,
                        );
                        _templates.add(newTemplate);
                        _idCounter++;
                      }
                    });
                    _saveTemplates();
                    Navigator.pop(context);
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }
}