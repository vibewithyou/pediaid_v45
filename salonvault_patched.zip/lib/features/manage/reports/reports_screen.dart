import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

/// A reports screen with basic filters and multiple chart types.
/// Users can choose a time range and metric to view. Each chart uses
/// mock data for demonstration. The export button is a placeholder for
/// future CSV/PDF downloads.
class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  // Keys for available time ranges. These map to translations in AppLocalizations.
  final List<String> _timeRangeKeys = ['last_7_days', 'last_4_weeks', 'last_6_months'];
  String _selectedRangeKey = 'last_7_days';

  // Keys for available metrics (each corresponds to a chart type).
  final List<String> _metricKeys = ['revenue', 'utilization', 'product_turnover'];
  String _selectedMetricKey = 'revenue';

  // Mock data for charts. In a real implementation, these values would
  // come from the backend based on the selected time range and salon.
  List<FlSpot> get _revenueData {
    switch (_selectedRangeKey) {
      case 'last_4_weeks':
        return [
          const FlSpot(0, 8),
          const FlSpot(1, 12),
          const FlSpot(2, 10),
          const FlSpot(3, 15),
        ];
      case 'last_6_months':
        return [
          const FlSpot(0, 40),
          const FlSpot(1, 45),
          const FlSpot(2, 35),
          const FlSpot(3, 50),
          const FlSpot(4, 48),
          const FlSpot(5, 55),
        ];
      case 'last_7_days':
      default:
        return [
          const FlSpot(0, 10),
          const FlSpot(1, 14),
          const FlSpot(2, 12),
          const FlSpot(3, 18),
          const FlSpot(4, 16),
          const FlSpot(5, 20),
          const FlSpot(6, 22),
        ];
    }
  }

  // Mock utilization data (e.g. appointments per day). Represented as bars.
  List<BarChartGroupData> get _utilizationData {
    final data = <double>[];
    switch (_selectedRangeKey) {
      case 'last_4_weeks':
        data.addAll([
          30, 42, 38, 50,
        ]);
        break;
      case 'last_6_months':
        data.addAll([40, 48, 35, 60, 55, 50]);
        break;
      case 'last_7_days':
      default:
        data.addAll([18, 20, 22, 24, 26, 28, 30]);
        break;
    }
    return List.generate(data.length, (i) {
      return BarChartGroupData(
        x: i,
        barRods: [
          BarChartRodData(toY: data[i], width: 12, borderRadius: BorderRadius.circular(4), color: AppColors.gold),
        ],
      );
    });
  }

  // Mock product turnover data for pie chart (revenue split by product). Each entry
  // contains a percentage value and a color from the theme palette.
  List<PieChartSectionData> get _productTurnoverData {
    final Map<String, double> values;
    switch (_selectedRangeKey) {
      case 'last_4_weeks':
        values = {'Shampoo': 40, 'Color': 30, 'Care': 20, 'Styling': 10};
        break;
      case 'last_6_months':
        values = {'Shampoo': 35, 'Color': 25, 'Care': 25, 'Styling': 15};
        break;
      case 'last_7_days':
      default:
        values = {'Shampoo': 45, 'Color': 30, 'Care': 15, 'Styling': 10};
        break;
    }
    return values.entries.map((e) {
      final color = _generateColorForLabel(e.key);
      return PieChartSectionData(
        value: e.value,
        title: '${e.value.toInt()}%',
        color: color,
        radius: 60,
        titleStyle: const TextStyle(color: Colors.white, fontSize: 14),
      );
    }).toList();
  }

  Color _generateColorForLabel(String label) {
    // Assign a consistent color based on the label hash. This is just for
    // demonstration. In a real app, you'd use your theme's palette.
    final hash = label.hashCode;
    return Color((hash & 0xFFFFFF) | 0xFF000000);
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l.translate('reports_title'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Filters row: time range and metric
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _selectedRangeKey,
                  decoration: InputDecoration(
                    labelText: l.translate('time_range'),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onChanged: (val) {
                    if (val != null) {
                      setState(() => _selectedRangeKey = val);
                    }
                  },
                  items: _timeRangeKeys
                      .map((k) => DropdownMenuItem(
                            value: k,
                            child: Text(l.translate(k)),
                          ))
                      .toList(),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _selectedMetricKey,
                  decoration: InputDecoration(
                    labelText: l.translate('metric'),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onChanged: (val) {
                    if (val != null) {
                      setState(() => _selectedMetricKey = val);
                    }
                  },
                  items: _metricKeys
                      .map((k) => DropdownMenuItem(
                            value: k,
                            child: Text(l.translate(k)),
                          ))
                      .toList(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          // Display the selected chart
          if (_selectedMetricKey == 'revenue') ...[
            Text(
              '${l.translate('revenue')} (${l.translate(_selectedRangeKey).toLowerCase()})',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 220,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: LineChart(
                    LineChartData(
                      gridData: const FlGridData(show: true, drawVerticalLine: false),
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(
                          axisNameSize: 24,
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 22,
                            interval: 1,
                            getTitlesWidget: (value, meta) {
                              final int index = value.toInt();
                              final labels = _selectedRangeKey == 'last_7_days'
                                  ? ['M', 'T', 'W', 'T', 'F', 'S', 'S']
                                  : List.generate(_revenueData.length, (i) => (i + 1).toString());
                              if (index < 0 || index >= labels.length) {
                                return const SizedBox.shrink();
                              }
                              return Text(labels[index], style: Theme.of(context).textTheme.bodySmall);
                            },
                          ),
                        ),
                        leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      ),
                      borderData: FlBorderData(show: false),
                      lineBarsData: [
                        LineChartBarData(
                          isCurved: true,
                          color: AppColors.gold,
                          barWidth: 3,
                          spots: _revenueData,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ] else if (_selectedMetricKey == 'utilization') ...[
            Text(
              '${l.translate('utilization')} (${l.translate(_selectedRangeKey).toLowerCase()})',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 220,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: BarChart(
                    BarChartData(
                      gridData: const FlGridData(show: false),
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 22,
                            interval: 1,
                            getTitlesWidget: (value, meta) {
                              final index = value.toInt();
                              return Text('D${index + 1}', style: Theme.of(context).textTheme.bodySmall);
                            },
                          ),
                        ),
                        leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      ),
                      borderData: FlBorderData(show: false),
                      barGroups: _utilizationData,
                    ),
                  ),
                ),
              ),
            ),
          ] else if (_selectedMetricKey == 'product_turnover') ...[
            Text(
              '${l.translate('product_turnover')} (${l.translate(_selectedRangeKey).toLowerCase()})',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 260,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: PieChart(
                    PieChartData(
                      sections: _productTurnoverData,
                      sectionsSpace: 4,
                      centerSpaceRadius: 40,
                    ),
                  ),
                ),
              ),
            ),
          ],
          const SizedBox(height: 24),
          // Placeholder for exporting reports
          LuxuryButton(
            label: l.translate('export_report'),
            filled: false,
            onPressed: () {
              // TODO(tobiasbecker2025): implement CSV/PDF export via backend or local generation
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(l.translate('export_not_implemented'))),
              );
            },
          ),
        ],
      ),
    );
  }
}