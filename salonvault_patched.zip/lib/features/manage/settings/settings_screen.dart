import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/language_provider.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  final _brandNameController = TextEditingController();
  bool _useSalonBranding = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _brandNameController.text = prefs.getString('brand_name') ?? '';
      _useSalonBranding = prefs.getBool('use_salon_branding') ?? false;
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('brand_name', _brandNameController.text);
    await prefs.setBool('use_salon_branding', _useSalonBranding);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Settings saved locally')),
    );
  }

  @override
  void dispose() {
    _brandNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final locale = ref.watch(localeProvider);
    final local = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(local.translate('settings_title'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(local.translate('branding_title'), style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          LuxuryInput(
            controller: _brandNameController,
            hintText: local.translate('brand_name_hint'),
          ),
          const SizedBox(height: 12),
          SwitchListTile(
            value: _useSalonBranding,
            activeColor: AppColors.gold,
            title: Text(local.translate('use_salon_branding_title')),
            subtitle: Text(local.translate('use_salon_branding_subtitle')),
            onChanged: (v) => setState(() => _useSalonBranding = v),
          ),
          const SizedBox(height: 24),
          Text(local.translate('language'), style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          DropdownButton<Locale>(
            value: locale,
            items: const [
              DropdownMenuItem(value: Locale('de'), child: Text('Deutsch')),
              DropdownMenuItem(value: Locale('en'), child: Text('English')),
            ],
            onChanged: (Locale? newLocale) {
              if (newLocale != null) {
                ref.read(localeProvider.notifier).setLocale(newLocale);
              }
            },
          ),
          const SizedBox(height: 24),
          Text(local.translate('legal_title'), style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          // Link to legal editor
          LuxuryCard(
            leading: const Icon(Icons.description),
            title: local.translate('legal_editor_title'),
            subtitle: local.translate('legal_editor_subtitle'),
            onTap: () {
              Navigator.pushNamed(context, '/manage/legal');
            },
          ),
          const SizedBox(height: 12),
          // Link to help/FAQ page
          LuxuryCard(
            leading: const Icon(Icons.help_outline),
            title: local.translate('help_faq'),
            subtitle: local.translate('help_faq_title'),
            onTap: () {
              Navigator.pushNamed(context, '/help');
            },
          ),
          const SizedBox(height: 24),
          LuxuryButton(
            onPressed: _save,
            filled: true,
            label: local.translate('save'),
          ),
        ],
      ),
    );
  }
}
