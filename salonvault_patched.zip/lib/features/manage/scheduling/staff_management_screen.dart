import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';

/// Screen for managing staff extras: absences, time tracking and working rules.
///
/// This screen is accessible from the Manage dashboard and is meant to
/// demonstrate how a manager could handle employee absences, holiday
/// calendars, working time rules and simple clock‑in/out tracking without
/// requiring a backend. All data lives in memory and should be replaced with
/// proper API calls marked by TODO comments when the backend is connected.
class StaffManagementScreen extends ConsumerStatefulWidget {
  const StaffManagementScreen({super.key});

  @override
  ConsumerState<StaffManagementScreen> createState() => _StaffManagementScreenState();
}

class _StaffManagementScreenState extends ConsumerState<StaffManagementScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Absences
  final List<_AbsenceRequest> _absences = [];

  // Time tracking
  final List<_TimeLog> _timeLogs = [];
  DateTime? _currentClockIn;

  // Working rules
  int _maxPerDay = 8;
  int _maxPerWeek = 40;

  // Holidays (static list for demonstration)
  final List<DateTime> _holidays = [
    DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day + 3),
    DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day + 7),
  ];

  // Employees (with possible duplicates). In a real system these would
  // come from the backend. Here we include duplicate names to demonstrate
  // the merge feature. Each employee has an id, name and role.
  final List<_Employee> _employees = [
    _Employee(id: '1', name: 'Anna Schmidt', role: 'Stylist'),
    _Employee(id: '2', name: 'Max Müller', role: 'Stylist'),
    _Employee(id: '3', name: 'Anna Schmidt', role: 'Colorist'),
  ];
  // Selected employees for merge operation.
  final Set<String> _selectedEmployees = {};

  @override
  void initState() {
    super.initState();
    // Added an extra tab for employees (with merge duplicates functionality).
    _tabController = TabController(length: 5, vsync: this);
  }

  /// Merges selected employees with identical names into a single entry. The
  /// first selected employee becomes the primary record; all other selected
  /// employees are removed. This simulates the merge duplicates feature. In a
  /// real implementation the merge would happen in the backend with data
  /// consolidation logic.
  void _mergeEmployees() {
    if (_selectedEmployees.length < 2) return;
    // Group selected employees by name
    final selectedList = _employees.where((e) => _selectedEmployees.contains(e.id)).toList();
    final String name = selectedList.first.name;
    final String role = selectedList.first.role;
    // Create a new id for merged employee
    final merged = _Employee(id: DateTime.now().microsecondsSinceEpoch.toString(), name: name, role: role);
    setState(() {
      _employees.removeWhere((e) => _selectedEmployees.contains(e.id));
      _employees.add(merged);
      _selectedEmployees.clear();
    });
    // TODO(tobiasbecker2025): Persist merged employee and delete duplicates via backend.
  }

  void _addAbsence() {
    final employeeController = TextEditingController();
    DateTime start = DateTime.now();
    DateTime end = DateTime.now().add(const Duration(days: 1));
    final reasonController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx2, setState) {
            Future<void> pickStart() async {
              final d = await showDatePicker(
                context: ctx2,
                initialDate: start,
                firstDate: DateTime(DateTime.now().year - 1),
                lastDate: DateTime(DateTime.now().year + 2),
              );
              if (d != null) {
                setState(() => start = d);
              }
            }
            Future<void> pickEnd() async {
              final d = await showDatePicker(
                context: ctx2,
                initialDate: end,
                firstDate: start,
                lastDate: DateTime(DateTime.now().year + 2),
              );
              if (d != null) {
                setState(() => end = d);
              }
            }
            return AlertDialog(
              title: const Text('Abwesenheit beantragen'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: employeeController,
                      decoration: const InputDecoration(labelText: 'Mitarbeiter'),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: pickStart,
                            child: Text('Start: ${DateFormat('dd.MM.yyyy').format(start)}'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: pickEnd,
                            child: Text('Ende: ${DateFormat('dd.MM.yyyy').format(end)}'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: reasonController,
                      decoration: const InputDecoration(labelText: 'Grund'),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.of(ctx2).pop(), child: const Text('Abbrechen')),
                LuxuryButton(
                  text: 'Anlegen',
                  onPressed: () {
                    setState(() {
                      _absences.add(_AbsenceRequest(
                        id: DateTime.now().microsecondsSinceEpoch.toString(),
                        employee: employeeController.text,
                        start: start,
                        end: end,
                        reason: reasonController.text,
                        status: AbsenceStatus.pending,
                      ));
                    });
                    // TODO(tobiasbecker2025): Persist absence request to backend.
                    Navigator.of(ctx2).pop();
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _toggleClock() {
    setState(() {
      if (_currentClockIn == null) {
        _currentClockIn = DateTime.now();
      } else {
        _timeLogs.add(_TimeLog(start: _currentClockIn!, end: DateTime.now()));
        _currentClockIn = null;
        // TODO(tobiasbecker2025): Persist time log entry to backend
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Staff Management'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Abwesenheiten'),
            Tab(text: 'Zeiterfassung'),
            Tab(text: 'Regeln'),
            Tab(text: 'Feiertage'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Absences tab
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Expanded(
                  child: _absences.isEmpty
                      ? const Center(child: Text('Keine Abwesenheiten.'))
                      : ListView.builder(
                          itemCount: _absences.length,
                          itemBuilder: (context, index) {
                            final a = _absences[index];
                            final period = '${DateFormat('dd.MM').format(a.start)}–${DateFormat('dd.MM').format(a.end)}';
                            return LuxuryCard(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(a.employee, style: Theme.of(context).textTheme.headlineMedium),
                                        const SizedBox(height: 4),
                                        Text(period, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).hintColor)),
                                        const SizedBox(height: 2),
                                        Text('Grund: ${a.reason}', style: Theme.of(context).textTheme.bodySmall),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: _statusColor(a.status).withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Text(
                                          _statusLabel(a.status),
                                          style: Theme.of(context).textTheme.bodySmall?.copyWith(color: _statusColor(a.status), fontWeight: FontWeight.w600),
                                        ),
                                      ),
                                      if (a.status == AbsenceStatus.pending)
                                        Row(
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.check, color: Colors.green),
                                              onPressed: () {
                                                setState(() {
                                                  a.status = AbsenceStatus.approved;
                                                });
                                                // TODO(tobiasbecker2025): persist absence approval to backend
                                              },
                                            ),
                                            IconButton(
                                              icon: const Icon(Icons.close, color: Colors.red),
                                              onPressed: () {
                                                setState(() {
                                                  a.status = AbsenceStatus.declined;
                                                });
                                                // TODO(tobiasbecker2025): persist absence decline to backend
                                              },
                                            ),
                                          ],
                                        ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                LuxuryButton(
                  onPressed: _addAbsence,
                  text: 'Abwesenheit hinzufügen',
                  variant: LuxuryButtonVariant.outlined,
                ),
              ],
            ),
          ),
          // Time tracking tab
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                LuxuryCard(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _currentClockIn == null ? 'Nicht eingecheckt' : 'Eingecheckt seit ${DateFormat.Hm().format(_currentClockIn!)}',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      LuxuryButton(
                        text: _currentClockIn == null ? 'Clock In' : 'Clock Out',
                        onPressed: _toggleClock,
                        variant: LuxuryButtonVariant.filled,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: _timeLogs.isEmpty
                      ? const Center(child: Text('Keine Zeiterfassungseinträge.'))
                      : ListView.builder(
                          itemCount: _timeLogs.length,
                          itemBuilder: (context, index) {
                            final log = _timeLogs[index];
                            final diff = log.end.difference(log.start);
                            final dur = '${diff.inHours.toString().padLeft(2, '0')}:${(diff.inMinutes % 60).toString().padLeft(2, '0')}';
                            return LuxuryCard(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          '${DateFormat('dd.MM.yyyy').format(log.start)} – ${DateFormat.Hm().format(log.start)}–${DateFormat.Hm().format(log.end)}',
                                          style: Theme.of(context).textTheme.bodyMedium,
                                        ),
                                        const SizedBox(height: 2),
                                        Text('Dauer: $dur', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).hintColor)),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red),
                                    onPressed: () {
                                      setState(() {
                                        _timeLogs.removeAt(index);
                                      });
                                      // TODO(tobiasbecker2025): persist deletion of time log to backend
                                    },
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
          // Rules tab
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Arbeitszeit‑Regeln', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(labelText: 'Max. Stunden pro Tag'),
                        keyboardType: TextInputType.number,
                        controller: TextEditingController(text: _maxPerDay.toString()),
                        onChanged: (val) {
                          final n = int.tryParse(val);
                          if (n != null) setState(() => _maxPerDay = n);
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(labelText: 'Max. Stunden pro Woche'),
                        keyboardType: TextInputType.number,
                        controller: TextEditingController(text: _maxPerWeek.toString()),
                        onChanged: (val) {
                          final n = int.tryParse(val);
                          if (n != null) setState(() => _maxPerWeek = n);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text('Hinweis: Diese Einstellungen dienen der Frontend‑Demonstration und werden nicht gespeichert.', style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 24),
                LuxuryCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Aktuelle Regeln'),
                      const SizedBox(height: 4),
                      Text('Max. pro Tag: $_maxPerDay h'),
                      Text('Max. pro Woche: $_maxPerWeek h'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Holidays tab
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Expanded(
                  child: _holidays.isEmpty
                      ? const Center(child: Text('Keine Feiertage eingetragen.'))
                      : ListView.builder(
                          itemCount: _holidays.length,
                          itemBuilder: (context, index) {
                            final h = _holidays[index];
                            return LuxuryCard(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(DateFormat('dd.MM.yyyy').format(h)),
                                  IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red),
                                    onPressed: () {
                                      setState(() {
                                        _holidays.removeAt(index);
                                      });
                                      // TODO(tobiasbecker2025): remove holiday in backend
                                    },
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                LuxuryButton(
                  text: 'Feiertag hinzufügen',
                  variant: LuxuryButtonVariant.outlined,
                  onPressed: () async {
                    final d = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(DateTime.now().year - 1),
                      lastDate: DateTime(DateTime.now().year + 2),
                    );
                    if (d != null) {
                      setState(() {
                        _holidays.add(d);
                      });
                      // TODO(tobiasbecker2025): persist holiday addition
                    }
                  },
                ),
              ],
            ),
          ),

          // Employees tab: list staff and merge duplicates
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Expanded(
                  child: _employees.isEmpty
                      ? const Center(child: Text('Keine Mitarbeiter vorhanden.'))
                      : ListView.builder(
                          itemCount: _employees.length,
                          itemBuilder: (context, index) {
                            final e = _employees[index];
                            final selected = _selectedEmployees.contains(e.id);
                            return LuxuryCard(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: Row(
                                children: [
                                  Checkbox(
                                    value: selected,
                                    onChanged: (val) {
                                      setState(() {
                                        if (val == true) {
                                          _selectedEmployees.add(e.id);
                                        } else {
                                          _selectedEmployees.remove(e.id);
                                        }
                                      });
                                    },
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(e.name, style: Theme.of(context).textTheme.headlineMedium),
                                        const SizedBox(height: 4),
                                        Text('Rolle: ${e.role}', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).hintColor)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                if (_selectedEmployees.length >= 2)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: LuxuryButton(
                      text: 'Ausgewählte zusammenführen',
                      onPressed: _mergeEmployees,
                    ),
                  ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: LuxuryButton(
                    text: 'Mitarbeiter hinzufügen',
                    variant: LuxuryButtonVariant.outlined,
                    onPressed: () {
                      final nameController = TextEditingController();
                      final roleController = TextEditingController();
                      showDialog(
                        context: context,
                        builder: (ctx) {
                          return AlertDialog(
                            title: const Text('Mitarbeiter hinzufügen'),
                            content: SingleChildScrollView(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  TextField(
                                    controller: nameController,
                                    decoration: const InputDecoration(labelText: 'Name'),
                                  ),
                                  const SizedBox(height: 8),
                                  TextField(
                                    controller: roleController,
                                    decoration: const InputDecoration(labelText: 'Rolle'),
                                  ),
                                ],
                              ),
                            ),
                            actions: [
                              TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Abbrechen')),
                              LuxuryButton(
                                text: 'Anlegen',
                                onPressed: () {
                                  setState(() {
                                    _employees.add(_Employee(
                                      id: DateTime.now().microsecondsSinceEpoch.toString(),
                                      name: nameController.text,
                                      role: roleController.text,
                                    ));
                                  });
                                  // TODO(tobiasbecker2025): Persist new employee to backend
                                  Navigator.of(ctx).pop();
                                },
                              ),
                            ],
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _statusLabel(AbsenceStatus s) {
    switch (s) {
      case AbsenceStatus.approved:
        return 'Genehmigt';
      case AbsenceStatus.declined:
        return 'Abgelehnt';
      case AbsenceStatus.pending:
        return 'Offen';
    }
  }

  Color _statusColor(AbsenceStatus s) {
    switch (s) {
      case AbsenceStatus.approved:
        return Colors.green;
      case AbsenceStatus.declined:
        return Colors.red;
      case AbsenceStatus.pending:
        return Colors.orange;
    }
  }
}

enum AbsenceStatus { pending, approved, declined }

class _AbsenceRequest {
  final String id;
  final String employee;
  final DateTime start;
  final DateTime end;
  final String reason;
  AbsenceStatus status;
  _AbsenceRequest({required this.id, required this.employee, required this.start, required this.end, required this.reason, required this.status});
}

class _TimeLog {
  final DateTime start;
  final DateTime end;
  _TimeLog({required this.start, required this.end});
}

/// Simple employee model for demonstration purposes.
class _Employee {
  String id;
  String name;
  String role;
  _Employee({required this.id, required this.name, required this.role});
}

// Hidden copyright marker
const _staffExtrasObfuscatedCopyright = 'tobiasbecker2025';