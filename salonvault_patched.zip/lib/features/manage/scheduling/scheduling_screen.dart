import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';

class SchedulingScreen extends StatefulWidget {
  const SchedulingScreen({super.key});

  @override
  State<SchedulingScreen> createState() => _SchedulingScreenState();
}

class _SchedulingScreenState extends State<SchedulingScreen> {
  final List<String> _stylists = ['Alice', 'Bob', 'Charlie'];
  late final List<DateTime> _days;
  // Map holding shift label by stylist and day index
  late Map<String, String?> _assignments;

  @override
  void initState() {
    super.initState();
    _days = List.generate(5, (i) => DateTime.now().add(Duration(days: i)));
    _assignments = {};
    for (final stylist in _stylists) {
      for (int d = 0; d < _days.length; d++) {
        // Just assign a dummy shift for first cell
        _assignments['$stylist-$d'] = (d == 0 && _stylists.indexOf(stylist) == 0)
            ? '09:00 - 17:00'
            : null;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Staff Scheduling')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: LuxuryButton(
                    label: 'Create Shift',
                    filled: false,
                    onPressed: () {
                      // TODO(tobiasbecker2025): open create shift dialog and store shift via backend
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: LuxuryButton(
                    label: 'Request Swap',
                    filled: false,
                    onPressed: () {
                      // TODO(tobiasbecker2025): implement shift swap logic
                    },
                  ),
                ),
              ],
            ),
          ),
          // Schedule board
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Column(
                children: [
                  // Header row with days
                  Row(
                    children: [
                      const SizedBox(width: 120),
                      ..._days.map((d) => Container(
                            width: 160,
                            padding: const EdgeInsets.all(12),
                            child: Text(
                              _formatDate(d),
                              style: Theme.of(context).textTheme.titleMedium,
                              textAlign: TextAlign.center,
                            ),
                          )),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // Rows per stylist
                  ..._stylists.map((stylist) {
                    return Row(
                      children: [
                        SizedBox(
                          width: 120,
                          child: Text(
                            stylist,
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ),
                        ...List.generate(_days.length, (dayIndex) {
                          final key = '$stylist-$dayIndex';
                          final shift = _assignments[key];
          return DragTarget<String>(
            onWillAccept: (data) {
              // Only accept drop if cell is empty; otherwise reject (conflict)
              if (_assignments[key] != null) {
                // Show a brief message informing about conflict
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Conflict: This slot already has a shift')),
                );
                return false;
              }
              return true;
            },
            onAccept: (data) {
              setState(() {
                _assignments[key] = data;
              });
            },
            builder: (context, candidateData, rejectedData) {
              return Padding(
                padding: const EdgeInsets.all(4),
                child: _buildShiftCell(stylist, dayIndex, shift),
              );
            },
          );
                        }),
                      ],
                    );
                  }).toList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShiftCell(String stylist, int dayIndex, String? shift) {
    final key = '$stylist-$dayIndex';
    if (shift != null) {
      return Draggable<String>(
        data: shift,
        feedback: _ShiftCard(label: shift),
        childWhenDragging: Container(
          width: 160,
          height: 60,
          decoration: BoxDecoration(
            color: Theme.of(context).disabledColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
        ),
        child: _ShiftCard(
          label: shift,
          onRemove: () {
            setState(() {
              _assignments[key] = null;
            });
          },
        ),
      );
    } else {
      return InkWell(
        onTap: () {
          // TODO(tobiasbecker2025): open create shift dialog for this cell
        },
        child: Container(
          width: 160,
          height: 60,
          decoration: BoxDecoration(
            color: Theme.of(context).cardTheme.color,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Theme.of(context).dividerColor.withOpacity(0.3)),
          ),
          child: Center(
            child: Text(
              '–',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Theme.of(context).disabledColor),
            ),
          ),
        ),
      );
    }
  }

  String _formatDate(DateTime d) {
    return '${d.day}/${d.month}';
  }
}

/// A small card representing a shift; used in drag-and-drop schedule board.
class _ShiftCard extends StatelessWidget {
  final String label;
  final VoidCallback? onRemove;
  const _ShiftCard({required this.label, this.onRemove});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 160,
      height: 60,
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).brightness == Brightness.dark
                ? Theme.of(context).colorScheme.primary.withOpacity(0.3)
                : Colors.black.withOpacity(0.2),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
          if (onRemove != null)
            IconButton(
              icon: const Icon(Icons.close, size: 18, color: AppColors.gold),
              onPressed: onRemove,
            ),
        ],
      ),
    );
  }
}
