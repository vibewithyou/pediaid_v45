import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';

/// Data model representing a gift card with a code, balance and expiry date.
class GiftCard {
  String id;
  String code;
  double balance;
  DateTime expiry;
  GiftCard({required this.id, required this.code, required this.balance, required this.expiry});

  factory GiftCard.fromMap(Map<String, dynamic> map) {
    return GiftCard(
      id: map['id'] ?? '',
      code: map['code'] ?? '',
      balance: (map['balance'] ?? 0).toDouble(),
      expiry: DateTime.parse(map['expiry']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'code': code,
      'balance': balance,
      'expiry': expiry.toIso8601String(),
    };
  }
}

/// Data model representing a multi‑session package with name, number of sessions, price and expiry date.
class ServicePackage {
  String id;
  String name;
  int sessions;
  double price;
  DateTime expiry;
  ServicePackage({required this.id, required this.name, required this.sessions, required this.price, required this.expiry});

  factory ServicePackage.fromMap(Map<String, dynamic> map) {
    return ServicePackage(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      sessions: map['sessions'] ?? 0,
      price: (map['price'] ?? 0).toDouble(),
      expiry: DateTime.parse(map['expiry']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'sessions': sessions,
      'price': price,
      'expiry': expiry.toIso8601String(),
    };
  }
}

/// Screen for managing gift cards and packages. Users can add, edit
/// or delete cards and packages. Data is persisted in SharedPreferences
/// per salon. All text is localized via AppLocalizations.
class GiftCardsScreen extends ConsumerStatefulWidget {
  const GiftCardsScreen({super.key});

  @override
  ConsumerState<GiftCardsScreen> createState() => _GiftCardsScreenState();
}

class _GiftCardsScreenState extends ConsumerState<GiftCardsScreen> with SingleTickerProviderStateMixin {
  final List<GiftCard> _giftCards = [];
  final List<ServicePackage> _packages = [];
  late TabController _tabController;
  int _idCounter = 1;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadData());
  }

  Future<void> _loadData() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final giftKey = 'gift_cards_$salonId';
    final packageKey = 'packages_$salonId';
    final giftJson = prefs.getString(giftKey);
    final packageJson = prefs.getString(packageKey);
    setState(() {
      _giftCards.clear();
      _packages.clear();
      if (giftJson != null) {
        final List<dynamic> decoded = jsonDecode(giftJson);
        _giftCards.addAll(decoded.map((e) => GiftCard.fromMap(Map<String, dynamic>.from(e))));
      }
      if (packageJson != null) {
        final List<dynamic> decoded = jsonDecode(packageJson);
        _packages.addAll(decoded.map((e) => ServicePackage.fromMap(Map<String, dynamic>.from(e))));
      }
      // update id counter based on existing ids
      for (final c in _giftCards) {
        final idNum = int.tryParse(c.id);
        if (idNum != null && idNum >= _idCounter) _idCounter = idNum + 1;
      }
      for (final p in _packages) {
        final idNum = int.tryParse(p.id);
        if (idNum != null && idNum >= _idCounter) _idCounter = idNum + 1;
      }
    });
  }

  Future<void> _saveData() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final giftKey = 'gift_cards_$salonId';
    final packageKey = 'packages_$salonId';
    final giftJson = jsonEncode(_giftCards.map((e) => e.toMap()).toList());
    final packageJson = jsonEncode(_packages.map((e) => e.toMap()).toList());
    await prefs.setString(giftKey, giftJson);
    await prefs.setString(packageKey, packageJson);
  }

  void _deleteGiftCard(int index) {
    setState(() {
      _giftCards.removeAt(index);
    });
    _saveData();
  }

  void _deletePackage(int index) {
    setState(() {
      _packages.removeAt(index);
    });
    _saveData();
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(l.translate('loyalty_title')),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: l.translate('gift_cards_tab')),
            Tab(text: l.translate('packages_tab')),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildGiftCardsTab(context, l),
          _buildPackagesTab(context, l),
        ],
      ),
    );
  }

  Widget _buildGiftCardsTab(BuildContext context, AppLocalizations l) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (_giftCards.isEmpty)
          Center(child: Text(l.translate('no_templates') ?? 'No items'))
        else
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: _giftCards.asMap().entries.map((entry) {
              final idx = entry.key;
              final gc = entry.value;
              return SizedBox(
                width: 260,
                child: LuxuryCard(
                  title: gc.code,
                  subtitle:
                      '${l.translate('gift_card_balance')}: €${gc.balance.toStringAsFixed(2)} • ${l.translate('gift_card_expiry')}: ${DateFormat('dd.MM.yyyy').format(gc.expiry)}',
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: AppColors.gold),
                        onPressed: () => _showGiftCardDialog(existing: gc, index: idx),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteGiftCard(idx),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        const SizedBox(height: 24),
        LuxuryButton(
          onPressed: () => _showGiftCardDialog(),
          text: l.translate('add_gift_card'),
          variant: LuxuryButtonVariant.outlined,
        ),
      ],
    );
  }

  Widget _buildPackagesTab(BuildContext context, AppLocalizations l) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (_packages.isEmpty)
          Center(child: Text(l.translate('no_templates') ?? 'No items'))
        else
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: _packages.asMap().entries.map((entry) {
              final idx = entry.key;
              final pkg = entry.value;
              return SizedBox(
                width: 260,
                child: LuxuryCard(
                  title: pkg.name,
                  subtitle:
                      '${pkg.sessions} ${l.translate('package_sessions')} • €${pkg.price.toStringAsFixed(2)} • ${l.translate('package_expiry')}: ${DateFormat('dd.MM.yyyy').format(pkg.expiry)}',
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: AppColors.gold),
                        onPressed: () => _showPackageDialog(existing: pkg, index: idx),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deletePackage(idx),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        const SizedBox(height: 24),
        LuxuryButton(
          onPressed: () => _showPackageDialog(),
          text: l.translate('add_package'),
          variant: LuxuryButtonVariant.outlined,
        ),
      ],
    );
  }

  void _showGiftCardDialog({GiftCard? existing, int? index}) {
    final l = AppLocalizations.of(context);
    String code = existing?.code ?? '';
    double balance = existing?.balance ?? 0.0;
    DateTime expiry = existing?.expiry ?? DateTime.now().add(const Duration(days: 365));
    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx2, setState) {
            Future<void> pickDate() async {
              final d = await showDatePicker(
                context: ctx2,
                initialDate: expiry,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 1825)),
              );
              if (d != null) {
                setState(() => expiry = d);
              }
            }
            return AlertDialog(
              title: Text(l.translate(existing == null ? 'new_gift_card' : 'edit_gift_card')),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    LuxuryInput(
                      controller: TextEditingController(text: code),
                      labelText: l.translate('gift_card_code'),
                      onChanged: (v) => code = v,
                    ),
                    const SizedBox(height: 8),
                    LuxuryInput(
                      controller: TextEditingController(text: balance == 0.0 ? '' : balance.toString()),
                      labelText: l.translate('gift_card_balance'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      onChanged: (v) => balance = double.tryParse(v) ?? 0.0,
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton(
                      onPressed: pickDate,
                      child: Text('${l.translate('gift_card_expiry')}: ${DateFormat('dd.MM.yyyy').format(expiry)}'),
                    ),
                  ],
                ),
              ),
              actions: [
                LuxuryButton(
                  label: l.translate('cancel'),
                  filled: false,
                  onPressed: () => Navigator.of(ctx2).pop(),
                ),
                LuxuryButton(
                  label: l.translate('save'),
                  filled: true,
                  onPressed: () {
                    if (code.trim().isEmpty || balance <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(l.translate('error_fill_fields'))),
                      );
                      return;
                    }
                    setState(() {
                      if (existing != null && index != null) {
                        _giftCards[index] = GiftCard(id: existing.id, code: code.trim(), balance: balance, expiry: expiry);
                      } else {
                        _giftCards.add(GiftCard(id: _idCounter.toString(), code: code.trim(), balance: balance, expiry: expiry));
                        _idCounter++;
                      }
                    });
                    _saveData();
                    Navigator.of(ctx2).pop();
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showPackageDialog({ServicePackage? existing, int? index}) {
    final l = AppLocalizations.of(context);
    String name = existing?.name ?? '';
    int sessions = existing?.sessions ?? 1;
    double price = existing?.price ?? 0.0;
    DateTime expiry = existing?.expiry ?? DateTime.now().add(const Duration(days: 365));
    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx2, setState) {
            Future<void> pickDate() async {
              final d = await showDatePicker(
                context: ctx2,
                initialDate: expiry,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 1825)),
              );
              if (d != null) {
                setState(() => expiry = d);
              }
            }
            return AlertDialog(
              title: Text(l.translate(existing == null ? 'new_package' : 'edit_package')),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    LuxuryInput(
                      controller: TextEditingController(text: name),
                      labelText: l.translate('package_name'),
                      onChanged: (v) => name = v,
                    ),
                    const SizedBox(height: 8),
                    LuxuryInput(
                      controller: TextEditingController(text: sessions == 0 ? '' : sessions.toString()),
                      labelText: l.translate('package_sessions'),
                      keyboardType: TextInputType.number,
                      onChanged: (v) => sessions = int.tryParse(v) ?? 0,
                    ),
                    const SizedBox(height: 8),
                    LuxuryInput(
                      controller: TextEditingController(text: price == 0.0 ? '' : price.toString()),
                      labelText: l.translate('package_price'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      onChanged: (v) => price = double.tryParse(v) ?? 0.0,
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton(
                      onPressed: pickDate,
                      child: Text('${l.translate('package_expiry')}: ${DateFormat('dd.MM.yyyy').format(expiry)}'),
                    ),
                  ],
                ),
              ),
              actions: [
                LuxuryButton(
                  label: l.translate('cancel'),
                  filled: false,
                  onPressed: () => Navigator.of(ctx2).pop(),
                ),
                LuxuryButton(
                  label: l.translate('save'),
                  filled: true,
                  onPressed: () {
                    if (name.trim().isEmpty || sessions <= 0 || price <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(l.translate('error_fill_fields'))),
                      );
                      return;
                    }
                    setState(() {
                      if (existing != null && index != null) {
                        _packages[index] = ServicePackage(id: existing.id, name: name.trim(), sessions: sessions, price: price, expiry: expiry);
                      } else {
                        _packages.add(ServicePackage(id: _idCounter.toString(), name: name.trim(), sessions: sessions, price: price, expiry: expiry));
                        _idCounter++;
                      }
                    });
                    _saveData();
                    Navigator.of(ctx2).pop();
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }
}