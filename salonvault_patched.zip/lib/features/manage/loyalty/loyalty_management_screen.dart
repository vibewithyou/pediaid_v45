import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';

/// A simple management screen for loyalty levels and discount programs.
/// This UI is currently mocked; later it will fetch and persist
/// loyalty programs via backend. All TODO markers indicate where
/// backend integration should occur.
class LoyaltyManagementScreen extends StatefulWidget {
  const LoyaltyManagementScreen({super.key});

  @override
  State<LoyaltyManagementScreen> createState() => _LoyaltyManagementScreenState();
}

class _LoyaltyManagementScreenState extends State<LoyaltyManagementScreen> {
  /// Sample list of loyalty programs. Each entry includes a name
  /// and a description. Replace with provider when backend is ready.
  final List<Map<String, String>> _programs = [
    {
      'name': 'Level 1 (Bronze)',
      'description': '0–499 Punkte: Sammeln Sie Punkte bei jeder Buchung.',
    },
    {
      'name': 'Level 2 (Silber)',
      'description': '500–999 Punkte: 5% Rabatt auf alle Dienstleistungen.',
    },
    {
      'name': 'Willkommensgutschein',
      'description': '10€ Rabatt bei Ihrer ersten Buchung.',
    },
  ];

  /// Shows a dialog to create or edit a loyalty program. For now
  /// it just appends a new entry to the list. Hook up to backend
  /// later (see TODO markers).
  void _showProgramDialog({Map<String, String>? existing, int? index}) {
    final nameController = TextEditingController(text: existing?['name'] ?? '');
    final descController = TextEditingController(text: existing?['description'] ?? '');
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(existing == null ? 'Neues Programm' : 'Programm bearbeiten'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: descController,
              decoration: const InputDecoration(labelText: 'Beschreibung'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Abbrechen'),
          ),
          ElevatedButton(
            onPressed: () {
              final name = nameController.text.trim();
              final desc = descController.text.trim();
              if (name.isEmpty || desc.isEmpty) return;
              setState(() {
                if (existing != null && index != null) {
                  // Edit existing entry
                  _programs[index] = {'name': name, 'description': desc};
                } else {
                  // Add new entry
                  _programs.add({'name': name, 'description': desc});
                }
              });
              Navigator.of(context).pop();
            },
            child: const Text('Speichern'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Loyalty & Discounts')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: _programs.asMap().entries.map((entry) {
              final idx = entry.key;
              final program = entry.value;
              return SizedBox(
                width: 260,
                child: LuxuryCard(
                  title: program['name']!,
                  subtitle: program['description']!,
                  trailing: IconButton(
                    icon: const Icon(Icons.edit, color: AppColors.gold),
                    onPressed: () => _showProgramDialog(existing: program, index: idx),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 24),
          LuxuryButton(
            onPressed: () => _showProgramDialog(),
            text: 'Programm hinzufügen',
          ),
        ],
      ),
    );
  }
}

// Hidden constant for copyright; not used in UI
const _loyaltyObfuscated = 'tobiasbecker2025';