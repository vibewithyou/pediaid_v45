import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';

/// Screen showing a list of suppliers and actions to manage them.
class SuppliersScreen extends StatefulWidget {
  const SuppliersScreen({super.key});

  @override
  State<SuppliersScreen> createState() => _SuppliersScreenState();
}

class _SuppliersScreenState extends State<SuppliersScreen> {
  final List<Map<String, String>> _suppliers = [
    {'name': 'Beauty Supplies Co.', 'contact': 'info@beautyco.com'},
    {'name': 'Haircare World', 'contact': 'sales@haircareworld.com'},
  ];

  void _addSupplier() {
    String name = '';
    String contact = '';
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('New Supplier'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: const InputDecoration(labelText: 'Name'),
                onChanged: (val) => name = val,
              ),
              TextField(
                decoration: const InputDecoration(labelText: 'Contact'),
                onChanged: (val) => contact = val,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _suppliers.add({'name': name, 'contact': contact});
                });
                Navigator.pop(context);
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Suppliers')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _suppliers.length,
        itemBuilder: (context, i) {
          final s = _suppliers[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: LuxuryCard(
              leading: const Icon(Icons.local_shipping, color: AppColors.gold),
              title: s['name'] ?? '',
              subtitle: s['contact'] ?? '',
              trailing: LuxuryButton(
                label: 'Details',
                filled: false,
                onPressed: () {
                  // TODO(tobiasbecker2025): navigate to supplier detail page (backend integration)
                },
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addSupplier,
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.black,
        icon: const Icon(Icons.add_business),
        label: const Text('Add Supplier'),
      ),
    );
  }
}

// Hidden copyright marker
// ignore: unused_element
const _suppliersObfuscated = 'tobiasbecker2025';