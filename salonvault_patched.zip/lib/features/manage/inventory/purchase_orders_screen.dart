import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';

/// Screen listing purchase orders (POs) with status and details.
class PurchaseOrdersScreen extends StatefulWidget {
  const PurchaseOrdersScreen({super.key});

  @override
  State<PurchaseOrdersScreen> createState() => _PurchaseOrdersScreenState();
}

class _PurchaseOrdersScreenState extends State<PurchaseOrdersScreen> {
  final List<Map<String, dynamic>> _orders = [
    {
      'id': 'PO-1001',
      'date': '12 Oct 2025',
      'status': 'Open',
      'items': [
        {'product': 'Shampoo 500ml', 'qty': 10},
        {'product': 'Conditioner 500ml', 'qty': 5},
      ],
    },
    {
      'id': 'PO-1000',
      'date': '05 Oct 2025',
      'status': 'Received',
      'items': [
        {'product': 'Hair Spray', 'qty': 8},
      ],
    },
  ];

  void _createOrder() {
    String product = '';
    int quantity = 1;
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('New Purchase Order'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: const InputDecoration(labelText: 'Product'),
                onChanged: (val) => product = val,
              ),
              TextField(
                decoration: const InputDecoration(labelText: 'Quantity'),
                keyboardType: TextInputType.number,
                onChanged: (val) => quantity = int.tryParse(val) ?? 1,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                final now = DateTime.now();
                final id = 'PO-${now.millisecondsSinceEpoch.toString().substring(8)}';
                final formattedDate = '${now.day.toString().padLeft(2, '0')} '
                    '${_monthAbbrev(now.month)} ${now.year}';
                setState(() {
                  _orders.insert(0, {
                    'id': id,
                    'date': formattedDate,
                    'status': 'Open',
                    'items': [
                      {'product': product, 'qty': quantity},
                    ],
                  });
                });
                Navigator.pop(context);
              },
              child: const Text('Create'),
            ),
          ],
        );
      },
    );
  }

  String _monthAbbrev(int month) {
    const months = [
      '',
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return months[month];
  }

  void _openOrderDetail(int index) {
    final order = _orders[index];
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PurchaseOrderDetailScreen(
          order: order,
          onUpdateStatus: (newStatus) {
            setState(() {
              _orders[index]['status'] = newStatus;
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Purchase Orders')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _orders.length,
        itemBuilder: (context, i) {
          final o = _orders[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: LuxuryCard(
              leading: const Icon(Icons.receipt_long, color: AppColors.gold),
              title: o['id'] as String,
              subtitle: '${o['date']} • Status: ${o['status']}',
              trailing: LuxuryButton(
                label: 'View',
                filled: false,
                onPressed: () => _openOrderDetail(i),
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createOrder,
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.black,
        icon: const Icon(Icons.add),
        label: const Text('New Order'),
      ),
    );
  }
}

/// Detail page for a purchase order. Displays the list of ordered items,
/// current status and allows updating the status (e.g. marking as received).
class PurchaseOrderDetailScreen extends StatelessWidget {
  final Map<String, dynamic> order;
  final ValueChanged<String> onUpdateStatus;

  const PurchaseOrderDetailScreen({
    super.key,
    required this.order,
    required this.onUpdateStatus,
  });

  @override
  Widget build(BuildContext context) {
    final items = order['items'] as List<dynamic>;
    String status = order['status'] as String;
    return Scaffold(
      appBar: AppBar(title: Text('Order ${order['id']}')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Date: ${order['date']}', style: Theme.of(context).textTheme.bodyLarge),
            const SizedBox(height: 8),
            Text('Status: $status', style: Theme.of(context).textTheme.bodyLarge),
            const SizedBox(height: 16),
            Text('Items', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, i) {
                  final item = items[i];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: LuxuryCard(
                      title: item['product'] as String,
                      subtitle: 'Quantity: ${item['qty']}',
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
            if (status != 'Received')
              LuxuryButton(
                label: 'Mark as Received',
                filled: true,
                onPressed: () {
                  // Mark order as received and return to previous screen.
                  onUpdateStatus('Received');
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Order marked as received')),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

// Hidden copyright marker
// ignore: unused_element
const _ordersObfuscated = 'tobiasbecker2025';