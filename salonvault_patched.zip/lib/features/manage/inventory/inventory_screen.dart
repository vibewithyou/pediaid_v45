import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Inventory screen that allows salon staff to manage stock items per salon.
/// Items are stored locally in [SharedPreferences] under the key `inventory_<salonId>`
/// as a JSON encoded list. Each entry is a map with `name`, `quantity` and `price`.
class InventoryScreen extends ConsumerStatefulWidget {
  const InventoryScreen({super.key});

  @override
  ConsumerState<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends ConsumerState<InventoryScreen> {
  List<_InventoryItem> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadItems();
  }

  Future<void> _loadItems() async {
    final prefs = await SharedPreferences.getInstance();
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) {
      setState(() {
        _loading = false;
        _items = [];
      });
      return;
    }
    final data = prefs.getString('inventory_\$salonId');
    if (data != null) {
      final List<dynamic> decoded = json.decode(data) as List<dynamic>;
      _items = decoded.map((e) => _InventoryItem.fromJson(e as Map<String, dynamic>)).toList();
    }
    setState(() {
      _loading = false;
    });
  }

  Future<void> _saveItems() async {
    final prefs = await SharedPreferences.getInstance();
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final encoded = json.encode(_items.map((e) => e.toJson()).toList());
    await prefs.setString('inventory_\$salonId', encoded);
  }

  void _showAddEditDialog({int? index}) {
    final l = AppLocalizations.of(context);
    final isEdit = index != null;
    String name = isEdit ? _items[index!].name : '';
    String qtyStr = isEdit ? _items[index!].quantity.toString() : '';
    String priceStr = isEdit ? _items[index!].price.toString() : '';
    final nameController = TextEditingController(text: name);
    final qtyController = TextEditingController(text: qtyStr);
    final priceController = TextEditingController(text: priceStr);
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(isEdit ? l.translate('edit_product') : l.translate('add_product')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(labelText: l.translate('product_name'), hintText: l.translate('enter_name')),
                ),
                TextField(
                  controller: qtyController,
                  decoration: InputDecoration(labelText: l.translate('product_quantity'), hintText: l.translate('enter_quantity')),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: priceController,
                  decoration: InputDecoration(labelText: l.translate('product_price'), hintText: l.translate('enter_price')),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(l.translate('cancel')),
            ),
            ElevatedButton(
              onPressed: () {
                final nameVal = nameController.text.trim();
                final qtyVal = int.tryParse(qtyController.text.trim());
                final priceVal = double.tryParse(priceController.text.trim());
                if (nameVal.isEmpty || qtyVal == null || qtyVal < 0 || priceVal == null || priceVal < 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(l.translate('error_invalid_input'))),
                  );
                  return;
                }
                setState(() {
                  if (isEdit) {
                    _items[index!] = _InventoryItem(name: nameVal, quantity: qtyVal, price: priceVal);
                  } else {
                    _items.add(_InventoryItem(name: nameVal, quantity: qtyVal, price: priceVal));
                  }
                });
                _saveItems();
                Navigator.pop(context);
              },
              child: Text(l.translate('save')),
            ),
          ],
        );
      },
    );
  }

  void _deleteItem(int index) {
    setState(() {
      _items.removeAt(index);
    });
    _saveItems();
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final salonId = ref.watch(selectedSalonProvider);
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (salonId == null) {
      return Scaffold(
        appBar: AppBar(title: Text(l.translate('inventory'))),
        body: Center(child: Text(l.translate('please_select_salon'))),
      );
    }
    final hasLowStock = _items.any((it) => it.quantity < 5);
    return Scaffold(
      appBar: AppBar(title: Text(l.translate('inventory'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (hasLowStock)
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: LuxuryCard(
                leading: const Icon(Icons.warning_amber_rounded, color: AppColors.errorRed),
                title: l.translate('low_stock_alert'),
                subtitle: l.translate('low_stock_message'),
                trailing: LuxuryButton(
                  label: l.translate('order_now'),
                  filled: false,
                  onPressed: () {
                    Navigator.pushNamed(context, '/manage/inventory/orders');
                  },
                ),
              ),
            ),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              LuxuryCard(
                leading: const Icon(Icons.local_shipping, color: AppColors.gold),
                title: l.translate('suppliers'),
                subtitle: l.translate('manage_suppliers'),
                onTap: () => Navigator.pushNamed(context, '/manage/inventory/suppliers'),
              ),
              LuxuryCard(
                leading: const Icon(Icons.receipt_long, color: AppColors.gold),
                title: l.translate('purchase_orders'),
                subtitle: l.translate('pending_orders'),
                onTap: () => Navigator.pushNamed(context, '/manage/inventory/orders'),
              ),
            ],
          ),
          const SizedBox(height: 24),
          if (_items.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 32),
                child: Text(
                  l.translate('no_products'),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
            )
          else
            ...List.generate(_items.length, (i) {
              final it = _items[i];
              final isLow = it.quantity < 5;
              return Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: LuxuryCard(
                  leading: Icon(
                    isLow ? Icons.warning_amber_rounded : Icons.inventory_2,
                    color: isLow ? AppColors.errorRed : AppColors.gold,
                  ),
                  title: it.name,
                  subtitle: '${l.translate('stock')}: ${it.quantity}  ·  \$${it.price.toStringAsFixed(2)}',
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () => _showAddEditDialog(index: i),
                        tooltip: l.translate('edit_product'),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () => _deleteItem(i),
                        tooltip: l.translate('delete'),
                        color: Colors.red,
                      ),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditDialog(),
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.black,
        icon: const Icon(Icons.add),
        label: Text(l.translate('add_product')),
      ),
    );
  }
}

/// Simple model for an inventory item.
class _InventoryItem {
  final String name;
  final int quantity;
  final double price;

  _InventoryItem({required this.name, required this.quantity, required this.price});

  factory _InventoryItem.fromJson(Map<String, dynamic> json) => _InventoryItem(
        name: json['name'] as String? ?? '',
        quantity: json['quantity'] as int? ?? 0,
        price: (json['price'] as num?)?.toDouble() ?? 0.0,
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'quantity': quantity,
        'price': price,
      };
}