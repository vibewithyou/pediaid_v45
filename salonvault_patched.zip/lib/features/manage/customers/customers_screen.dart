import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/theme/app_theme.dart';

/// Simple data model representing a customer. Each customer has a name,
/// email address and phone number. Additional fields can be added later
/// (e.g. notes, loyalty status) and persisted accordingly.
class Customer {
  final String name;
  final String email;
  final String phone;

  Customer({required this.name, required this.email, required this.phone});

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phone: map['phone'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
    };
  }
}

/// Screen for listing and managing customers. Salon owners and managers can
/// view existing customers, search by name/email/phone, add new customers
/// and remove entries. Data is persisted per salon via SharedPreferences.
class CustomersScreen extends ConsumerStatefulWidget {
  const CustomersScreen({super.key});

  @override
  ConsumerState<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends ConsumerState<CustomersScreen> {
  final List<Customer> _customers = [];
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Load customers after first frame to ensure ref is ready
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadCustomers());
  }

  /// Loads customers for the currently selected salon. If no salon is
  /// selected, the list remains empty. Customers are stored as a JSON
  /// array under the key `customers_<salonId>` in SharedPreferences.
  Future<void> _loadCustomers() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'customers_$salonId';
    final jsonStr = prefs.getString(key);
    if (jsonStr != null) {
      final List<dynamic> decoded = jsonDecode(jsonStr);
      setState(() {
        _customers.clear();
        _customers.addAll(decoded.map((e) => Customer.fromMap(Map<String, dynamic>.from(e))));
      });
    }
  }

  /// Persists the current customer list for the selected salon.
  Future<void> _saveCustomers() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'customers_$salonId';
    final jsonStr = jsonEncode(_customers.map((c) => c.toMap()).toList());
    await prefs.setString(key, jsonStr);
  }

  /// Displays a dialog allowing the user to enter name, email and phone
  /// for a new customer. Validates input and adds the customer to
  /// the list on success.
  void _showAddCustomerDialog() {
    final l = AppLocalizations.of(context);
    String name = '';
    String email = '';
    String phone = '';
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(l.translate('add_customer')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: InputDecoration(
                    labelText: l.translate('customer_name'),
                    hintText: l.translate('enter_name'),
                  ),
                  onChanged: (v) => name = v,
                ),
                TextField(
                  decoration: InputDecoration(
                    labelText: l.translate('customer_email'),
                    hintText: l.translate('enter_email'),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  onChanged: (v) => email = v,
                ),
                TextField(
                  decoration: InputDecoration(
                    labelText: l.translate('customer_phone'),
                    hintText: l.translate('enter_phone'),
                  ),
                  keyboardType: TextInputType.phone,
                  onChanged: (v) => phone = v,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(l.translate('cancel')),
            ),
            ElevatedButton(
              onPressed: () {
                final trimmedName = name.trim();
                final trimmedEmail = email.trim();
                final trimmedPhone = phone.trim();
                if (trimmedName.isEmpty || trimmedEmail.isEmpty || trimmedPhone.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(l.translate('error_fill_fields'))),
                  );
                  return;
                }
                // Simple email and phone validation. These can be improved.
                final emailRegex = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+\$');
                final phoneRegex = RegExp(r'^[0-9+()\s-]{5,}\$');
                if (!emailRegex.hasMatch(trimmedEmail)) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(l.translate('error_invalid_email'))),
                  );
                  return;
                }
                if (!phoneRegex.hasMatch(trimmedPhone)) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(l.translate('error_invalid_phone'))),
                  );
                  return;
                }
                setState(() {
                  _customers.add(Customer(name: trimmedName, email: trimmedEmail, phone: trimmedPhone));
                });
                _saveCustomers();
                Navigator.pop(context);
              },
              child: Text(l.translate('save')),
            ),
          ],
        );
      },
    );
  }

  /// Deletes the customer at [index] and saves the list.
  void _deleteCustomer(int index) {
    setState(() {
      _customers.removeAt(index);
    });
    _saveCustomers();
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    // Filter customers by search query
    final query = _searchController.text.toLowerCase().trim();
    final List<Customer> filtered = query.isEmpty
        ? _customers
        : _customers.where((c) {
            return c.name.toLowerCase().contains(query) ||
                c.email.toLowerCase().contains(query) ||
                c.phone.toLowerCase().contains(query);
          }).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(l.translate('customers_title')),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: l.translate('add_customer'),
            onPressed: _showAddCustomerDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: l.translate('search_customers'),
                prefixIcon: const Icon(Icons.search),
                border: const OutlineInputBorder(),
              ),
              onChanged: (_) {
                setState(() {});
              },
            ),
          ),
          Expanded(
            child: filtered.isEmpty
                ? Center(
                    child: Text(
                      l.translate('no_customers'),
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final c = filtered[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: LuxuryCard(
                          leading: const CircleAvatar(child: Icon(Icons.person)),
                          title: c.name,
                          subtitle: '${c.email}\n${c.phone}',
                          trailing: IconButton(
                            icon: Icon(Icons.delete, color: Theme.of(context).colorScheme.error),
                            onPressed: () => _deleteCustomer(_customers.indexOf(c)),
                            tooltip: l.translate('delete'),
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CustomerDetailScreen(customer: c),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

/// Detail screen showing basic information about a customer. This page is
/// currently static and can be extended later with tabs for appointments,
/// gallery, notes and preferences as needed. For now it displays the
/// customer’s contact details and placeholders for future enhancements.
class CustomerDetailScreen extends StatelessWidget {
  final Customer customer;

  const CustomerDetailScreen({super.key, required this.customer});

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(customer.name)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          LuxuryCard(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: customer.name,
            subtitle: '${customer.email}\n${customer.phone}',
          ),
          const SizedBox(height: 16),
          LuxuryCard(
            leading: const Icon(Icons.star, color: AppColors.gold),
            title: 'Loyalty Level',
            subtitle: 'Gold Member',
          ),
          const SizedBox(height: 16),
          LuxuryCard(
            leading: const Icon(Icons.event_note, color: AppColors.gold),
            title: 'Appointments',
            subtitle: 'TODO: Display appointment history and upcoming bookings',
          ),
          const SizedBox(height: 16),
          LuxuryCard(
            leading: const Icon(Icons.note_alt, color: AppColors.gold),
            title: 'Notes & Documents',
            subtitle: 'TODO: Show private notes and uploaded files',
          ),
        ],
      ),
    );
  }
}