import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';

import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_chip.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Screen for managing a salon's services and price list.
///
/// This UI lets managers create, edit and delete services (name, category,
/// duration, price) without communicating with the backend. Each service is
/// represented as a simple model stored in memory. Use the TODO markers
/// to replace the in‑memory list with calls to the API once the backend
/// integration is ready. See the patch description for more details.
class ServicesScreen extends ConsumerStatefulWidget {
  const ServicesScreen({super.key});

  @override
  ConsumerState<ServicesScreen> createState() => _ServicesScreenState();
}

/// A model representing a single salon service. Each service has an ID,
/// a name, a category, a duration in minutes and a price. Instances can
/// be serialized to and from JSON for persistent storage.
class _ServiceItem {
  final String id;
  final String name;
  final String category;
  final int duration;
  final double price;
  const _ServiceItem({required this.id, required this.name, required this.category, required this.duration, required this.price});

  factory _ServiceItem.fromJson(Map<String, dynamic> json) {
    return _ServiceItem(
      id: json['id'] as String,
      name: json['name'] as String,
      category: json['category'] as String,
      duration: json['duration'] as int,
      price: (json['price'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'category': category,
      'duration': duration,
      'price': price,
    };
  }
}

class _ServicesScreenState extends ConsumerState<ServicesScreen> {
  List<_ServiceItem> _services = [];
  bool _loading = true;
  String _selectedCategoryKey = 'all';
  String _sortMode = 'name';

  @override
  void initState() {
    super.initState();
    _loadServices();
  }

  Future<void> _loadServices() async {
    final prefs = await SharedPreferences.getInstance();
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) {
      setState(() {
        _loading = false;
        _services = [];
      });
      return;
    }
    final data = prefs.getString('services_\$salonId');
    if (data != null) {
      final List<dynamic> decoded = json.decode(data) as List<dynamic>;
      _services = decoded.map((e) => _ServiceItem.fromJson(e as Map<String, dynamic>)).toList();
    }
    setState(() {
      _loading = false;
    });
  }

  Future<void> _saveServices() async {
    final prefs = await SharedPreferences.getInstance();
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final encoded = json.encode(_services.map((e) => e.toJson()).toList());
    await prefs.setString('services_\$salonId', encoded);
  }

  void _addOrEditService({_ServiceItem? existing}) {
    final l = AppLocalizations.of(context);
    final isEdit = existing != null;
    final nameController = TextEditingController(text: existing?.name ?? '');
    final categoryController = TextEditingController(text: existing?.category ?? '');
    final durationController = TextEditingController(text: existing?.duration.toString() ?? '');
    final priceController = TextEditingController(text: existing?.price.toString() ?? '');
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text(isEdit ? l.translate('edit_service') : l.translate('new_service')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(labelText: l.translate('service_name')),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: categoryController,
                  decoration: InputDecoration(labelText: l.translate('service_category')),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: durationController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: l.translate('service_duration')),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: priceController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(labelText: l.translate('service_price')),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: Text(l.translate('cancel')),
            ),
            LuxuryButton(
              onPressed: () {
                final id = existing?.id ?? DateTime.now().microsecondsSinceEpoch.toString();
                final newService = _ServiceItem(
                  id: id,
                  name: nameController.text.trim(),
                  category: categoryController.text.trim(),
                  duration: int.tryParse(durationController.text.trim()) ?? 0,
                  price: double.tryParse(priceController.text.trim().replaceAll(',', '.')) ?? 0.0,
                );
                setState(() {
                  if (isEdit) {
                    final idx = _services.indexWhere((s) => s.id == existing!.id);
                    if (idx != -1) {
                      _services[idx] = newService;
                    }
                  } else {
                    _services.add(newService);
                  }
                });
                _saveServices();
                Navigator.of(ctx).pop();
              },
              text: isEdit ? l.translate('save') : l.translate('create'),
            ),
          ],
        );
      },
    );
  }

  void _addCombinationService() {
    final l = AppLocalizations.of(context);
    final Set<String> selectedIds = {};
    final nameController = TextEditingController();
    final priceController = TextEditingController();
    final durationController = TextEditingController();

    void recomputeDefaults() {
      final selected = _services.where((s) => selectedIds.contains(s.id)).toList();
      if (selected.isEmpty) {
        return;
      }
      final totalDuration = selected.fold<int>(0, (prev, s) => prev + s.duration);
      final totalPrice = selected.fold<double>(0.0, (prev, s) => prev + s.price);
      if (nameController.text.isEmpty) {
        nameController.text = selected.map((e) => e.name.split(' ').first).join(' + ');
      }
      durationController.text = totalDuration.toString();
      priceController.text = totalPrice.toStringAsFixed(2);
    }

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx2, setState) {
            return AlertDialog(
              title: Text(l.translate('combination_title')),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(l.translate('select_services')),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: 300,
                      height: 200,
                      child: ListView(
                        children: _services
                            .map((s) => CheckboxListTile(
                                  title: Text('${s.name} (${s.duration} ${l.translate('minutes_short')} / ${s.price.toStringAsFixed(2)} €)'),
                                  value: selectedIds.contains(s.id),
                                  onChanged: (val) {
                                    setState(() {
                                      if (val == true) {
                                        selectedIds.add(s.id);
                                      } else {
                                        selectedIds.remove(s.id);
                                      }
                                      recomputeDefaults();
                                    });
                                  },
                                ))
                            .toList(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(labelText: l.translate('service_name')),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: durationController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(labelText: l.translate('service_duration')),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: priceController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(labelText: l.translate('service_price')),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.of(ctx2).pop(), child: Text(l.translate('cancel'))),
                LuxuryButton(
                  onPressed: () {
                    if (selectedIds.isEmpty) return;
                    final newItem = _ServiceItem(
                      id: DateTime.now().microsecondsSinceEpoch.toString(),
                      name: nameController.text.trim(),
                      category: l.translate('combination_category'),
                      duration: int.tryParse(durationController.text.trim()) ?? 0,
                      price: double.tryParse(priceController.text.trim().replaceAll(',', '.')) ?? 0.0,
                    );
                    setState(() {
                      _services.add(newItem);
                    });
                    _saveServices();
                    Navigator.of(ctx2).pop();
                  },
                  text: l.translate('create'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  List<_ServiceItem> _getFilteredSorted() {
    List<_ServiceItem> filtered = _services;
    if (_selectedCategoryKey != 'all') {
      final categoryName = _selectedCategoryKey;
      filtered = filtered.where((s) => s.category == categoryName).toList();
    }
    filtered.sort((a, b) {
      switch (_sortMode) {
        case 'priceAsc':
          return a.price.compareTo(b.price);
        case 'priceDesc':
          return b.price.compareTo(a.price);
        case 'durationAsc':
          return a.duration.compareTo(b.duration);
        case 'durationDesc':
          return b.duration.compareTo(a.duration);
        case 'name':
        default:
          return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      }
    });
    return filtered;
  }

  void _deleteService(_ServiceItem service) {
    final l = AppLocalizations.of(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(l.translate('delete_service')),
        content: Text(l.translate('delete_service_confirm').replaceAll('{{name}}', service.name)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(l.translate('cancel')),
          ),
          LuxuryButton(
            onPressed: () {
              setState(() {
                _services.removeWhere((s) => s.id == service.id);
              });
              _saveServices();
              Navigator.of(ctx).pop();
            },
            text: l.translate('delete'),
            variant: LuxuryButtonVariant.filled,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final salonId = ref.watch(selectedSalonProvider);
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (salonId == null) {
      return Scaffold(
        appBar: AppBar(title: Text(l.translate('manage_services'))),
        body: Center(child: Text(l.translate('please_select_salon'))),
      );
    }
    final categories = {
      'all',
      ..._services.map((s) => s.category).toSet(),
    };
    return Scaffold(
      appBar: AppBar(title: Text(l.translate('manage_services'))),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ...categories.map((cat) {
                  final isSelected = _selectedCategoryKey == cat;
                  final label = cat == 'all' ? l.translate('filter_all') : cat;
                  return LuxuryChip(
                    label: Text(label),
                    selected: isSelected,
                    onSelected: (val) {
                      setState(() {
                        _selectedCategoryKey = cat;
                      });
                    },
                  );
                }).toList(),
                DropdownButton<String>(
                  value: _sortMode,
                  items: [
                    DropdownMenuItem(value: 'name', child: Text(l.translate('sort_name'))),
                    DropdownMenuItem(value: 'priceAsc', child: Text(l.translate('sort_price_asc'))),
                    DropdownMenuItem(value: 'priceDesc', child: Text(l.translate('sort_price_desc'))),
                    DropdownMenuItem(value: 'durationAsc', child: Text(l.translate('sort_duration_asc'))),
                    DropdownMenuItem(value: 'durationDesc', child: Text(l.translate('sort_duration_desc'))),
                  ],
                  onChanged: (val) {
                    if (val != null) setState(() => _sortMode = val);
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _services.isEmpty
                  ? Center(child: Text(l.translate('no_services')))
                  : ListView.builder(
                      itemCount: _getFilteredSorted().length,
                      itemBuilder: (context, index) {
                        final s = _getFilteredSorted()[index];
                        return LuxuryCard(
                          margin: const EdgeInsets.only(bottom: 12),
                          onTap: () => _addOrEditService(existing: s),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(s.name, style: Theme.of(context).textTheme.headlineMedium),
                                    const SizedBox(height: 4),
                                    Text('${s.category} • ${s.duration} ${l.translate('minutes_short')}', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).hintColor)),
                                  ],
                                ),
                              ),
                              Text('${s.price.toStringAsFixed(2)} €', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                              IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => _deleteService(s),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: LuxuryButton(
                onPressed: () => _addOrEditService(),
                text: l.translate('new_service'),
                variant: LuxuryButtonVariant.outlined,
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: LuxuryButton(
                onPressed: _addCombinationService,
                text: l.translate('add_combination'),
                variant: LuxuryButtonVariant.outlined,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Hidden copyright string; obfuscated so it doesn't show up in the UI.
const _servicesObfuscatedCopyright = 'tobiasbecker2025';