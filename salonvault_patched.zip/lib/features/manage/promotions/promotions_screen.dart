import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_chip.dart';

/// Represents a discount promotion. A promotion has a name, a discount
/// type (percentage or fixed), a value, start and end dates and an
/// optional target (e.g. a service category). When persisted, it is
/// stored in JSON format per salon in SharedPreferences.
class Promotion {
  String id;
  String name;
  DiscountType type;
  double value;
  DateTime startDate;
  DateTime endDate;
  String target;

  Promotion({
    required this.id,
    required this.name,
    required this.type,
    required this.value,
    required this.startDate,
    required this.endDate,
    required this.target,
  });

  factory Promotion.fromMap(Map<String, dynamic> map) {
    return Promotion(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      type: map['type'] == 'fixed' ? DiscountType.fixed : DiscountType.percent,
      value: (map['value'] ?? 0).toDouble(),
      startDate: DateTime.parse(map['startDate']),
      endDate: DateTime.parse(map['endDate']),
      target: map['target'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'type': type == DiscountType.fixed ? 'fixed' : 'percent',
      'value': value,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'target': target,
    };
  }
}

/// Types of discount a promotion can have.
enum DiscountType { percent, fixed }

/// Screen for managing discount promotions. Managers can add, edit or delete
/// promotions. Promotions are stored in SharedPreferences per salon and
/// filtered by status (all, active, upcoming, expired). All strings are
/// localized using AppLocalizations.
class PromotionsScreen extends ConsumerStatefulWidget {
  const PromotionsScreen({super.key});

  @override
  ConsumerState<PromotionsScreen> createState() => _PromotionsScreenState();
}

class _PromotionsScreenState extends ConsumerState<PromotionsScreen> {
  final List<Promotion> _promotions = [];
  String _filterStatus = 'all';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadPromotions());
  }

  Future<void> _loadPromotions() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'promotions_$salonId';
    final jsonStr = prefs.getString(key);
    if (jsonStr != null) {
      final List<dynamic> decoded = jsonDecode(jsonStr);
      setState(() {
        _promotions.clear();
        _promotions.addAll(
          decoded.map((e) => Promotion.fromMap(Map<String, dynamic>.from(e))),
        );
      });
    }
  }

  Future<void> _savePromotions() async {
    final salonId = ref.read(selectedSalonProvider);
    if (salonId == null) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'promotions_$salonId';
    final jsonStr = jsonEncode(_promotions.map((p) => p.toMap()).toList());
    await prefs.setString(key, jsonStr);
  }

  void _deletePromotion(int index) {
    setState(() {
      _promotions.removeAt(index);
    });
    _savePromotions();
  }

  List<Promotion> _getFilteredPromotions() {
    final now = DateTime.now();
    switch (_filterStatus) {
      case 'active':
        return _promotions
            .where((p) => p.startDate.isBefore(now) && p.endDate.isAfter(now))
            .toList();
      case 'upcoming':
        return _promotions.where((p) => p.startDate.isAfter(now)).toList();
      case 'expired':
        return _promotions.where((p) => p.endDate.isBefore(now)).toList();
      case 'all':
      default:
        return _promotions;
    }
  }

  /// Opens a dialog to create or edit a promotion. When [existing] is provided,
  /// the dialog fields are prefilled and upon save the entry will be updated.
  void _showAddOrEditDialog({Promotion? existing}) {
    final l = AppLocalizations.of(context);
    final isEdit = existing != null;
    String name = existing?.name ?? '';
    DiscountType type = existing?.type ?? DiscountType.percent;
    double? value = existing?.value;
    DateTime startDate = existing?.startDate ?? DateTime.now();
    DateTime endDate = existing?.endDate ?? DateTime.now().add(const Duration(days: 30));
    String target = existing?.target ?? '';
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            Future<void> pickDate({required bool isStart}) async {
              final now = DateTime.now();
              final initial = isStart ? startDate : endDate;
              final picked = await showDatePicker(
                context: context,
                initialDate: initial,
                firstDate: DateTime(now.year - 1),
                lastDate: DateTime(now.year + 5),
              );
              if (picked != null) {
                setState(() {
                  if (isStart) {
                    startDate = picked;
                  } else {
                    endDate = picked;
                  }
                });
              }
            }
            return AlertDialog(
              title: Text(isEdit ? l.translate('edit_promotion') ?? l.translate('new_promotion') : l.translate('new_promotion')),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      decoration: InputDecoration(
                        labelText: l.translate('promotion_name'),
                        hintText: l.translate('promotion_name'),
                      ),
                      controller: TextEditingController(text: name),
                      onChanged: (v) => name = v,
                    ),
                    const SizedBox(height: 8),
                    DropdownButton<DiscountType>(
                      value: type,
                      onChanged: (val) => setState(() => type = val!),
                      items: DiscountType.values
                          .map(
                            (t) => DropdownMenuItem(
                              value: t,
                              child: Text(
                                t == DiscountType.percent
                                    ? l.translate('discount_percent')
                                    : l.translate('discount_fixed'),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: l.translate('promotion_value'),
                        hintText: l.translate('promotion_value'),
                      ),
                      controller: TextEditingController(text: value != null ? value.toString() : ''),
                      onChanged: (v) => value = double.tryParse(v),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => pickDate(isStart: true),
                            child: Text(
                              '${startDate.day.toString().padLeft(2, '0')}.${startDate.month.toString().padLeft(2, '0')}.${startDate.year}',
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => pickDate(isStart: false),
                            child: Text(
                              '${endDate.day.toString().padLeft(2, '0')}.${endDate.month.toString().padLeft(2, '0')}.${endDate.year}',
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      decoration: InputDecoration(
                        labelText: l.translate('promotion_target'),
                        hintText: l.translate('promotion_target'),
                      ),
                      controller: TextEditingController(text: target),
                      onChanged: (v) => target = v,
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text(l.translate('cancel') ?? 'Cancel'),
                ),
                LuxuryButton(
                  onPressed: () {
                    if (name.trim().isEmpty || value == null) {
                      // simple validation
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(l.translate('error_fill_fields'))),
                      );
                      return;
                    }
                    final newPromo = Promotion(
                      id: existing?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
                      name: name.trim(),
                      type: type,
                      value: value!,
                      startDate: startDate,
                      endDate: endDate,
                      target: target.trim(),
                    );
                    setState(() {
                      if (isEdit) {
                        final idx = _promotions.indexWhere((p) => p.id == existing!.id);
                        if (idx != -1) {
                          _promotions[idx] = newPromo;
                        }
                      } else {
                        _promotions.add(newPromo);
                      }
                    });
                    _savePromotions();
                    Navigator.of(context).pop();
                  },
                  text: l.translate(isEdit ? 'save' : 'create') ?? (isEdit ? 'Save' : 'Create'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final filteredPromos = _getFilteredPromotions();
    return Scaffold(
      appBar: AppBar(
        title: Text(l.translate('promotions_title')),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Filter chips
            Wrap(
              spacing: 8,
              children: ['all', 'active', 'upcoming', 'expired'].map((status) {
                final selected = _filterStatus == status;
                return LuxuryChip(
                  label: Text(
                    l.translate(
                      status == 'all'
                          ? 'filter_all'
                          : status == 'active'
                              ? 'filter_active'
                              : status == 'upcoming'
                                  ? 'filter_upcoming'
                                  : 'filter_expired',
                    ),
                  ),
                  selected: selected,
                  onSelected: (val) {
                    setState(() => _filterStatus = status);
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: filteredPromos.isEmpty
                  ? Center(
                      child: Text(l.translate('no_promotions')),
                    )
                  : ListView.builder(
                      itemCount: filteredPromos.length,
                      itemBuilder: (context, index) {
                        final p = filteredPromos[index];
                        final durationStr =
                            '${p.startDate.day.toString().padLeft(2, '0')}.${p.startDate.month.toString().padLeft(2, '0')}.${p.startDate.year} – ${p.endDate.day.toString().padLeft(2, '0')}.${p.endDate.month.toString().padLeft(2, '0')}.${p.endDate.year}';
                        final valStr = p.type == DiscountType.percent
                            ? '${p.value.toStringAsFixed(1)}%'
                            : '${p.value.toStringAsFixed(2)}€';
                        return LuxuryCard(
                          margin: const EdgeInsets.only(bottom: 12),
                          onTap: () => _showAddOrEditDialog(existing: p),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(p.name, style: Theme.of(context).textTheme.headlineMedium),
                                    const SizedBox(height: 4),
                                    Text(durationStr,
                                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).hintColor)),
                                    const SizedBox(height: 2),
                                    Text('${l.translate('promotion_target')}: ${p.target}',
                                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).hintColor)),
                                  ],
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(valStr, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                                  IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red),
                                    onPressed: () {
                                      final idx = _promotions.indexWhere((e) => e.id == p.id);
                                      if (idx != -1) {
                                        _deletePromotion(idx);
                                      }
                                    },
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: LuxuryButton(
                onPressed: () => _showAddOrEditDialog(),
                text: l.translate('new_promotion'),
                variant: LuxuryButtonVariant.outlined,
              ),
            ),
          ],
        ),
      ),
    );
  }
}