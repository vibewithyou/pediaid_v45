import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/salon_provider.dart';

/// A simple editor to manage the legal texts for a salon.
///
/// This screen allows a salon owner or manager to edit the four main
/// legal documents required on a public website: Impressum,
/// Datenschutzerklärung, Allgemeine Geschäftsbedingungen (AGB)
/// and a Widerrufsbelehrung. The texts are persisted locally
/// using `SharedPreferences` so they survive app restarts. A
/// backend integration can later persist these values per salon.
class LegalEditorScreen extends ConsumerStatefulWidget {
  const LegalEditorScreen({super.key});

  @override
  ConsumerState<LegalEditorScreen> createState() => _LegalEditorScreenState();
}

class _LegalEditorScreenState extends ConsumerState<LegalEditorScreen> {
  final _impressumController = TextEditingController();
  final _privacyController = TextEditingController();
  final _termsController = TextEditingController();
  final _withdrawalController = TextEditingController();

  String? _salonId;

  @override
  void initState() {
    super.initState();
    // Delay loading until after first build so that ref is available
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _salonId = ref.read(selectedSalonProvider);
      _load();
    });
  }

  /// Loads existing legal texts for the current salon from SharedPreferences.
  /// If none exist, fill with default templates so owners/managers can
  /// start editing immediately. When no salon is selected, fields remain
  /// empty and a warning will be shown.
  Future<void> _load() async {
    final id = _salonId;
    final prefs = await SharedPreferences.getInstance();
    if (id == null) {
      // Clear controllers to avoid mixing other salon data
      setState(() {
        _impressumController.text = '';
        _privacyController.text = '';
        _termsController.text = '';
        _withdrawalController.text = '';
      });
      return;
    }
    setState(() {
      _impressumController.text = prefs.getString('legal_impressum_$id') ??
          'Musterimpressum\n\nName des Salons\nStraße Hausnummer\nPLZ Ort\nLand\n\nVertreten durch: Vorname Nachname\nTelefon: +49 …\nE‑Mail: kontakt@deinsalon.de\n\nRegistereintrag: Eintragung im Handelsregister.\nRegistergericht: Amtsgericht Musterstadt\nRegisternummer: HRB 123456\nUSt‑ID: DE123456789\n\nDie EU‑Kommission stellt eine Plattform für die außergerichtliche Online‑Streitbeilegung bereit: http://ec.europa.eu/consumers/odr/.';
      _privacyController.text = prefs.getString('legal_datenschutz_$id') ??
          'Muster‑Datenschutzerklärung\n\n1. Allgemeine Hinweise\nWir informieren Sie im Folgenden über die Erhebung personenbezogener Daten bei Nutzung unserer App. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können.\n\n2. Verantwortliche Stelle\nVerantwortlich für die Datenverarbeitung ist: Name des Salons, Adresse, Kontakt.\n\n3. Datenverarbeitung beim Besuch der App\nBeim Aufrufen unserer App werden technische Daten (Browsertyp, Betriebssystem, IP‑Adresse) automatisch erfasst. Diese Daten dienen der Gewährleistung eines störungsfreien Betriebs.\n\nBitte passen Sie diesen Text entsprechend Ihrer tatsächlichen Datenverarbeitung an.';
      _termsController.text = prefs.getString('legal_agb_$id') ??
          'Muster‑AGB\n\n§1 Geltungsbereich\nDiese Allgemeinen Geschäftsbedingungen (AGB) regeln das Vertragsverhältnis zwischen dem Salon und Kund*innen für alle über die App vereinbarten Dienstleistungen.\n\n§2 Vertragsschluss\nMit der Buchung einer Dienstleistung über die App geben Sie ein verbindliches Angebot ab. Der Vertrag kommt erst mit der Bestätigung des Salons zustande.\n\n§3 Leistungen und Preise\nDie angebotenen Leistungen und Preise sind in der App aufgeführt und verstehen sich inklusive gesetzlicher Mehrwertsteuer.\n\nBitte ergänzen Sie weitere Klauseln (Zahlung, Stornierung, Haftung etc.) entsprechend Ihrer Anforderungen.';
      _withdrawalController.text = prefs.getString('legal_widerruf_$id') ??
          'Muster‑Widerrufsbelehrung\n\nWiderrufsrecht\nSie haben das Recht, binnen 14 Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen. Die Widerrufsfrist beträgt 14 Tage ab dem Tag des Vertragsschlusses.\n\nUm Ihr Widerrufsrecht auszuüben, müssen Sie uns (Name des Salons, Adresse, E‑Mail) mittels einer eindeutigen Erklärung (z.B. per E‑Mail) über Ihren Entschluss informieren.\n\nFolgen des Widerrufs\nWenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen unverzüglich und spätestens binnen 14 Tagen zurückzuzahlen.\n\nBitte prüfen Sie, ob und in welchem Umfang ein Widerrufsrecht bei Dienstleistungen besteht, und passen Sie den Text entsprechend an.';
    });
  }

  /// Persists the edited legal texts for the current salon. When no
  /// salon is selected, nothing is saved and a message is shown.
  Future<void> _save() async {
    final id = _salonId;
    if (id == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kein Salon ausgewählt – bitte wählen Sie zunächst einen Salon aus')), 
      );
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('legal_impressum_$id', _impressumController.text);
    await prefs.setString('legal_datenschutz_$id', _privacyController.text);
    await prefs.setString('legal_agb_$id', _termsController.text);
    await prefs.setString('legal_widerruf_$id', _withdrawalController.text);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Rechtstexte wurden für diesen Salon gespeichert')), 
    );
  }

  @override
  void dispose() {
    _impressumController.dispose();
    _privacyController.dispose();
    _termsController.dispose();
    _withdrawalController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Rechtstexte bearbeiten')),
      body: _salonId == null
          ? const Center(
              child: Text('Kein Salon ausgewählt. Bitte wählen Sie einen Salon aus, um die Rechtstexte zu bearbeiten.'),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text('Impressum', style: theme.textTheme.headlineMedium),
                const SizedBox(height: 8),
                LuxuryInput(
                  controller: _impressumController,
                  maxLines: 8,
                  hintText: 'Impressum Text',
                ),
                const SizedBox(height: 16),
                Text('Datenschutz', style: theme.textTheme.headlineMedium),
                const SizedBox(height: 8),
                LuxuryInput(
                  controller: _privacyController,
                  maxLines: 8,
                  hintText: 'Datenschutz Text',
                ),
                const SizedBox(height: 16),
                Text('AGB', style: theme.textTheme.headlineMedium),
                const SizedBox(height: 8),
                LuxuryInput(
                  controller: _termsController,
                  maxLines: 8,
                  hintText: 'AGB Text',
                ),
                const SizedBox(height: 16),
                Text('Widerruf', style: theme.textTheme.headlineMedium),
                const SizedBox(height: 8),
                LuxuryInput(
                  controller: _withdrawalController,
                  maxLines: 8,
                  hintText: 'Widerruf Text',
                ),
                const SizedBox(height: 24),
                LuxuryButton(
                  filled: true,
                  label: 'Speichern',
                  onPressed: _save,
                ),
              ],
            ),
    );
  }
}