import 'package:flutter/material.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

/// A simple FAQ screen with expandable questions and answers.
///
/// This page can be linked from settings or onboarding to provide
/// quick help and explanations. For now it contains a few example
/// questions; in a real app these could be loaded from a CMS or
/// localisation files.
class FaqScreen extends StatefulWidget {
  const FaqScreen({super.key});

  @override
  State<FaqScreen> createState() => _FaqScreenState();
}

class _FaqScreenState extends State<FaqScreen> {
  late final List<_FaqItem> _items;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final local = AppLocalizations.of(context);
    // Initialize FAQ items with localized questions and answers
    _items = [
      _FaqItem(question: local.translate('faq_q1'), answer: local.translate('faq_a1')),
      _FaqItem(question: local.translate('faq_q2'), answer: local.translate('faq_a2')),
      _FaqItem(question: local.translate('faq_q3'), answer: local.translate('faq_a3')),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final local = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(local.translate('help_faq_title'))),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _items.length,
        itemBuilder: (context, index) {
          final item = _items[index];
          return _FaqTile(item: item);
        },
      ),
    );
  }
}

class _FaqItem {
  final String question;
  final String answer;
  const _FaqItem({required this.question, required this.answer});
}

class _FaqTile extends StatefulWidget {
  final _FaqItem item;
  const _FaqTile({required this.item});

  @override
  State<_FaqTile> createState() => _FaqTileState();
}

class _FaqTileState extends State<_FaqTile> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        children: [
          ListTile(
            title: Text(widget.item.question, style: Theme.of(context).textTheme.bodyLarge),
            trailing: Icon(_expanded ? Icons.expand_less : Icons.expand_more),
            onTap: () {
              setState(() => _expanded = !_expanded);
            },
          ),
          if (_expanded)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(widget.item.answer, style: Theme.of(context).textTheme.bodyMedium),
            ),
        ],
      ),
    );
  }
}