import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/gallery_ai/data/gallery_repository.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';

class GalleryState {
  final GalleryScope scope;
  final GalleryFilter filter;
  final List<Media> items;
  final Set<String> selection;
  final bool isLoading;
  final bool isLoadingMore;
  final bool hasMore;
  final int page;

  const GalleryState({
    required this.scope,
    required this.filter,
    this.items = const [],
    this.selection = const {},
    this.isLoading = false,
    this.isLoadingMore = false,
    this.hasMore = true,
    this.page = 0,
  });

  GalleryState copyWith({
    GalleryScope? scope,
    GalleryFilter? filter,
    List<Media>? items,
    Set<String>? selection,
    bool? isLoading,
    bool? isLoadingMore,
    bool? hasMore,
    int? page,
  }) => GalleryState(
        scope: scope ?? this.scope,
        filter: filter ?? this.filter,
        items: items ?? this.items,
        selection: selection ?? this.selection,
        isLoading: isLoading ?? this.isLoading,
        isLoadingMore: isLoadingMore ?? this.isLoadingMore,
        hasMore: hasMore ?? this.hasMore,
        page: page ?? this.page,
      );
}

class GalleryNotifier extends Notifier<GalleryState> {
  static const int pageSize = 24;

  GalleryRepository get _repo => ref.read(galleryRepositoryProvider);

  @override
  GalleryState build() {
    // default scope public
    const scope = GalleryScope.publicFeed;
    // trigger initial load asynchronously so build can return fast
    Future.microtask(() => _loadInitial(scope));
    return const GalleryState(scope: scope, filter: GalleryFilter());
  }

  Future<void> _loadInitial(GalleryScope scope) async {
    state = state.copyWith(isLoading: true, items: [], page: 0, hasMore: true);
    final result = await _repo.fetch(scope, filter: state.filter, page: 0, pageSize: pageSize);
    state = state.copyWith(isLoading: false, items: result, page: 1, hasMore: result.length == pageSize);
  }

  Future<void> refresh() async => _loadInitial(state.scope);

  Future<void> loadMore() async {
    if (state.isLoadingMore || !state.hasMore) return;
    state = state.copyWith(isLoadingMore: true);
    final more = await _repo.fetch(state.scope, filter: state.filter, page: state.page, pageSize: pageSize);
    state = state.copyWith(
      isLoadingMore: false,
      items: [...state.items, ...more],
      page: state.page + 1,
      hasMore: more.length == pageSize,
    );
  }

  void setScope(GalleryScope scope) {
    state = state.copyWith(scope: scope);
    _loadInitial(scope);
  }

  void applyFilter(GalleryFilter filter) {
    state = state.copyWith(filter: filter);
    _loadInitial(state.scope);
  }

  void toggleSelection(String id) {
    final sel = Set<String>.from(state.selection);
    if (!sel.add(id)) sel.remove(id);
    state = state.copyWith(selection: sel);
  }

  Future<void> toggleLike(String id) async {
    await _repo.toggleLike(id);
    // Trigger a small state change to update UI when favoritesOnly is enabled
    if (state.filter.favoritesOnly) await refresh();
  }

  Future<void> setVisibility(String id, MediaVisibility vis) async {
    await _repo.setVisibility(id, vis);
    // refresh in current list to reflect changes
    final idx = state.items.indexWhere((m) => m.id == id);
    if (idx != -1) {
      final updated = await _repo.getById(id);
      if (updated != null) {
        final items = [...state.items];
        items[idx] = updated;
        state = state.copyWith(items: items);
      }
    }
  }

  Future<void> uploadLocal(List<Media> newItems) async {
    await _repo.upload(newItems);
    await refresh();
  }

  Future<Media?> getById(String id) => _repo.getById(id);
}

final galleryProvider = NotifierProvider<GalleryNotifier, GalleryState>(GalleryNotifier.new);
