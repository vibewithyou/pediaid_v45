import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/gallery_ai/data/inspiration_repository.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';

class InspirationState {
  final List<Inspiration> suggestions;
  final AiTask? task;
  final bool isLoading;
  final String? error;

  const InspirationState({
    this.suggestions = const [],
    this.task,
    this.isLoading = false,
    this.error,
  });

  InspirationState copyWith({
    List<Inspiration>? suggestions,
    AiTask? task,
    bool? isLoading,
    String? error,
  }) => InspirationState(
        suggestions: suggestions ?? this.suggestions,
        task: task ?? this.task,
        isLoading: isLoading ?? this.isLoading,
        error: error,
      );
}

class InspirationNotifier extends Notifier<InspirationState> {
  InspirationRepository get _repo => ref.read(inspirationRepositoryProvider);
  StreamSubscription<AiTask>? _sub;

  @override
  InspirationState build() {
    _load();
    ref.onDispose(() => _sub?.cancel());
    return const InspirationState(isLoading: true);
  }

  Future<void> _load() async {
    try {
      final list = await _repo.getSuggestions();
      state = state.copyWith(isLoading: false, suggestions: list);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: '$e');
    }
  }

  Future<void> refresh() => _load();

  void requestMore() {
    _sub?.cancel();
    _sub = _repo.requestMoreSuggestions().listen((task) async {
      state = state.copyWith(task: task);
      if (task.status == AiTaskStatus.done) {
        await _load();
      }
    });
  }
}

final inspirationProvider = NotifierProvider<InspirationNotifier, InspirationState>(InspirationNotifier.new);
