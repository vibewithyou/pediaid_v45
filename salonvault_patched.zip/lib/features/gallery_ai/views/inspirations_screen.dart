import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/features/booking/data/booking_repository.dart';
import 'package:salonvault/features/gallery_ai/state/inspiration_state.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';

import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';

// TODO(tobiasbecker2025): This screen currently uses mocked AI suggestions via
// inspirationProvider. Once the backend AI service is available, replace
// the state management logic with API calls to fetch personalised
// recommendations and attach media to bookings accordingly.

class InspirationsScreen extends ConsumerWidget {
  const InspirationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(inspirationProvider);
    final notifier = ref.read(inspirationProvider.notifier);
    return Scaffold(
      appBar: AppBar(title: const Text('Inspirationen (KI)')),
      body: RefreshIndicator(
        onRefresh: notifier.refresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Vorschläge für dich', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(
              'Basierend auf deinen Likes und bisherigen Buchungen',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(fontStyle: FontStyle.italic),
            ),
            const SizedBox(height: 8),
            if (state.isLoading)
              const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
            else
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  for (final s in state.suggestions.take(3)) _SuggestionCard(title: s.title, imageUrl: s.imageUrl),
                ],
              ),
            const SizedBox(height: 16),
            LuxuryButton(
              onPressed: notifier.requestMore,
              filled: true,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.auto_awesome),
                  SizedBox(width: 8),
                  Text('Weitere Vorschläge anfordern'),
                ],
              ),
            ),
            const SizedBox(height: 12),
            if (state.task != null) ...[
              LinearProgressIndicator(value: state.task!.status == AiTaskStatus.done ? 1 : state.task!.progress),
              const SizedBox(height: 4),
              Text('Status: ${state.task!.status.name}  ${(state.task!.progress * 100).toStringAsFixed(0)}%'),
            ],
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                for (final s in state.suggestions)
                  _SuggestionCard(title: s.title, imageUrl: s.imageUrl),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class _SuggestionCard extends ConsumerWidget {
  final String title;
  final String imageUrl;
  const _SuggestionCard({required this.title, required this.imageUrl});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      width: 200,
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Theme.of(context).colorScheme.primary, width: 1.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Card(
          clipBehavior: Clip.antiAlias,
          color: Theme.of(context).cardTheme.color,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AspectRatio(
                aspectRatio: 4 / 5,
                child: Image.network(imageUrl, fit: BoxFit.cover),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  'Ähnlich wie deine bisherigen Favoriten',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7)),
                ),
              ),
              const SizedBox(height: 6),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: LuxuryButton(
                  onPressed: () => _attachToBooking(context, ref, imageUrl),
                  filled: false,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.add_link),
                      SizedBox(width: 6),
                      Text('Zum Booking hinzufügen'),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _attachToBooking(BuildContext context, WidgetRef ref, String imageUrl) async {
    final user = ref.read(authStateProvider).user;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bitte einloggen')));
      return;
    }
    final repo = ref.read(bookingRepositoryProvider);
    final bookingsRes = await repo.userBookings(user.id);
    List<dynamic> bookings = [];
    bookingsRes.fold((f) => bookings = [], (v) => bookings = v);
    if (bookings.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Keine aktiven Bookings')));
      return;
    }
    final bookingId = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(title: Text('Für Booking hinzufügen')), 
            for (final b in bookings)
              ListTile(
                title: Text('#${b.id} - ${_fmt(b.slot)}'),
                subtitle: Text('Service ${b.serviceId}'),
                onTap: () => Navigator.pop(ctx, b.id),
              ),
          ],
        ),
      ),
    );
    if (bookingId == null) return;
    final attachRes = await repo.attachMedia(bookingId, [imageUrl]);
    attachRes.fold(
      (f) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fehler: ${f.message}'))),
      (_) => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Zum Booking hinzugefügt'))),
    );
  }

  String _fmt(DateTime t) => '${t.day.toString().padLeft(2, '0')}.${t.month.toString().padLeft(2, '0')}.${t.year}  ${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}'.toString();
}
