import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';
import 'package:salonvault/features/gallery_ai/state/gallery_state.dart';
import 'package:salonvault/features/gallery_ai/widgets/filter_chips_bar.dart';
import 'package:salonvault/features/gallery_ai/widgets/media_grid.dart';

// TODO(tobiasbecker2025): The gallery hub currently loads media from a local
// provider and stores uploads only in memory. Once the backend is ready,
// implement API calls here for loading the public feed, personal uploads and
// salon-specific media. Also persist uploads to the backend instead of
// maintaining state locally.

class GalleryHubScreen extends ConsumerWidget {
  const GalleryHubScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Galerie'),
          bottom: TabBar(
            onTap: (i) {
              final scope = switch (i) {
                0 => GalleryScope.publicFeed,
                1 => GalleryScope.myMedia,
                _ => GalleryScope.salon,
              };
              ref.read(galleryProvider.notifier).setScope(scope);
            },
            tabs: const [
              Tab(text: 'Öffentlich'),
              Tab(text: 'Meine'),
              Tab(text: 'Salon'),
            ],
          ),
        ),
        body: const Column(
          children: [
            FilterChipsBar(),
            Expanded(child: MediaGrid()),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _pickAndUpload(context, ref),
          label: const Text('Hochladen'),
          icon: const Icon(Icons.upload),
        ),
      ),
    );
  }

  Future<void> _pickAndUpload(BuildContext context, WidgetRef ref) async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.image,
      withData: true,
      allowedExtensions: const ['png', 'jpg', 'jpeg', 'webp'],
    );
    if (result == null || result.files.isEmpty) return;
    final files = result.files.take(5).toList();

    MediaVisibility? vis = MediaVisibility.private;
    vis = await showModalBottomSheet<MediaVisibility>(
      context: context,
      builder: (context) => _VisibilitySheet(initial: vis!),
    );
    if (vis == null) return;

    // Build media items with temporary bytes and a placeholder url
    final now = DateTime.now();
    final newItems = <Media>[];
    for (final f in files) {
      final bytes = f.bytes;
      if (bytes == null) continue;
      newItems.add(Media(
        id: 'local_${now.millisecondsSinceEpoch}_${f.name}',
        ownerId: 'me',
        visibility: vis,
        imageUrl: 'https://picsum.photos/seed/${f.name.hashCode}/600/800',
        createdAt: now,
        bytes: Uint8List.fromList(bytes),
        tags: const ['Upload'],
        title: f.name,
      ));
    }
    if (newItems.isEmpty) return;
    await ref.read(galleryProvider.notifier).uploadLocal(newItems);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bilder hinzugefügt')),
      );
    }
  }
}

class _VisibilitySheet extends StatefulWidget {
  final MediaVisibility initial;
  const _VisibilitySheet({required this.initial});

  @override
  State<_VisibilitySheet> createState() => _VisibilitySheetState();
}

class _VisibilitySheetState extends State<_VisibilitySheet> {
  late MediaVisibility _vis = widget.initial;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Sichtbarkeit wählen', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            RadioListTile<MediaVisibility>(
              value: MediaVisibility.private,
              groupValue: _vis,
              onChanged: (v) => setState(() => _vis = v!),
              title: const Text('Privat'),
              secondary: const Icon(Icons.lock, color: Colors.blue),
            ),
            RadioListTile<MediaVisibility>(
              value: MediaVisibility.public,
              groupValue: _vis,
              onChanged: (v) => setState(() => _vis = v!),
              title: const Text('Öffentlich'),
              secondary: const Icon(Icons.public, color: Colors.green),
            ),
            RadioListTile<MediaVisibility>(
              value: MediaVisibility.salon,
              groupValue: _vis,
              onChanged: (v) => setState(() => _vis = v!),
              title: const Text('Salon'),
              secondary: const Icon(Icons.apartment, color: Colors.orange),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(_vis),
              child: const Text('Übernehmen'),
            ),
          ],
        ),
      ),
    );
  }
}
