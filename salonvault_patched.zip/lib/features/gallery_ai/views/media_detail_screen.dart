import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/features/chat/models/attachment.dart';
import 'package:salonvault/features/chat/models/participant.dart';
import 'package:salonvault/features/chat/state/chat_state.dart';
import 'package:salonvault/models/stylist.dart';
import 'package:salonvault/features/gallery_ai/state/gallery_state.dart';

class MediaDetailScreen extends ConsumerWidget {
  final String id;
  const MediaDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder<Media?>(
      future: ref.read(galleryProvider.notifier).getById(id),
      builder: (context, snap) {
        final media = snap.data;
        final isLoading = snap.connectionState != ConnectionState.done;
        return Scaffold(
          appBar: AppBar(title: const Text('Detailansicht'), actions: [
            IconButton(
              icon: const Icon(Icons.favorite, color: Colors.red),
              onPressed: () => ref.read(galleryProvider.notifier).toggleLike(id),
            )
          ]),
          body: isLoading
              ? const Center(child: CircularProgressIndicator())
              : media == null
                  ? const Center(child: Text('Nicht gefunden'))
                  : _Body(media: media),
        );
      },
    );
  }
}

class _Body extends ConsumerStatefulWidget {
  final Media media;
  const _Body({required this.media});

  @override
  ConsumerState<_Body> createState() => _BodyState();
}

class _BodyState extends ConsumerState<_Body> {
  late Media _media = widget.media;
  final _tagController = TextEditingController();

  @override
  void dispose() {
    _tagController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: InteractiveViewer(
            child: _media.bytes != null
                ? Image.memory(_media.bytes!, fit: BoxFit.contain)
                : Image.network(_media.imageUrl, fit: BoxFit.contain),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final t in _media.tags)
                    InputChip(
                      label: Text(t),
                      onDeleted: () {
                        setState(() {
                          final tags = [..._media.tags]..remove(t);
                          _media = _media.copyWith(tags: tags);
                        });
                        // TODO: persist tags via API when backend available
                      },
                    ),
                  SizedBox(
                    width: 160,
                    child: TextField(
                      controller: _tagController,
                      decoration: const InputDecoration(hintText: 'Tag hinzufügen'),
                      onSubmitted: (v) {
                        if (v.trim().isEmpty) return;
                        setState(() {
                          final tags = {..._media.tags, v.trim()}.toList();
                          _media = _media.copyWith(tags: tags);
                          _tagController.clear();
                        });
                        // TODO: persist tags via API when backend available
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('Sichtbarkeit: '),
                  DropdownButton<MediaVisibility>(
                    value: _media.visibility,
                    onChanged: (v) async {
                      if (v == null) return;
                      if (_media.visibility == MediaVisibility.public && v != MediaVisibility.public) {
                        final proceed = await _confirmVisibility(context);
                        if (!proceed) return;
                      }
                      await ref.read(galleryProvider.notifier).setVisibility(_media.id, v);
                      setState(() => _media = _media.copyWith(visibility: v));
                    },
                    items: const [
                      DropdownMenuItem(value: MediaVisibility.public, child: Text('Öffentlich')),
                      DropdownMenuItem(value: MediaVisibility.private, child: Text('Privat')),
                      DropdownMenuItem(value: MediaVisibility.salon, child: Text('Salon')),
                    ],
                  ),
                  const Spacer(),
                  FilledButton.icon(
                    onPressed: () {
                      // Simulate attach to booking
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Zum Booking hinzugefügt')),
                      );
                    },
                    icon: const Icon(Icons.bookmark_add),
                    label: const Text('Zum Booking hinzufügen'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: () async {
                  // Warn for public media share safety
                  final ok = await showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('Mit Stylist teilen'),
                          content: const Text('Salon/Stylisten dürfen dieses Bild sehen. Fortfahren?'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
                            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Teilen')),
                          ],
                        ),
                      ) ??
                      false;
                  if (!ok) return;
                  final stylist = await _pickStylist(context, ref);
                  if (stylist == null) return;
                  final meKey = ref.read(myChatKeyProvider);
                  final isStylist = meKey.startsWith('stylist:');
                  final myId = meKey.split(':').last;
                  final me = Participant(
                    id: myId,
                    type: isStylist ? ChatActorType.stylist : ChatActorType.user,
                    displayName: isStylist ? 'Ich (Stylist)' : 'Ich',
                  );
                  final other = Participant(
                    id: stylist.id,
                    type: ChatActorType.stylist,
                    displayName: stylist.name,
                    avatarUrl: stylist.avatar,
                  );
                  final conv = await ref.read(chatActionsProvider).createConversation(
                    participants: [me, other],
                    initialAttachments: [Attachment(
                      id: DateTime.now().microsecondsSinceEpoch.toString(),
                      type: AttachmentType.media,
                      media: [MediaRef(_media.id)],
                      createdAt: DateTime.now(),
                    )],
                  );
                  if (context.mounted) context.push('/chat/${conv.id}');
                },
                icon: const Icon(Icons.share),
                label: const Text('Mit Stylist teilen'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<Stylist?> _pickStylist(BuildContext context, WidgetRef ref) async {
    final selectedSalonId = ref.read(selectedSalonProvider);
    final salonId = selectedSalonId ?? '1';
    final stylists = await ref.read(salonStylistsProvider(salonId).future);
    return showDialog<Stylist>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Stylist auswählen'),
        content: SizedBox(
          width: 320,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: stylists.length,
            itemBuilder: (_, i) {
              final s = stylists[i];
              return ListTile(
                leading: CircleAvatar(backgroundImage: s.avatar != null ? NetworkImage(s.avatar!) : null, child: s.avatar == null ? const Icon(Icons.person) : null),
                title: Text(s.name),
                onTap: () => Navigator.pop(ctx, s),
              );
            },
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Abbrechen'))],
      ),
    );
  }

  Future<bool> _confirmVisibility(BuildContext context) async {
    final res = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Sichtbarkeit ändern'),
        content: const Text('Salon/Stylisten dürfen dieses Bild sehen. Fortfahren?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Ja')),
        ],
      ),
    );
    return res ?? false;
  }
}
