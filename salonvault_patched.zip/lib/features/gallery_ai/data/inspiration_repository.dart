import 'dart:async';
import 'dart:math';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/features/gallery_ai/data/gallery_repository.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';

abstract class InspirationRepository {
  Future<List<Inspiration>> getSuggestions();
  Stream<AiTask> requestMoreSuggestions();
}

final inspirationRepositoryProvider = Provider<InspirationRepository>((ref) {
  return MockInspirationRepository(ref);
});

class MockInspirationRepository implements InspirationRepository {
  final Ref ref;
  MockInspirationRepository(this.ref);

  @override
  Future<List<Inspiration>> getSuggestions() async {
    // Build suggestions using likes and tags heuristics
    final repo = ref.read(galleryRepositoryProvider) as MockGalleryRepository;
    final userId = ref.read(authStateProvider).user?.id ?? 'u1';
    // gather liked media
    final liked = <String>[];
    // private access to map not exposed; approximate by filtering from public fetch
    final recent = await repo.fetch(
      GalleryScope.publicFeed,
      filter: const GalleryFilter(),
      page: 0,
      pageSize: 200,
    );
    for (final m in recent) {
      if (await repo.isLiked(m.id)) liked.add(m.id);
    }
    // compute tag scores
    final tagScore = <String, int>{};
    for (final m in recent) {
      final base = liked.contains(m.id) ? 3 : 1;
      for (final t in m.tags) {
        tagScore[t] = (tagScore[t] ?? 0) + base;
      }
    }
    // pick inspirations favoring high-scoring tags + recentness
    final rand = Random(userId.hashCode);
    final candidates = recent.take(50).toList();
    candidates.shuffle(rand);
    final inspirations = candidates.take(12).map((m) {
      final s = m.tags.fold<double>(0, (p, t) => p + (tagScore[t] ?? 0));
      final score = s / (m.tags.length == 0 ? 1 : m.tags.length);
      return Inspiration(
        id: 'insp_${m.id}',
        title: m.title ?? 'Idee',
        imageUrl: m.imageUrl,
        score: score,
        tags: m.tags,
      );
    }).toList()
      ..sort((a, b) => b.score.compareTo(a.score));
    return inspirations.take(6).toList();
  }

  @override
  Stream<AiTask> requestMoreSuggestions() async* {
    // Mock task stream that progresses from pending -> running -> done
    final id = 'task_${DateTime.now().millisecondsSinceEpoch}';
    var task = AiTask(
      id: id,
      status: AiTaskStatus.pending,
      progress: 0,
      createdAt: DateTime.now(),
    );
    yield task;
    await Future<void>.delayed(const Duration(milliseconds: 400));
    task = task.copyWith(status: AiTaskStatus.running, progress: 0.2);
    yield task;
    for (int i = 3; i <= 10; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      task = task.copyWith(progress: i / 10);
      yield task;
    }
    await Future<void>.delayed(const Duration(milliseconds: 350));
    yield task.copyWith(status: AiTaskStatus.done, progress: 1.0);
  }
}
