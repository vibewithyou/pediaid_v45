import 'package:flutter/foundation.dart';

/// Visibility levels for media
enum MediaVisibility { public, private, salon }

/// Reference to a media used by booking/sharing flows
class MediaRef {
  final String id;
  const MediaRef(this.id);
}

/// Lightweight media model for the gallery
class Media {
  final String id;
  final String ownerId;
  final String? salonId;
  final MediaVisibility visibility;
  final String? title;
  final List<String> tags;
  final String imageUrl; // mock network image url
  final Uint8List? bytes; // used for freshly uploaded local images on web
  final DateTime createdAt;

  const Media({
    required this.id,
    required this.ownerId,
    required this.visibility,
    required this.imageUrl,
    required this.createdAt,
    this.salonId,
    this.title,
    this.tags = const [],
    this.bytes,
  });

  Media copyWith({
    String? id,
    String? ownerId,
    String? salonId,
    MediaVisibility? visibility,
    String? title,
    List<String>? tags,
    String? imageUrl,
    Uint8List? bytes,
    DateTime? createdAt,
  }) => Media(
        id: id ?? this.id,
        ownerId: ownerId ?? this.ownerId,
        salonId: salonId ?? this.salonId,
        visibility: visibility ?? this.visibility,
        title: title ?? this.title,
        tags: tags ?? this.tags,
        imageUrl: imageUrl ?? this.imageUrl,
        bytes: bytes ?? this.bytes,
        createdAt: createdAt ?? this.createdAt,
      );
}

/// AI Inspiration card
class Inspiration {
  final String id;
  final String title;
  final String imageUrl;
  final double score; // mock relevance score
  final List<String> tags;

  const Inspiration({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.score,
    this.tags = const [],
  });
}

enum AiTaskStatus { pending, running, done, error }

class AiTask {
  final String id;
  final AiTaskStatus status;
  final double progress; // 0..1
  final DateTime createdAt;
  final String? error;

  const AiTask({
    required this.id,
    required this.status,
    required this.progress,
    required this.createdAt,
    this.error,
  });

  AiTask copyWith({
    AiTaskStatus? status,
    double? progress,
    String? error,
  }) => AiTask(
        id: id,
        status: status ?? this.status,
        progress: progress ?? this.progress,
        createdAt: createdAt,
        error: error ?? this.error,
      );
}

/// Filters for the gallery grid
class GalleryFilter {
  final String? style;
  final String? length;
  final String? color;
  final List<String> tags;
  final MediaVisibility? visibility;
  final bool favoritesOnly;

  const GalleryFilter({
    this.style,
    this.length,
    this.color,
    this.tags = const [],
    this.visibility,
    this.favoritesOnly = false,
  });

  GalleryFilter copyWith({
    String? style,
    String? length,
    String? color,
    List<String>? tags,
    MediaVisibility? visibility,
    bool? favoritesOnly,
  }) => GalleryFilter(
        style: style ?? this.style,
        length: length ?? this.length,
        color: color ?? this.color,
        tags: tags ?? this.tags,
        visibility: visibility ?? this.visibility,
        favoritesOnly: favoritesOnly ?? this.favoritesOnly,
      );
}

/// Scope of gallery tab
enum GalleryScope { publicFeed, myMedia, salon }
