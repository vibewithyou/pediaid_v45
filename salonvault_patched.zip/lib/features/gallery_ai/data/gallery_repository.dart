import 'dart:async';
import 'dart:math';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';

abstract class GalleryRepository {
  Future<List<Media>> fetch(
    GalleryScope scope, {
    required GalleryFilter filter,
    required int page,
    required int pageSize,
  });

  Future<bool> toggleLike(String mediaId);
  Future<bool> isLiked(String mediaId);
  Future<Media> setVisibility(String mediaId, MediaVisibility visibility);
  Future<List<Media>> upload(
    List<Media> newItems,
  );
  Future<Media?> getById(String id);
}

final galleryRepositoryProvider = Provider<GalleryRepository>((ref) {
  return MockGalleryRepository(ref);
});

class MockGalleryRepository implements GalleryRepository {
  final Ref ref;
  final List<Media> _items = [];
  final Map<String, bool> _likes = {};
  bool _seeded = false;

  MockGalleryRepository(this.ref) {
    _seedIfNeeded();
  }

  Future<void> _seedIfNeeded() async {
    if (_seeded) return;
    _seeded = true;
    final user = ref.read(authStateProvider).user;
    final userId = user?.id ?? 'u1';
    final now = DateTime.now();
    final rand = Random(42);
    // Generate mock media with picsum
    for (int i = 0; i < 60; i++) {
      final vis = i % 3 == 0
          ? MediaVisibility.public
          : (i % 3 == 1 ? MediaVisibility.private : MediaVisibility.salon);
      _items.add(
        Media(
          id: 'm$i',
          ownerId: i % 4 == 0 ? userId : 'other',
          salonId: i % 4 == 2 ? 'salon-123' : null,
          visibility: vis,
          imageUrl: 'https://picsum.photos/seed/gallery_$i/600/800',
          createdAt: now.subtract(Duration(days: rand.nextInt(180))),
          tags: [
            ['Bob', 'Pixie', 'Fade'][i % 3],
            ['Kurz', 'Mittel', 'Lang'][i % 3],
            ['Blond', 'Braun', 'Rot'][i % 3],
          ],
          title: 'Style #$i',
        ),
      );
    }
    await _loadLikes();
  }

  Future<void> _loadLikes() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = ref.read(authStateProvider).user?.id ?? 'guest';
    final list = prefs.getStringList('likes_$userId') ?? [];
    _likes
      ..clear()
      ..addEntries(list.map((id) => MapEntry(id, true)));
  }

  Future<void> _saveLikes() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = ref.read(authStateProvider).user?.id ?? 'guest';
    final list = _likes.entries.where((e) => e.value).map((e) => e.key).toList();
    await prefs.setStringList('likes_$userId', list);
  }

  @override
  Future<List<Media>> fetch(
    GalleryScope scope, {
    required GalleryFilter filter,
    required int page,
    required int pageSize,
  }) async {
    await _seedIfNeeded();
    // Filter by scope
    final userId = ref.read(authStateProvider).user?.id ?? 'u1';
    Iterable<Media> data = _items;
    switch (scope) {
      case GalleryScope.publicFeed:
        data = data.where((m) => m.visibility == MediaVisibility.public);
        break;
      case GalleryScope.myMedia:
        data = data.where((m) => m.ownerId == userId);
        break;
      case GalleryScope.salon:
        data = data.where((m) => m.visibility == MediaVisibility.salon);
        break;
    }
    // Apply filters
    if (filter.visibility != null) {
      data = data.where((m) => m.visibility == filter.visibility);
    }
    if (filter.style != null) {
      data = data.where((m) => m.tags.contains(filter.style));
    }
    if (filter.length != null) {
      data = data.where((m) => m.tags.contains(filter.length));
    }
    if (filter.color != null) {
      data = data.where((m) => m.tags.contains(filter.color));
    }
    if (filter.tags.isNotEmpty) {
      data = data.where((m) => filter.tags.every((t) => m.tags.contains(t)));
    }
    if (filter.favoritesOnly) {
      data = data.where((m) => _likes[m.id] == true);
    }
    // Sort newest first
    final list = data.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    // Paging
    final start = page * pageSize;
    final end = min(start + pageSize, list.length);
    if (start >= list.length) return [];
    return list.sublist(start, end);
  }

  @override
  Future<bool> toggleLike(String mediaId) async {
    _likes[mediaId] = !(_likes[mediaId] ?? false);
    await _saveLikes();
    return _likes[mediaId] ?? false;
  }

  @override
  Future<bool> isLiked(String mediaId) async {
    return _likes[mediaId] ?? false;
  }

  @override
  Future<Media> setVisibility(String mediaId, MediaVisibility visibility) async {
    final idx = _items.indexWhere((m) => m.id == mediaId);
    if (idx == -1) throw StateError('Media not found');
    final updated = _items[idx].copyWith(visibility: visibility);
    _items[idx] = updated;
    return updated;
  }

  @override
  Future<List<Media>> upload(List<Media> newItems) async {
    _items.addAll(newItems);
    return newItems;
  }

  @override
  Future<Media?> getById(String id) async {
    await _seedIfNeeded();
    try {
      return _items.firstWhere((m) => m.id == id);
    } catch (_) {
      return null;
    }
  }
}
