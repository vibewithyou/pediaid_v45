import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';
import 'package:salonvault/features/gallery_ai/state/gallery_state.dart';

Future<List<MediaRef>?> showBookingAttachPicker(BuildContext context, WidgetRef ref) async {
  return showModalBottomSheet<List<MediaRef>>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => const _AttachPickerSheet(),
  );
}

class _AttachPickerSheet extends ConsumerStatefulWidget {
  const _AttachPickerSheet();

  @override
  ConsumerState<_AttachPickerSheet> createState() => _AttachPickerSheetState();
}

class _AttachPickerSheetState extends ConsumerState<_AttachPickerSheet> {
  GalleryScope _scope = GalleryScope.myMedia;

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(galleryProvider);
    final notifier = ref.read(galleryProvider.notifier);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Bilder anhängen', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 12),
            SegmentedButton<GalleryScope>(
              segments: const [
                ButtonSegment(value: GalleryScope.myMedia, label: Text('Eigene Bilder')),
                ButtonSegment(value: GalleryScope.publicFeed, label: Text('Öffentliche Galerie')),
                ButtonSegment(value: GalleryScope.salon, label: Text('KI-Vorschläge')),
              ],
              selected: {_scope},
              onSelectionChanged: (s) {
                setState(() => _scope = s.first);
                notifier.setScope(_scope);
              },
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 300,
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemCount: state.items.length,
                itemBuilder: (context, index) {
                  final m = state.items[index];
                  final selected = state.selection.contains(m.id);
                  return GestureDetector(
                    onTap: () => notifier.toggleSelection(m.id),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        m.bytes != null
                            ? Image.memory(m.bytes!, fit: BoxFit.cover)
                            : Image.network(m.imageUrl, fit: BoxFit.cover),
                        if (selected)
                          Container(
                            color: Colors.black.withValues(alpha: 0.4),
                            child: const Icon(Icons.check_circle, color: Colors.lightGreenAccent, size: 36),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('Abbrechen')),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () {
                    final refs = state.selection.map((e) => MediaRef(e)).toList();
                    Navigator.pop(context, refs);
                  },
                  child: const Text('Hinzufügen'),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
