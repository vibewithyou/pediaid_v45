import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/widgets/luxury_chip.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';
import 'package:salonvault/features/gallery_ai/state/gallery_state.dart';

class FilterChipsBar extends ConsumerWidget {
  const FilterChipsBar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(galleryProvider);
    final notifier = ref.read(galleryProvider.notifier);
    final filter = state.filter;

    void update({String? style, String? length, String? color, bool? favs}) {
      notifier.applyFilter(filter.copyWith(
        style: style ?? filter.style,
        length: length ?? filter.length,
        color: color ?? filter.color,
        favoritesOnly: favs ?? filter.favoritesOnly,
      ));
    }

    final styles = const ['Bob', 'Pixie', 'Fade'];
    final lengths = const ['Kurz', 'Mittel', 'Lang'];
    final colors = const ['Blond', 'Braun', 'Rot'];

    return Container(
      color: Theme.of(context).colorScheme.surface,
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          // Favourites chip
          LuxuryChip(
            label: 'Favoriten',
            selected: filter.favoritesOnly,
            onSelected: (v) => update(favs: v),
          ),
          const SizedBox(width: 8),
          // Style chips
          for (final s in styles) ...[
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: LuxuryChip(
                label: 'Stil: $s',
                selected: filter.style == s,
                onSelected: (val) => update(style: filter.style == s ? null : s),
              ),
            ),
          ],
          // Length chips
          for (final l in lengths) ...[
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: LuxuryChip(
                label: 'Länge: $l',
                selected: filter.length == l,
                onSelected: (val) => update(length: filter.length == l ? null : l),
              ),
            ),
          ],
          // Colour chips
          for (final c in colors) ...[
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: LuxuryChip(
                label: 'Farbe: $c',
                selected: filter.color == c,
                onSelected: (val) => update(color: filter.color == c ? null : c),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
