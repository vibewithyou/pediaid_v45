import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';
import 'package:salonvault/features/gallery_ai/state/gallery_state.dart';
import 'package:salonvault/features/gallery_ai/data/gallery_repository.dart';

// TODO(tobiasbecker2025): integrate backend for media retrieval, likes and
// filtering. Currently the media grid uses locally mocked data via
// galleryProvider. Replace with API calls once the Laravel backend is ready.

class MediaGrid extends ConsumerStatefulWidget {
  const MediaGrid({super.key});

  @override
  ConsumerState<MediaGrid> createState() => _MediaGridState();
}

class _MediaGridState extends ConsumerState<MediaGrid> {
  final _controller = ScrollController();

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_controller.hasClients) return;
    final max = _controller.position.maxScrollExtent;
    final offset = _controller.offset;
    if (max - offset < 400) {
      ref.read(galleryProvider.notifier).loadMore();
    }
  }

  @override
  void dispose() {
    _controller
      ..removeListener(_onScroll)
      ..dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(galleryProvider);
    final notifier = ref.read(galleryProvider.notifier);
    final items = state.items;
    // Determine number of columns based on screen width. Use 2 columns on small
    // screens, 3 on tablet and 4 on desktop to better utilise space.
    final width = MediaQuery.of(context).size.width;
    int crossAxisCount = 2;
    if (width >= 1024) {
      crossAxisCount = 4;
    } else if (width >= 600) {
      crossAxisCount = 3;
    }
    final grid = GridView.builder(
      key: const PageStorageKey('media_grid'),
      controller: _controller,
      padding: const EdgeInsets.all(8),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 0.75,
      ),
      itemCount: items.length + (state.isLoadingMore ? 2 : 0),
      itemBuilder: (context, index) {
        if (index >= items.length) {
          return const Center(child: CircularProgressIndicator());
        }
        final m = items[index];
        return _ThumbTile(media: m, onTap: () => context.push('/gallery/${m.id}'));
      },
    );

    if (state.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (items.isEmpty) {
      return RefreshIndicator(
        onRefresh: notifier.refresh,
        child: ListView(
          children: const [
            SizedBox(height: 120),
            Center(child: Text('Keine Ergebnisse. Filter anpassen oder hochladen.')),
            SizedBox(height: 240),
          ],
        ),
      );
    }
    return RefreshIndicator(onRefresh: notifier.refresh, child: grid);
  }
}

class _ThumbTile extends ConsumerStatefulWidget {
  final Media media;
  final VoidCallback onTap;
  const _ThumbTile({required this.media, required this.onTap});

  @override
  ConsumerState<_ThumbTile> createState() => _ThumbTileState();
}

class _ThumbTileState extends ConsumerState<_ThumbTile> {
  bool _hovering = false;
  bool _liked = false;

  @override
  void initState() {
    super.initState();
    _loadLike();
  }

  Future<void> _loadLike() async {
    final repo = ref.read(galleryRepositoryProvider);
    final liked = await repo.isLiked(widget.media.id);
    if (mounted) setState(() => _liked = liked);
  }

  @override
  Widget build(BuildContext context) {
    final notifier = ref.read(galleryProvider.notifier);
    return MouseRegion(
      onEnter: (_) => setState(() => _hovering = true),
      onExit: (_) => setState(() => _hovering = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _hovering ? 1.03 : 1.0,
          duration: const Duration(milliseconds: 150),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Semantics(
              // Provide an accessible description for the media tile. If
              // a title is set on the media object use it, otherwise
              // fallback to a generic label. Mark this as an image so
              // screen readers announce it appropriately.
              label: widget.media.title ?? 'Galeriebild',
              image: true,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (widget.media.bytes != null)
                    Image.memory(widget.media.bytes!, fit: BoxFit.cover)
                  else
                    Image.network(widget.media.imageUrl, fit: BoxFit.cover),
                  // On hover, apply a subtle primary coloured overlay
                  AnimatedOpacity(
                    opacity: _hovering ? 0.08 : 0.0,
                    duration: const Duration(milliseconds: 150),
                    child: Container(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Material(
                      color: Theme.of(context).colorScheme.background.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(20),
                      child: IconButton(
                        tooltip: _liked ? 'Aus Favoriten entfernen' : 'Zu Favoriten hinzufügen',
                        onPressed: () async {
                          await notifier.toggleLike(widget.media.id);
                          // Toggle local state to update icon
                          setState(() => _liked = !_liked);
                        },
                        icon: Icon(_liked ? Icons.favorite : Icons.favorite_border),
                        color: _liked ? Colors.red : Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ),
                  Positioned(
                    left: 8,
                    top: 8,
                    child: _VisibilityBadge(visibility: widget.media.visibility),
                  ),
                  // Book now button overlay (mock) visible on hover
                  if (_hovering)
                    Positioned(
                      bottom: 8,
                      left: 8,
                      right: 8,
                      child: Semantics(
                        label: 'Jetzt buchen',
                        button: true,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.8),
                            foregroundColor: Colors.black,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            padding: const EdgeInsets.symmetric(vertical: 8),
                          ),
                          onPressed: () {
                            // Trigger booking wizard with preselected service (mock)
                            // When implementing, pass service id or style tag. See TODO.
                            Navigator.pushNamed(context, '/booking');
                          },
                          child: const Text('Buchen'),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _VisibilityBadge extends StatelessWidget {
  final MediaVisibility visibility;
  const _VisibilityBadge({required this.visibility});

  @override
  Widget build(BuildContext context) {
    final (icon, label, color) = switch (visibility) {
      MediaVisibility.public => (Icons.public, 'Öffentlich', Colors.green),
      MediaVisibility.private => (Icons.lock, 'Privat', Colors.blue),
      MediaVisibility.salon => (Icons.apartment, 'Salon', Colors.orange),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [Icon(icon, size: 14, color: color), const SizedBox(width: 4), Text(label)],
      ),
    );
  }
}
