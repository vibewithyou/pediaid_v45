import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

/// Simple onboarding flow presented as a series of pages with a title,
/// description and placeholder image. This screen is optional and
/// accessible via the `/onboarding` route. It demonstrates how
/// onboarding can look and can be expanded later with real assets
/// and internationalisation.
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _pageIndex = 0;

  /// A list of page definitions. The [titleKey], [descKey] and [altKey]
  /// correspond to translation keys in [AppLocalizations], and [imageAsset]
  /// points to the asset file. We build the actual pages in the build
  /// method so they update when the locale changes.
  final List<Map<String, String>> _pageDefs = const [
    {
      'titleKey': 'onboarding_title_1',
      'descKey': 'onboarding_desc_1',
      // Use the newly generated salon visuals for a more luxurious feel.
      'image': 'assets/images/onboarding_gen1.png',
      'altKey': 'onboarding_image_1_alt',
    },
    {
      'titleKey': 'onboarding_title_2',
      'descKey': 'onboarding_desc_2',
      'image': 'assets/images/onboarding_gen2.png',
      'altKey': 'onboarding_image_2_alt',
    },
    {
      'titleKey': 'onboarding_title_3',
      'descKey': 'onboarding_desc_3',
      'image': 'assets/images/onboarding_gen3.png',
      'altKey': 'onboarding_image_3_alt',
    },
    {
      'titleKey': 'onboarding_title_4',
      'descKey': 'onboarding_desc_4',
      // Re‑use the second generated image for the fourth slide
      'image': 'assets/images/onboarding_gen2.png',
      'altKey': 'onboarding_image_4_alt',
    },
    {
      'titleKey': 'onboarding_title_5',
      'descKey': 'onboarding_desc_5',
      // Re‑use the third generated image for the final slide
      'image': 'assets/images/onboarding_gen3.png',
      'altKey': 'onboarding_image_5_alt',
    },
  ];

  void _next() {
    if (_pageIndex < _pages.length - 1) {
      _controller.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final localizations = AppLocalizations.of(context);
    // Build pages based on current translations.
    final pages = _pageDefs
        .map((def) => _OnboardingPage(
              title: localizations.translate(def['titleKey']!),
              description: localizations.translate(def['descKey']!),
              imageAsset: def['image']!,
              altText: localizations.translate(def['altKey']!),
            ))
        .toList();
    final pageCount = pages.length;
    return Scaffold(
      appBar: AppBar(
        title: Text(localizations.translate('onboarding')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              localizations.translate('onboarding_skip'),
              style: const TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _controller,
              onPageChanged: (i) => setState(() => _pageIndex = i),
              itemCount: pageCount,
              itemBuilder: (context, index) {
                final page = pages[index];
                return Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          alignment: Alignment.center,
                          child: Image.asset(
                            page.imageAsset,
                            fit: BoxFit.contain,
                            semanticLabel: page.altText,
                            errorBuilder: (context, error, stackTrace) {
                              // Fall back to a grey block if image missing
                              return Container(
                                width: 200,
                                height: 200,
                                color: theme.colorScheme.surfaceVariant,
                              );
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        page.title,
                        style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        page.description,
                        style: theme.textTheme.bodyLarge,
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          pageCount,
                          (i) => Container(
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: i == _pageIndex ? AppColors.gold : theme.unselectedWidgetColor,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      LuxuryButton(
                        label: _pageIndex == pageCount - 1
                            ? localizations.translate('onboarding_start')
                            : localizations.translate('onboarding_next'),
                        onPressed: _next,
                        filled: true,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _OnboardingPage {
  final String title;
  final String description;
  final String imageAsset;
  final String altText;

  const _OnboardingPage({
    required this.title,
    required this.description,
    required this.imageAsset,
    this.altText = '',
  });
}