import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/providers/salon_provider.dart';

/// Displays the Widerrufsbelehrung for the currently selected salon.
///
/// Each salon can define its own withdrawal policy via the Legal Editor.
/// If no policy has been saved for the chosen salon, a placeholder is
/// shown. When no salon is selected, an info message is displayed.
class WithdrawalScreen extends ConsumerWidget {
  const WithdrawalScreen({super.key});

  Future<String> _loadWithdrawal(String? salonId) async {
    final prefs = await SharedPreferences.getInstance();
    if (salonId == null) {
      return 'Kein Salon ausgewählt. Bitte wählen Sie einen Salon, um die Widerrufsbelehrung zu sehen.';
    }
    final key = 'legal_widerruf_$salonId';
    final stored = prefs.getString(key);
    if (stored != null) return stored;
    // Fallback template if no custom withdrawal policy has been saved yet
    return 'Muster‑Widerrufsbelehrung\n\nWiderrufsrecht\nSie haben das Recht, binnen 14 Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen. Die Widerrufsfrist beträgt 14 Tage ab dem Tag des Vertragsschlusses.\n\nUm Ihr Widerrufsrecht auszuüben, müssen Sie uns (Name des Salons, Adresse, E‑Mail) mittels einer eindeutigen Erklärung (z.B. per E‑Mail) über Ihren Entschluss informieren.\n\nFolgen des Widerrufs\nWenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen unverzüglich und spätestens binnen 14 Tagen zurückzuzahlen.\n\nBitte prüfen Sie, ob und in welchem Umfang ein Widerrufsrecht bei Dienstleistungen besteht, und passen Sie den Text entsprechend an.';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final salonId = ref.watch(selectedSalonProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Widerruf')),
      body: FutureBuilder<String>(
        future: _loadWithdrawal(salonId),
        builder: (context, snapshot) {
          final text = snapshot.data ?? '';
          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Text(
              text,
              style: const TextStyle(fontSize: 16, height: 1.5),
            ),
          );
        },
      ),
    );
  }
}