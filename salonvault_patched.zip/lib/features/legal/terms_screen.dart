import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:salonvault/core/providers/salon_provider.dart';

/// Displays the Allgemeine Geschäftsbedingungen (AGB) for the currently
/// selected salon. If no salon is selected or the salon has not yet
/// customized their AGB, the visitor sees a placeholder informing them
/// that no terms have been provided.
class TermsScreen extends ConsumerWidget {
  const TermsScreen({super.key});

  Future<String> _loadTerms(String? salonId) async {
    final prefs = await SharedPreferences.getInstance();
    if (salonId == null) {
      return 'Kein Salon ausgewählt. Bitte wählen Sie einen Salon, um dessen AGB zu sehen.';
    }
    // Use a salon‑specific key so each salon can define its own legal texts
    final key = 'legal_agb_$salonId';
    final stored = prefs.getString(key);
    if (stored != null) return stored;
    // Fallback to a default template so that legal information is always available
    return 'Muster‑AGB\n\n§1 Geltungsbereich\nDiese Allgemeinen Geschäftsbedingungen (AGB) regeln das Vertragsverhältnis zwischen dem Salon und Kund*innen für alle über die App vereinbarten Dienstleistungen.\n\n§2 Vertragsschluss\nMit der Buchung einer Dienstleistung über die App geben Sie ein verbindliches Angebot ab. Der Vertrag kommt erst mit der Bestätigung des Salons zustande.\n\n§3 Leistungen und Preise\nDie angebotenen Leistungen und Preise sind in der App aufgeführt und verstehen sich inklusive gesetzlicher Mehrwertsteuer.\n\nBitte ergänzen Sie weitere Klauseln (Zahlung, Stornierung, Haftung etc.) entsprechend Ihrer Anforderungen.';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedSalonId = ref.watch(selectedSalonProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('AGB')),
      body: FutureBuilder<String>(
        future: _loadTerms(selectedSalonId),
        builder: (context, snapshot) {
          final text = snapshot.data ?? '';
          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Text(
              text,
              style: const TextStyle(fontSize: 16, height: 1.5),
            ),
          );
        },
      ),
    );
  }
}