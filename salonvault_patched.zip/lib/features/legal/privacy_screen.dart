import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/salon_provider.dart';

class PrivacyScreen extends ConsumerWidget {
  const PrivacyScreen({super.key});

  Future<String> _loadPrivacy(String? salonId) async {
    final prefs = await SharedPreferences.getInstance();
    if (salonId == null) {
      return 'Kein Salon ausgewählt. Bitte wählen Sie einen Salon, um die Datenschutzerklärung zu sehen.';
    }
    final key = 'legal_datenschutz_$salonId';
    final stored = prefs.getString(key);
    if (stored != null) return stored;
    // Default data protection template if none has been saved
    return 'Muster‑Datenschutzerklärung\n\n1. Allgemeine Hinweise\nWir informieren Sie im Folgenden über die Erhebung personenbezogener Daten bei Nutzung unserer App. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können.\n\n2. Verantwortliche Stelle\nVerantwortlich für die Datenverarbeitung ist: Name des Salons, Adresse, Kontakt.\n\n3. Datenverarbeitung beim Besuch der App\nBeim Aufrufen unserer App werden technische Daten (Browsertyp, Betriebssystem, IP‑Adresse) automatisch erfasst. Diese Daten dienen der Gewährleistung eines störungsfreien Betriebs.\n\nBitte passen Sie diesen Text entsprechend Ihrer tatsächlichen Datenverarbeitung an.';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final salonId = ref.watch(selectedSalonProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Datenschutz')),
      body: FutureBuilder<String>(
        future: _loadPrivacy(salonId),
        builder: (context, snapshot) {
          final text = snapshot.data ?? '';
          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Text(
              text,
              style: const TextStyle(fontSize: 16, height: 1.5),
            ),
          );
        },
      ),
    );
  }
}
