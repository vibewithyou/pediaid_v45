import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/salon_provider.dart';

class ImpressumScreen extends ConsumerWidget {
  const ImpressumScreen({super.key});

  Future<String> _loadImpressum(String? salonId) async {
    final prefs = await SharedPreferences.getInstance();
    if (salonId == null) {
      return 'Kein Salon ausgewählt. Bitte wählen Sie einen Salon, um das Impressum zu sehen.';
    }
    final key = 'legal_impressum_$salonId';
    final stored = prefs.getString(key);
    if (stored != null) return stored;
    // Default template if no custom Impressum exists
    return 'Musterimpressum\n\nName des Salons\nStraße Hausnummer\nPLZ Ort\nLand\n\nVertreten durch: Vorname Nachname\nTelefon: +49 …\nE‑Mail: kontakt@deinsalon.de\n\nRegistereintrag: Eintragung im Handelsregister.\nRegistergericht: Amtsgericht Musterstadt\nRegisternummer: HRB 123456\nUSt‑ID: DE123456789\n\nDie EU‑Kommission stellt eine Plattform für die außergerichtliche Online‑Streitbeilegung bereit: http://ec.europa.eu/consumers/odr/.\n';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final salonId = ref.watch(selectedSalonProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Impressum')),
      body: FutureBuilder<String>(
        future: _loadImpressum(salonId),
        builder: (context, snapshot) {
          final text = snapshot.data ?? '';
          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Text(
              text,
              style: const TextStyle(fontSize: 16, height: 1.5),
            ),
          );
        },
      ),
    );
  }
}
