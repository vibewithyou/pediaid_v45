import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_chip.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/utils/snackbar_utils.dart';

/// NotificationsScreen presents a simple inbox for system and marketing
/// notifications. All data is currently mocked until the backend is
/// integrated. When real APIs exist, replace the hard coded lists and
/// callbacks marked with TODO(tobiasbecker2025).
class NotificationsScreen extends ConsumerStatefulWidget {
  const NotificationsScreen({super.key});

  @override
  ConsumerState<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends ConsumerState<NotificationsScreen> {
  /// Holds the currently selected filter. Notifications can be filtered
  /// by type (all, bookings, promotions, system). In the future the
  /// available types should come from the backend. See TODO below.
  String _selectedFilter = 'All';

  /// Mock notifications list. Each entry contains an id, title,
  /// description, datetime and type. The type corresponds to the
  /// filters above. When the backend is ready, this list should be
  /// populated via an API call and stored in a provider. See
  /// TODO(tobiasbecker2025) markers below.
  final List<_NotificationItem> _notifications = [
    _NotificationItem(
      id: '1',
      title: 'Buchung bestätigt',
      description: 'Ihre Buchung am 24. Okt um 14:00 Uhr ist bestätigt.',
      dateTime: DateTime.now().subtract(const Duration(hours: 2)),
      type: 'Bookings',
    ),
    _NotificationItem(
      id: '2',
      title: 'Neue Aktion: 10% Rabatt',
      description: 'Sichern Sie sich jetzt 10% Rabatt auf alle Haarpflegeprodukte.',
      dateTime: DateTime.now().subtract(const Duration(days: 1)),
      type: 'Promotions',
    ),
    _NotificationItem(
      id: '3',
      title: 'Systemwartung',
      description: 'Geplante Wartung am Freitag um 22:00 Uhr für 30 Minuten.',
      dateTime: DateTime.now().subtract(const Duration(days: 2)),
      type: 'System',
    ),
    _NotificationItem(
      id: '4',
      title: 'Treuepunkte eingelöst',
      description: 'Sie haben 50 Punkte für einen Gutschein eingelöst.',
      dateTime: DateTime.now().subtract(const Duration(days: 3)),
      type: 'Bookings',
    ),
  ];

  /// Mock set of notification types used for filtering. When the
  /// notifications API is implemented, derive these from the returned
  /// notifications. See TODO(tobiasbecker2025) below.
  final List<String> _types = ['All', 'Bookings', 'Promotions', 'System'];

  /// Set storing the ids of notifications marked as read. This state is
  /// local to the screen for now. When integrated with backend, use
  /// persistent storage and update via API. See TODO(tobiasbecker2025).
  final Set<String> _readIds = {};

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    // Build list of filtered notifications based on selected filter.
    final filtered = _selectedFilter == 'All'
        ? _notifications
        : _notifications.where((n) => n.type == _selectedFilter).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: Column(
        children: [
          // Filter bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: _types.map((type) {
                  final selected = _selectedFilter == type;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: LuxuryChip(
                      label: type,
                      isSelected: selected,
                      onTap: () {
                        setState(() => _selectedFilter = type);
                      },
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          // Action bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${filtered.length} Notifications', style: theme.textTheme.bodyMedium),
                LuxuryButton(
                  label: 'Mark all read',
                  filled: false,
                  onPressed: () {
                    // Mark all notifications as read. In the future,
                    // make an API call to mark them on the server.
                    setState(() {
                      _readIds.addAll(_notifications.map((n) => n.id));
                    });
                    // Show confirmation toast
                    showLuxurySnackBar(context, 'Alle Benachrichtigungen als gelesen markiert', SnackType.success);
                  },
                ),
              ],
            ),
          ),
          // Notification list
          Expanded(
            child: filtered.isEmpty
                ? Center(
                    child: Text('Keine Benachrichtigungen', style: theme.textTheme.bodyMedium),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final n = filtered[index];
                      final read = _readIds.contains(n.id);
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: GestureDetector(
                          onTap: () {
                            // On tap mark as read and show details. When
                            // implementing, navigate or show dialog with
                            // notification details. See TODO below.
                            setState(() => _readIds.add(n.id));
                            showLuxurySnackBar(context, 'Benachrichtigung geöffnet', SnackType.info);
                          },
                          child: LuxuryCard(
                            title: n.title,
                            subtitle: '${n.description}\n${_formatDate(n.dateTime)}',
                            trailing: Icon(
                              read ? Icons.done : Icons.notifications,
                              color: read ? AppColors.successGreen : AppColors.gold,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  /// Helper to format a DateTime into a short string. Localizes
  /// to the user locale later.
  String _formatDate(DateTime dt) {
    return '${dt.day.toString().padLeft(2, '0')}.${dt.month.toString().padLeft(2, '0')}.${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }
}

/// Internal model class for notifications. In the future this should be
/// moved into a shared models folder and populated via an API call.
class _NotificationItem {
  final String id;
  final String title;
  final String description;
  final DateTime dateTime;
  final String type;
  _NotificationItem({
    required this.id,
    required this.title,
    required this.description,
    required this.dateTime,
    required this.type,
  });
}

// Hidden constant for copyright claim; not used in UI.
const _obfuscatedNotifications = 'tobiasbecker2025';