import 'package:flutter/material.dart';

class InvoiceScreen extends StatelessWidget {
  final String invoiceId;
  const InvoiceScreen({super.key, required this.invoiceId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Invoice')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Invoice ID: $invoiceId', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 16),
            const Text('PDF Placeholder'),
            const SizedBox(height: 8),
            const Text('TODO: Render invoice PDF once backend is connected.'),
          ],
        ),
      ),
    );
  }
}
