import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/widgets/luxury_chip.dart';

class MapSearchScreen extends ConsumerStatefulWidget {
  const MapSearchScreen({super.key});

  @override
  ConsumerState<MapSearchScreen> createState() => _MapSearchScreenState();
}

class _MapSearchScreenState extends ConsumerState<MapSearchScreen> {
  final _mapController = MapController();
  bool _showList = false;
  final Set<String> _selectedFilters = {};

  @override
  Widget build(BuildContext context) {
    final salonsAsync = ref.watch(salonsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Find Salons'),
        actions: [
          IconButton(
            icon: Icon(_showList ? Icons.map : Icons.list),
            onPressed: () => setState(() => _showList = !_showList),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (!_showList)
            salonsAsync.when(
              data: (salons) => FlutterMap(
                mapController: _mapController,
                options: MapOptions(
                  initialCenter: LatLng(52.5200, 13.4050),
                  initialZoom: 12,
                ),
                children: [
                  TileLayer(
                    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.salonvault.app',
                  ),
                  MarkerLayer(
                    markers: salons.map((salon) => Marker(
                      point: LatLng(salon.lat, salon.lng),
                      width: 40,
                      height: 40,
                      child: GestureDetector(
                        onTap: () => context.push('/salon/${salon.id}'),
                        child: Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: AppColors.gold,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.3),
                                blurRadius: 4,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: const Icon(Icons.location_on, color: AppColors.black, size: 20),
                        ),
                      ),
                    )).toList(),
                  ),
                ],
              ),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => Center(child: Text('Error: $error')),
            ),
          if (_showList)
            salonsAsync.when(
              data: (salons) => ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: salons.length,
                itemBuilder: (context, index) {
                  final salon = salons[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    child: ListTile(
                      leading: Icon(Icons.store, color: AppColors.gold),
                      title: Text(salon.name),
                      subtitle: Text(salon.address),
                      trailing: Text('${salon.rating} ⭐'),
                      onTap: () => context.push('/salon/${salon.id}'),
                    ),
                  );
                },
              ),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => Center(child: Text('Error: $error')),
            ),
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Wrap(
                  spacing: 8,
                  children: [
                    for (final filter in ['Distance', 'Price', 'Rating', 'Available'])
                      LuxuryChip(
                        label: filter,
                        selected: _selectedFilters.contains(filter),
                        onSelected: (selected) {
                          setState(() {
                            if (selected) {
                              _selectedFilters.add(filter);
                            } else {
                              _selectedFilters.remove(filter);
                            }
                          });
                        },
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
