import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/features/salon_templates/state/template_state.dart';
import 'package:salonvault/features/salon_templates/entities.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class SalonHomeScreen extends ConsumerWidget {
  final String salonId;

  const SalonHomeScreen({super.key, required this.salonId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final salonAsync = ref.watch(salonDetailProvider(salonId));
    final servicesAsync = ref.watch(salonServicesProvider(salonId));
    final stylistsAsync = ref.watch(salonStylistsProvider(salonId));

    final tState = ref.watch(salonTemplateProvider(salonId));
    if (tState == null || tState.isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final tokens = tState.template.tokens;
    final blocks = [...tState.template.blocks]
            .where((b) => b.visible)
            .toList()
          ..sort((a, b) => a.order.compareTo(b.order));

        final themed = _themeFromTokens(context, tokens);
        return Theme(
          data: themed,
          child: Scaffold(
        body: salonAsync.when(
          data: (salon) => CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 250,
                pinned: true,
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => context.pop(),
                ),
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        salon.images.first,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: AppColors.mediumGrey,
                          child: Icon(Icons.store, size: 80, color: AppColors.gold),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withValues(alpha: 0.7),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 16,
                        left: 16,
                        right: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              salon.name,
                              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                                color: AppColors.white,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(Icons.star, size: 20, color: AppColors.gold),
                                const SizedBox(width: 4),
                                Text(
                                  '${salon.rating} (${salon.reviewCount})',
                                  style: const TextStyle(color: AppColors.white, fontSize: 16),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                // Removed TabBar. Layout is driven by template blocks below.
              ),
              SliverList(
                delegate: SliverChildListDelegate([
                  for (final b in blocks) ...[
                    _buildBlock(context, b, salon, servicesAsync, stylistsAsync),
                    const SizedBox(height: 16),
                  ]
                ]),
              )
            ],
          ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(child: Text('Error: $error')),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => context.push('/booking'),
          backgroundColor: AppColors.gold,
          foregroundColor: AppColors.black,
          icon: const Icon(Icons.calendar_today),
          label: const Text('Book Now'),
        ),
          ),
        );
  }

  Widget _buildInfoTab(BuildContext context, salon) => SingleChildScrollView(
    padding: const EdgeInsets.all(24),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('About', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 12),
        Text(salon.description ?? 'No description available', style: Theme.of(context).textTheme.bodyLarge),
        const SizedBox(height: 24),
        Text('Contact', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 12),
        if (salon.phone != null) ...[
          Row(
            children: [
              Icon(Icons.phone, color: AppColors.gold),
              const SizedBox(width: 12),
              Text(salon.phone!, style: Theme.of(context).textTheme.bodyLarge),
            ],
          ),
          const SizedBox(height: 8),
        ],
        Row(
          children: [
            Icon(Icons.location_on, color: AppColors.gold),
            const SizedBox(width: 12),
            Expanded(child: Text(salon.address, style: Theme.of(context).textTheme.bodyLarge)),
          ],
        ),
        const SizedBox(height: 24),
        Text('Opening Hours', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 12),
        if (salon.openingHours != null)
          ...salon.openingHours!.entries.map((e) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(e.key, style: Theme.of(context).textTheme.bodyLarge),
                Text(e.value, style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          )),
      ],
    ),
  );

  Widget _buildServicesTab(BuildContext context, servicesAsync) => servicesAsync.when(
    data: (services) {
      return LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 600;
          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: isWide ? 2 : 1,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: isWide ? 3.5 : 3,
            ),
            itemCount: services.length,
            itemBuilder: (context, index) {
              final service = services[index];
              final subtitleParts = <String>[];
              if (service.description != null && service.description!.isNotEmpty) {
                subtitleParts.add(service.description!);
              }
              subtitleParts.add('${service.durationMinutes} min');
              subtitleParts.add('€${service.price.toStringAsFixed(2)}');
              return LuxuryCard(
                leading: const Icon(Icons.cut, color: AppColors.gold),
                title: service.name,
                subtitle: subtitleParts.join(' · '),
                onTap: () {},
              );
            },
          );
        },
      );
    },
    loading: () => const Center(child: CircularProgressIndicator()),
    error: (error, _) => Center(child: Text('Error: $error')),
  );

  Widget _buildTeamTab(BuildContext context, stylistsAsync) => stylistsAsync.when(
    data: (stylists) {
      return LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 600;
          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: isWide ? 2 : 1,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: isWide ? 3.5 : 3,
            ),
            itemCount: stylists.length,
            itemBuilder: (context, index) {
              final stylist = stylists[index];
              final specialties = stylist.specialties.join(' · ');
              final subtitleParts = <String>[];
              if (stylist.bio != null && stylist.bio!.isNotEmpty) {
                subtitleParts.add(stylist.bio!);
              }
              if (specialties.isNotEmpty) {
                subtitleParts.add(specialties);
              }
              final subtitle = subtitleParts.join(' · ');
              return LuxuryCard(
                leading: CircleAvatar(
                  radius: 24,
                  backgroundImage: stylist.avatar != null ? NetworkImage(stylist.avatar!) : null,
                  child: stylist.avatar == null
                      ? const Icon(Icons.person, color: AppColors.gold)
                      : null,
                ),
                title: stylist.name,
                subtitle: subtitle.isNotEmpty ? subtitle : null,
                onTap: () {},
              );
            },
          );
        },
      );
    },
    loading: () => const Center(child: CircularProgressIndicator()),
    error: (error, _) => Center(child: Text('Error: $error')),
  );

  Widget _buildPromoTab(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Text('No active promotions', style: Theme.of(context).textTheme.bodyMedium),
    ),
  );

  Widget _buildBlock(
    BuildContext context,
    LayoutBlock block,
    dynamic salon,
    AsyncValue servicesAsync,
    AsyncValue stylistsAsync,
  ) {
    switch (block.type) {
      case LayoutBlockType.info:
        return _SectionCard(title: block.data['title'] as String? ?? 'Info', child: _buildInfoTab(context, salon));
      case LayoutBlockType.services:
        return _SectionCard(title: block.data['title'] as String? ?? 'Services', child: _buildServicesTab(context, servicesAsync));
      case LayoutBlockType.team:
        return _SectionCard(title: block.data['title'] as String? ?? 'Team', child: _buildTeamTab(context, stylistsAsync));
      case LayoutBlockType.promo:
        return _SectionCard(title: block.data['title'] as String? ?? 'Aktionen', child: _buildPromoTab(context));
      case LayoutBlockType.gallery:
        return _SectionCard(
          title: block.data['title'] as String? ?? 'Galerie',
          child: _buildGalleryTab(context),
        );
    }
  }

  Widget _buildGalleryPlaceholder(BuildContext context) => Container(
        padding: const EdgeInsets.all(24),
        child: Center(child: Text('Galerie (bald)', style: Theme.of(context).textTheme.bodyMedium)),
      );

  /// Builds the gallery section for the salon. If no images have been
  /// uploaded yet for this salon, a localized placeholder is shown. Once
  /// images exist, they are displayed in a grid. This uses
  /// [SharedPreferences] to load base64 encoded images saved via the
  /// [SalonGalleryEditor].
  Widget _buildGalleryTab(BuildContext context) {
    return FutureBuilder<List<String>>(
      future: _loadGalleryImages(),
      builder: (context, snapshot) {
        final l = AppLocalizations.of(context);
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              l.translate('gallery_public_empty'),
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          );
        }
        final images = snapshot.data!;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.all(12),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1,
          ),
          itemCount: images.length,
          itemBuilder: (context, index) {
            final b64 = images[index];
            return ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.memory(
                base64Decode(b64),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: Colors.grey.shade300,
                ),
              ),
            );
          },
        );
      },
    );
  }

  /// Loads the list of gallery images (as base64 strings) for this salon
  /// from [SharedPreferences]. The key is based on the salon ID.
  Future<List<String>> _loadGalleryImages() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'gallery_${salonId}';
    final listString = prefs.getString(key);
    if (listString == null) return [];
    try {
      final decoded = json.decode(listString);
      if (decoded is List) {
        return decoded.whereType<String>().toList();
      }
    } catch (_) {
      // ignore errors and return empty list
    }
    return [];
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;
  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.headlineLarge),
            const SizedBox(height: 8),
            child,
          ],
        ),
      ),
    );
  }
}

ThemeData _themeFromTokens(BuildContext context, SalonThemeTokens t) {
  final base = t.dark ? Theme.of(context).copyWith(brightness: Brightness.dark) : Theme.of(context).copyWith(brightness: Brightness.light);
  final colorScheme = (t.dark ? const ColorScheme.dark() : const ColorScheme.light()).copyWith(
    primary: t.primary,
    secondary: t.accent,
  );
  return base.copyWith(
    colorScheme: colorScheme,
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(backgroundColor: t.primary, foregroundColor: t.dark ? Colors.black : Colors.black),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(foregroundColor: t.accent, side: BorderSide(color: t.accent, width: 1.5)),
    ),
    appBarTheme: base.appBarTheme.copyWith(backgroundColor: t.dark ? Colors.black : Colors.white, foregroundColor: t.accent),
  );
}
