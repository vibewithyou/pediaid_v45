import 'package:salonvault/features/chat/models/attachment.dart';
import 'package:salonvault/features/chat/models/participant.dart';

class Message {
  final String id;
  final String conversationId;
  final ChatActorType senderType;
  final String senderId; // domain id (userId/stylistId)
  final String? text;
  final List<Attachment> attachments;
  final DateTime sentAt;
  final Set<String> seenBy; // participant keys

  const Message({
    required this.id,
    required this.conversationId,
    required this.senderType,
    required this.senderId,
    this.text,
    this.attachments = const [],
    required this.sentAt,
    this.seenBy = const {},
  });

  String get senderKey => switch (senderType) {
        ChatActorType.user => 'user:$senderId',
        ChatActorType.stylist => 'stylist:$senderId',
        ChatActorType.system => 'system',
      };

  bool isSeenBy(String participantKey) => seenBy.contains(participantKey);

  Message copyWith({
    String? id,
    String? conversationId,
    ChatActorType? senderType,
    String? senderId,
    String? text,
    List<Attachment>? attachments,
    DateTime? sentAt,
    Set<String>? seenBy,
  }) => Message(
        id: id ?? this.id,
        conversationId: conversationId ?? this.conversationId,
        senderType: senderType ?? this.senderType,
        senderId: senderId ?? this.senderId,
        text: text ?? this.text,
        attachments: attachments ?? this.attachments,
        sentAt: sentAt ?? this.sentAt,
        seenBy: seenBy ?? this.seenBy,
      );
}
