import 'package:salonvault/features/chat/models/message.dart';
import 'package:salonvault/features/chat/models/participant.dart';

class Conversation {
  final String id;
  final List<Participant> participants;
  final String? bookingId; // optional booking association
  final DateTime updatedAt;
  final Message? lastMessage;
  final Set<String> unreadBy; // participant keys who have unread messages

  const Conversation({
    required this.id,
    required this.participants,
    this.bookingId,
    required this.updatedAt,
    this.lastMessage,
    this.unreadBy = const {},
  });

  Conversation copyWith({
    String? id,
    List<Participant>? participants,
    String? bookingId,
    DateTime? updatedAt,
    Message? lastMessage,
    Set<String>? unreadBy,
  }) => Conversation(
        id: id ?? this.id,
        participants: participants ?? this.participants,
        bookingId: bookingId ?? this.bookingId,
        updatedAt: updatedAt ?? this.updatedAt,
        lastMessage: lastMessage ?? this.lastMessage,
        unreadBy: unreadBy ?? this.unreadBy,
      );

  bool hasUnread(String participantKey) => unreadBy.contains(participantKey);
}
