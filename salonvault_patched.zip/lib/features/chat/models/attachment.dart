import 'package:salonvault/features/gallery_ai/data/models.dart';

enum AttachmentType { media }

class Attachment {
  final String id;
  final AttachmentType type;
  final List<MediaRef> media;
  final DateTime createdAt;

  const Attachment({
    required this.id,
    required this.type,
    required this.media,
    required this.createdAt,
  });
}
