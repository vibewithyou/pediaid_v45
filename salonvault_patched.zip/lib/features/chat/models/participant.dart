enum ChatActorType { user, stylist, system }

class Participant {
  final String id; // domain id (userId or stylistId or 'system')
  final ChatActorType type;
  final String displayName;
  final String? avatarUrl;

  const Participant({
    required this.id,
    required this.type,
    required this.displayName,
    this.avatarUrl,
  });

  String get key => switch (type) {
        ChatActorType.user => 'user:$id',
        ChatActorType.stylist => 'stylist:$id',
        ChatActorType.system => 'system',
      };
}
