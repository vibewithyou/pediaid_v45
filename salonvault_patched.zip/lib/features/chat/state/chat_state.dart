import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/features/chat/data/chat_repository.dart';
import 'package:salonvault/features/chat/models/attachment.dart';
import 'package:salonvault/features/chat/models/conversation.dart';
import 'package:salonvault/features/chat/models/message.dart';
import 'package:salonvault/features/chat/models/participant.dart';

final myChatKeyProvider = Provider<String>((ref) {
  final user = ref.watch(authStateProvider).user;
  if (user == null) return 'user:guest';
  // If the app user role is stylist, use stylist key; else customer user key
  final isStylist = user.role.name == 'stylist';
  return isStylist ? 'stylist:${user.id}' : 'user:${user.id}';
});

final conversationsProvider = StreamProvider<List<Conversation>>((ref) {
  final repo = ref.watch(chatRepositoryProvider);
  final myKey = ref.watch(myChatKeyProvider);
  return repo.watchConversations(myKey);
});

final messagesProvider = StreamProvider.family<List<Message>, String>((ref, conversationId) {
  final repo = ref.watch(chatRepositoryProvider);
  return repo.watchMessages(conversationId);
});

class ChatActions {
  final Ref ref;
  ChatActions(this.ref);

  ChatRepository get _repo => ref.read(chatRepositoryProvider);

  Future<Conversation> createConversation({
    required List<Participant> participants,
    String? bookingId,
    String? initialText,
    List<Attachment>? initialAttachments,
  }) {
    return _repo.createConversation(
      participants: participants,
      bookingId: bookingId,
      initialText: initialText,
      initialAttachments: initialAttachments,
    );
  }

  Future<void> send({
    required String conversationId,
    required ChatActorType senderType,
    required String senderId,
    String? text,
    List<Attachment> attachments = const [],
  }) {
    return _repo.sendMessage(
      conversationId: conversationId,
      senderType: senderType,
      senderId: senderId,
      text: text,
      attachments: attachments,
    );
  }

  Future<void> markRead(String conversationId) {
    final key = ref.read(myChatKeyProvider);
    return _repo.markAsRead(conversationId: conversationId, participantKey: key);
  }
}

final chatActionsProvider = Provider((ref) => ChatActions(ref));
