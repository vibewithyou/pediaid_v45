import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/chat/models/attachment.dart';
import 'package:salonvault/features/chat/models/participant.dart';
import 'package:salonvault/features/chat/state/chat_state.dart';
import 'package:salonvault/features/gallery_ai/widgets/booking_attach_picker.dart';
import 'package:salonvault/features/gallery_ai/data/models.dart';

class ConversationDetailScreen extends ConsumerStatefulWidget {
  final String conversationId;
  const ConversationDetailScreen({super.key, required this.conversationId});

  @override
  ConsumerState<ConversationDetailScreen> createState() => _ConversationDetailScreenState();
}

class _ConversationDetailScreenState extends ConsumerState<ConversationDetailScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final convs = ref.watch(conversationsProvider).value ?? const [];
    final conv = convs.firstWhere(
      (c) => c.id == widget.conversationId,
      orElse: () => (convs.isNotEmpty ? convs.first : null) ??
          // fallback empty conversation display when deep linking without state loaded yet
          // This keeps the screen usable until stream updates
          // ignore: unnecessary_cast
          (null as dynamic),
    );

    final msgsAsync = ref.watch(messagesProvider(widget.conversationId));
    final myKey = ref.watch(myChatKeyProvider);

    if (conv != null) {
      // mark as read when entering
      ref.read(chatActionsProvider).markRead(widget.conversationId);
    }

    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Expanded(child: Text(_titleFor(conv?.participants ?? [], myKey))),
          if (conv?.bookingId != null)
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Chip(label: Text('Booking ${conv!.bookingId}')),
            ),
        ]),
      ),
      body: Column(children: [
        Expanded(
          child: msgsAsync.when(
            data: (msgs) {
              return ListView.builder(
                controller: _scrollController,
                reverse: true,
                padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                itemCount: msgs.length,
                itemBuilder: (_, i) {
                  final m = msgs[msgs.length - 1 - i];
                  final isMe = m.senderKey == myKey;
                  return _MessageBubble(message: m, isMe: isMe);
                },
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, st) => Center(child: Text('Fehler: $e')),
          ),
        ),
        _InputBar(
          controller: _controller,
          onSend: (text) async {
            final meKey = ref.read(myChatKeyProvider);
            final isStylist = meKey.startsWith('stylist:');
            final myId = meKey.split(':').last;
            await ref.read(chatActionsProvider).send(
                  conversationId: widget.conversationId,
                  senderType: isStylist ? ChatActorType.stylist : ChatActorType.user,
                  senderId: myId,
                  text: text.trim().isEmpty ? null : text.trim(),
                );
            _controller.clear();
            _scrollToBottom();
          },
          onAttach: () async {
            final picked = await showBookingAttachPicker(context, ref);
            if (picked == null || picked.isEmpty) return;
            final attachments = _mediaRefsToAttachment(picked);
            final meKey = ref.read(myChatKeyProvider);
            final isStylist = meKey.startsWith('stylist:');
            final myId = meKey.split(':').last;
            await ref.read(chatActionsProvider).send(
              conversationId: widget.conversationId,
              senderType: isStylist ? ChatActorType.stylist : ChatActorType.user,
              senderId: myId,
              attachments: attachments,
            );
            _scrollToBottom();
          },
          onQuickBookingLink: () {
            _controller.text = (_controller.text + ( _controller.text.isEmpty ? '' : ' ' ) + 'Terminlink: /booking').trim();
            _controller.selection = TextSelection.fromPosition(TextPosition(offset: _controller.text.length));
          },
        ),
      ]),
    );
  }

  List<Attachment> _mediaRefsToAttachment(List<MediaRef> refs) {
    return [
      Attachment(id: DateTime.now().microsecondsSinceEpoch.toString(), type: AttachmentType.media, media: refs, createdAt: DateTime.now()),
    ];
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  String _titleFor(List participants, String myKey) {
    final others = participants.where((p) => p.key != myKey).toList();
    if (others.isEmpty) return 'Chat';
    return others.map((p) => p.displayName).join(', ');
  }
}

class _MessageBubble extends StatelessWidget {
  final dynamic message; // Message
  final bool isMe;
  const _MessageBubble({required this.message, required this.isMe});

  @override
  Widget build(BuildContext context) {
    final t = message.sentAt;
    final dateStr = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
    final seen = message.seenBy.length > 1; // seen by someone else besides sender
    final bubbleColor = isMe ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceVariant;
    final textColor = Theme.of(context).colorScheme.onPrimaryContainer;
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: bubbleColor,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(12),
            topRight: const Radius.circular(12),
            bottomLeft: Radius.circular(isMe ? 12 : 2),
            bottomRight: Radius.circular(isMe ? 2 : 12),
          ),
        ),
        child: Column(
          crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (message.text != null)
              Text(message.text!, style: TextStyle(color: textColor)),
            if (message.attachments.isNotEmpty) ...[
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final a in message.attachments)
                    if (a.type == AttachmentType.media)
                      _MediaThumbs(mediaRefs: a.media),
                ],
              ),
            ],
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(dateStr, style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(width: 6),
                if (isMe)
                  Icon(
                    seen ? Icons.done_all : Icons.done,
                    size: 16,
                    color: seen ? Colors.blue : Colors.grey,
                  ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class _MediaThumbs extends ConsumerWidget {
  final List<MediaRef> mediaRefs;
  const _MediaThumbs({required this.mediaRefs});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Render media refs as simple colored boxes with ids (because we don't have a repo to fetch thumbs here)
    return Wrap(
      spacing: 6,
      children: [
        for (final m in mediaRefs)
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(8),
            ),
            alignment: Alignment.center,
            child: Text(m.id, style: const TextStyle(fontSize: 10)),
          ),
      ],
    );
  }
}

class _InputBar extends StatelessWidget {
  final TextEditingController controller;
  final Future<void> Function(String text) onSend;
  final Future<void> Function() onAttach;
  final VoidCallback onQuickBookingLink;
  const _InputBar({required this.controller, required this.onSend, required this.onAttach, required this.onQuickBookingLink});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
        child: Row(
          children: [
            IconButton(onPressed: onAttach, icon: const Icon(Icons.attach_file)),
            Expanded(
              child: TextField(
                controller: controller,
                decoration: const InputDecoration(hintText: 'Nachricht schreiben', border: OutlineInputBorder()),
                minLines: 1,
                maxLines: 4,
              ),
            ),
            IconButton(onPressed: onQuickBookingLink, icon: const Icon(Icons.calendar_month)),
            const SizedBox(width: 4),
            FilledButton(
              onPressed: () => onSend(controller.text),
              child: const Icon(Icons.send),
            ),
          ],
        ),
      ),
    );
  }
}
