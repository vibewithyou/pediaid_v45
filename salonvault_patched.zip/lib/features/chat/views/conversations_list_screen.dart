import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/features/chat/models/participant.dart';
import 'package:salonvault/features/chat/state/chat_state.dart';
import 'package:salonvault/models/stylist.dart';

class ConversationsListScreen extends ConsumerStatefulWidget {
  const ConversationsListScreen({super.key});

  @override
  ConsumerState<ConversationsListScreen> createState() => _ConversationsListScreenState();
}

class _ConversationsListScreenState extends ConsumerState<ConversationsListScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final convsAsync = ref.watch(conversationsProvider);
    final myKey = ref.watch(myChatKeyProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Chats')),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final stylist = await _pickStylist(context, ref);
          if (stylist == null) return;
          final meKey = ref.read(myChatKeyProvider);
          final isStylist = meKey.startsWith('stylist:');
          final userId = meKey.split(':').last;
          final me = Participant(
            id: userId,
            type: isStylist ? ChatActorType.stylist : ChatActorType.user,
            displayName: isStylist ? 'Ich (Stylist)' : 'Ich',
          );
          final other = Participant(
            id: stylist.id,
            type: ChatActorType.stylist,
            displayName: stylist.name,
            avatarUrl: stylist.avatar,
          );
          final conv = await ref.read(chatActionsProvider).createConversation(participants: [me, other]);
          if (context.mounted) context.push('/chat/${conv.id}');
        },
        child: const Icon(Icons.chat),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Suchen...'),
            onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: convsAsync.when(
              data: (convs) {
                final filtered = convs.where((c) {
                  final title = _conversationTitle(c.participants, myKey).toLowerCase();
                  final last = (c.lastMessage?.text ?? '').toLowerCase();
                  return _query.isEmpty || title.contains(_query) || last.contains(_query);
                }).toList()
                  ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
                if (filtered.isEmpty) return const Center(child: Text('Keine Konversationen'));
                return ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final c = filtered[i];
                    final title = _conversationTitle(c.participants, myKey);
                    final subtitle = c.lastMessage?.text ?? (c.lastMessage?.attachments.isNotEmpty == true ? 'Medien' : '');
                    final unread = c.hasUnread(myKey);
                    return ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.person)),
                      title: Row(children: [
                        Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis)),
                        if (c.bookingId != null)
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Chip(label: Text('Booking ${c.bookingId}')),
                          ),
                      ]),
                      subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis),
                      trailing: unread ? const _UnreadDot() : null,
                      onTap: () => context.push('/chat/${c.id}'),
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, st) => Center(child: Text('Fehler: $e')),
            ),
          ),
        ]),
      ),
    );
  }

  String _conversationTitle(List<Participant> participants, String myKey) {
    final others = participants.where((p) => p.key != myKey).toList();
    if (others.isEmpty) return 'Ich';
    return others.map((p) => p.displayName).join(', ');
  }

  Future<Stylist?> _pickStylist(BuildContext context, WidgetRef ref) async {
    final selectedSalonId = ref.read(selectedSalonProvider);
    final salonId = selectedSalonId ?? '1';
    final stylistsAsync = await ref.read(salonStylistsProvider(salonId).future);
    return showDialog<Stylist>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Stylist auswählen'),
        content: SizedBox(
          width: 320,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: stylistsAsync.length,
            itemBuilder: (_, i) {
              final s = stylistsAsync[i];
              return ListTile(
                leading: CircleAvatar(backgroundImage: s.avatar != null ? NetworkImage(s.avatar!) : null, child: s.avatar == null ? const Icon(Icons.person) : null),
                title: Text(s.name),
                onTap: () => Navigator.pop(ctx, s),
              );
            },
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Abbrechen'))],
      ),
    );
  }
}

class _UnreadDot extends StatelessWidget {
  const _UnreadDot();
  @override
  Widget build(BuildContext context) {
    return Container(width: 12, height: 12, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle));
  }
}
