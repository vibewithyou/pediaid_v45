import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/chat/models/attachment.dart';
import 'package:salonvault/features/chat/models/conversation.dart';
import 'package:salonvault/features/chat/models/message.dart';
import 'package:salonvault/features/chat/models/participant.dart';

abstract class ChatRepository {
  Stream<List<Conversation>> watchConversations(String myParticipantKey);
  Stream<List<Message>> watchMessages(String conversationId);

  Future<Conversation> createConversation({
    required List<Participant> participants,
    String? bookingId,
    String? initialText,
    List<Attachment>? initialAttachments,
  });

  Future<void> sendMessage({
    required String conversationId,
    required ChatActorType senderType,
    required String senderId,
    String? text,
    List<Attachment> attachments = const [],
  });

  Future<void> markAsRead({required String conversationId, required String participantKey});
}

class MockChatRepository implements ChatRepository {
  final Map<String, Conversation> _conversations = {};
  final Map<String, List<Message>> _messages = {};
  final StreamController<void> _tick = StreamController.broadcast();

  int _idCounter = 0;
  String _nextId() => (++_idCounter).toString();

  @override
  Stream<List<Conversation>> watchConversations(String myParticipantKey) {
    return _tick.stream.startWith(null).map((_) {
      final all = _conversations.values.toList()
        ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      return all;
    });
  }

  @override
  Stream<List<Message>> watchMessages(String conversationId) {
    return _tick.stream.startWith(null).map((_) => List<Message>.from(_messages[conversationId] ?? const []));
  }

  @override
  Future<Conversation> createConversation({
    required List<Participant> participants,
    String? bookingId,
    String? initialText,
    List<Attachment>? initialAttachments,
  }) async {
    final id = _nextId();
    final created = Conversation(
      id: id,
      participants: participants,
      bookingId: bookingId,
      updatedAt: DateTime.now(),
      lastMessage: null,
      unreadBy: {},
    );
    _conversations[id] = created;
    _messages[id] = [];
    if (initialText != null || (initialAttachments != null && initialAttachments.isNotEmpty)) {
      // send system or first participant message? We'll attribute to the first human participant (user if present)
      final sender = participants.firstWhere(
        (p) => p.type != ChatActorType.system,
        orElse: () => participants.first,
      );
      await sendMessage(
        conversationId: id,
        senderType: sender.type,
        senderId: sender.id,
        text: initialText,
        attachments: initialAttachments ?? const [],
      );
    } else {
      _tick.add(null);
    }
    return _conversations[id]!;
  }

  @override
  Future<void> sendMessage({
    required String conversationId,
    required ChatActorType senderType,
    required String senderId,
    String? text,
    List<Attachment> attachments = const [],
  }) async {
    final conv = _conversations[conversationId];
    if (conv == null) return;
    final msg = Message(
      id: _nextId(),
      conversationId: conversationId,
      senderType: senderType,
      senderId: senderId,
      text: (text ?? '').isEmpty && attachments.isEmpty ? null : text,
      attachments: attachments,
      sentAt: DateTime.now(),
      seenBy: {switch (senderType) {
        ChatActorType.user => 'user:$senderId',
        ChatActorType.stylist => 'stylist:$senderId',
        ChatActorType.system => 'system',
      }},
    );
    final list = _messages[conversationId]!..add(msg);

    // Determine unreadBy: everyone except sender
    final senderKey = msg.senderKey;
    final unread = <String>{};
    for (final p in conv.participants) {
      final key = p.key;
      if (key != senderKey) unread.add(key);
    }
    final updated = conv.copyWith(
      lastMessage: msg,
      updatedAt: msg.sentAt,
      unreadBy: unread,
    );
    _conversations[conversationId] = updated;
    _messages[conversationId] = list;
    _tick.add(null);
  }

  @override
  Future<void> markAsRead({required String conversationId, required String participantKey}) async {
    final conv = _conversations[conversationId];
    if (conv == null) return;
    final newSet = Set<String>.from(conv.unreadBy)..remove(participantKey);
    _conversations[conversationId] = conv.copyWith(unreadBy: newSet);
    // Also mark each message seen
    final list = _messages[conversationId] ?? const [];
    _messages[conversationId] = [
      for (final m in list)
        m.seenBy.contains(participantKey)
            ? m
            : m.copyWith(seenBy: {...m.seenBy, participantKey})
    ];
    _tick.add(null);
  }
}

extension _StartWith<T> on Stream<T> {
  Stream<T> startWith(T? value) async* {
    if (value != null) yield value;
    yield* this;
  }
}

final chatRepositoryProvider = Provider<ChatRepository>((ref) => MockChatRepository());
