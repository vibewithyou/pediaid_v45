import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/theme/app_theme.dart';

/// The public landing page shown before a user logs in or selects a salon.
///
/// It introduces the platform with a hero section and a few highlight cards.
class LandingScreen extends StatelessWidget {
  const LandingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 80, horizontal: 24),
              color: theme.colorScheme.background,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'SalonManager',
                    style: theme.textTheme.displayMedium?.copyWith(
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Entdecke deinen perfekten Salon',
                    style: theme.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Wrap(
                    spacing: 16,
                    runSpacing: 16,
                    children: [
                      LuxuryButton(
                        label: 'Salon finden',
                        onPressed: () => context.go('/map'),
                      ),
                      LuxuryButton(
                        label: 'Inspiration ansehen',
                        onPressed: () => context.go('/inspirations'),
                        filled: false,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            // Highlights
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  LuxuryCard(
                    leading: const Icon(Icons.calendar_month, color: AppColors.gold),
                    title: 'Einfach buchen',
                    subtitle: 'Termin finden und buchen in wenigen Schritten.',
                  ),
                  const SizedBox(height: 16),
                  LuxuryCard(
                    leading: const Icon(Icons.storefront, color: AppColors.gold),
                    title: 'Dein Salon, dein Style',
                    subtitle: 'Passe Farben, Texte und Galerie individuell an.',
                  ),
                  const SizedBox(height: 16),
                  LuxuryCard(
                    leading: const Icon(Icons.stars, color: AppColors.gold),
                    title: 'Treueprogramm',
                    subtitle: 'Sammle Punkte und erhalte exklusive Vorteile.',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            // Footer with legal links
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Wrap(
                alignment: WrapAlignment.center,
                spacing: 16,
                children: [
                  TextButton(
                    onPressed: () => context.go('/impressum'),
                    child: const Text('Impressum'),
                  ),
                    TextButton(
                    onPressed: () => context.go('/privacy'),
                    child: const Text('Datenschutz'),
                  ),
                    TextButton(
                    onPressed: () => context.go('/terms'),
                    child: const Text('AGB'),
                  ),
                    TextButton(
                    onPressed: () => context.go('/withdrawal'),
                    child: const Text('Widerruf'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}