import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/core/providers/booking_provider.dart';
import 'package:salonvault/core/providers/salon_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/widgets/luxury_card.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';
import 'package:salonvault/core/widgets/luxury_stepper.dart';
import 'package:salonvault/services/booking_service.dart';

class BookingWizardScreen extends ConsumerWidget {
  const BookingWizardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final wizardState = ref.watch(bookingWizardProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Book Appointment'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            if (wizardState.currentStep > 0) {
              ref.read(bookingWizardProvider.notifier).previousStep();
            } else {
              context.pop();
            }
          },
        ),
      ),
      body: Column(
        children: [
          // Luxury stepper to indicate progress through the five steps
          LuxuryStepper(currentStep: wizardState.currentStep, totalSteps: 5),
          Expanded(
            child: IndexedStack(
              index: wizardState.currentStep,
              children: const [
                _Step1SelectService(),
                _Step2SelectStylist(),
                _Step3SelectSlot(),
                _Step4AddNotes(),
                _Step5Confirm(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Step1SelectService extends ConsumerWidget {
  const _Step1SelectService();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedSalonId = ref.watch(selectedSalonProvider);
    if (selectedSalonId == null) {
      return const Center(child: Text('Please select a salon first'));
    }

    final servicesAsync = ref.watch(salonServicesProvider(selectedSalonId));

    return servicesAsync.when(
      data: (services) => ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: services.length,
        itemBuilder: (context, index) {
          final service = services[index];
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: LuxuryCard(
              leading: const Icon(Icons.content_cut, color: AppColors.gold),
              title: service.name,
              subtitle: '${service.durationMinutes} min',
              trailing: Text(
                '€${service.price.toStringAsFixed(2)}',
                style: const TextStyle(
                  color: AppColors.gold,
                  fontWeight: FontWeight.bold,
                ),
              ),
              onTap: () {
                ref.read(bookingWizardProvider.notifier).setService(service.id);
                ref.read(bookingWizardProvider.notifier).nextStep();
              },
            ),
          );
        },
      ),
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }
}

class _Step2SelectStylist extends ConsumerWidget {
  const _Step2SelectStylist();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedSalonId = ref.watch(selectedSalonProvider);
    if (selectedSalonId == null) {
      return const Center(child: Text('Please select a salon first'));
    }

    final stylistsAsync = ref.watch(salonStylistsProvider(selectedSalonId));

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: LuxuryButton(
            label: 'Any Stylist',
            filled: false,
            onPressed: () {
              ref.read(bookingWizardProvider.notifier).setStylist(null);
              ref.read(bookingWizardProvider.notifier).nextStep();
            },
          ),
        ),
        Expanded(
          child: stylistsAsync.when(
            data: (stylists) => ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: stylists.length,
              itemBuilder: (context, index) {
                final stylist = stylists[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: LuxuryCard(
                    leading: CircleAvatar(
                      backgroundImage: stylist.avatar != null ? NetworkImage(stylist.avatar!) : null,
                      child: stylist.avatar == null ? const Icon(Icons.person) : null,
                    ),
                    title: stylist.name,
                    subtitle: '${stylist.rating} ⭐ (${stylist.reviewCount})',
                    onTap: () {
                      ref.read(bookingWizardProvider.notifier).setStylist(stylist.id);
                      ref.read(bookingWizardProvider.notifier).nextStep();
                    },
                  ),
                );
              },
            ),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Center(child: Text('Error: $error')),
          ),
        ),
      ],
    );
  }
}

class _Step3SelectSlot extends ConsumerStatefulWidget {
  const _Step3SelectSlot();

  @override
  ConsumerState<_Step3SelectSlot> createState() => _Step3SelectSlotState();
}

class _Step3SelectSlotState extends ConsumerState<_Step3SelectSlot> {
  DateTime _selectedDate = DateTime.now();
  final _bookingService = BookingService();

  @override
  Widget build(BuildContext context) {
    final wizardState = ref.watch(bookingWizardProvider);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: const Icon(Icons.chevron_left),
                onPressed: () => setState(() {
                  _selectedDate = _selectedDate.subtract(const Duration(days: 1));
                }),
              ),
              Text(
                '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              IconButton(
                icon: const Icon(Icons.chevron_right),
                onPressed: () => setState(() {
                  _selectedDate = _selectedDate.add(const Duration(days: 1));
                }),
              ),
            ],
          ),
        ),
        Expanded(
          child: FutureBuilder(
            future: _bookingService.getAvailableSlots(
              ref.read(selectedSalonProvider)!,
              wizardState.serviceId!,
              _selectedDate,
            ),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              return snapshot.data!.fold(
                (failure) => Center(child: Text('Error: ${failure.message}')),
                (slots) => GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 2,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: slots.length,
                  itemBuilder: (context, index) {
                    final slot = slots[index];
                    final isSelected = wizardState.selectedSlot == slot;
                    return ElevatedButton(
                      onPressed: () {
                        ref.read(bookingWizardProvider.notifier).setSlot(slot);
                        ref.read(bookingWizardProvider.notifier).nextStep();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isSelected ? AppColors.gold : null,
                      ),
                      child: Text('${slot.hour}:${slot.minute.toString().padLeft(2, '0')}'),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _Step4AddNotes extends ConsumerStatefulWidget {
  const _Step4AddNotes();

  @override
  ConsumerState<_Step4AddNotes> createState() => _Step4AddNotesState();
}

class _Step4AddNotesState extends ConsumerState<_Step4AddNotes> {
  final _notesController = TextEditingController();
  final _imagePicker = ImagePicker();

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final wizardState = ref.read(bookingWizardProvider);
    if (wizardState.images.length >= 5) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Maximum 5 images allowed')),
      );
      return;
    }

    final image = await _imagePicker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      ref.read(bookingWizardProvider.notifier).addImage(image.path);
    }
  }

  @override
  Widget build(BuildContext context) {
    final wizardState = ref.watch(bookingWizardProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          LuxuryInput(
            controller: _notesController,
            hintText: 'Add notes (optional)',
            maxLines: 5,
            onChanged: (value) => ref.read(bookingWizardProvider.notifier).setNotes(value),
          ),
          const SizedBox(height: 24),
          Text('Reference Images (${wizardState.images.length}/5)', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ...wizardState.images.map((path) => Stack(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: AppColors.mediumGrey,
                    ),
                    child: Icon(Icons.image, color: AppColors.gold),
                  ),
                  Positioned(
                    top: -4,
                    right: -4,
                    child: IconButton(
                      icon: const Icon(Icons.close, size: 16),
                      onPressed: () => ref.read(bookingWizardProvider.notifier).removeImage(path),
                    ),
                  ),
                ],
              )),
              if (wizardState.images.length < 5)
                InkWell(
                  onTap: _pickImage,
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.gold, width: 2),
                    ),
                    child: Icon(Icons.add, color: AppColors.gold),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 32),
          LuxuryButton(
            label: 'Continue',
            onPressed: () => ref.read(bookingWizardProvider.notifier).nextStep(),
          ),
        ],
      ),
    );
  }
}

class _Step5Confirm extends ConsumerWidget {
  const _Step5Confirm();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final wizardState = ref.watch(bookingWizardProvider);
    final authState = ref.watch(authStateProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Booking summary in a luxury card
          LuxuryCard(
            title: 'Booking Summary',
            subtitle: [
              'Date: ${wizardState.selectedSlot?.day}/${wizardState.selectedSlot?.month}/${wizardState.selectedSlot?.year}',
              'Time: ${wizardState.selectedSlot?.hour}:${wizardState.selectedSlot?.minute.toString().padLeft(2, '0')}',
              if (wizardState.notes != null && wizardState.notes!.isNotEmpty)
                'Notes: ${wizardState.notes}',
            ].join('\n'),
          ),
          const SizedBox(height: 32),
          LuxuryButton(
            label: 'Confirm Booking',
            onPressed: () async {
              final user = authState.user;
              if (user == null) return;

              final bookingService = BookingService();
              final result = await bookingService.createBooking(
                userId: user.id,
                salonId: ref.read(selectedSalonProvider)!,
                serviceId: wizardState.serviceId!,
                stylistId: wizardState.stylistId,
                slot: wizardState.selectedSlot!,
                notes: wizardState.notes,
                images: wizardState.images,
              );

              result.fold(
                (failure) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error: ${failure.message}')),
                  );
                },
                (booking) {
                  ref.read(bookingWizardProvider.notifier).reset();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Booking confirmed!')),
                  );
                  context.go('/home');
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
