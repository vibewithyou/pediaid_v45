import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/booking_provider.dart';
import 'package:salonvault/features/booking/booking_wizard_screen.dart';

class BookingEntryScreen extends ConsumerWidget {
  final int step;
  const BookingEntryScreen({super.key, required this.step});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifier = ref.read(bookingWizardProvider.notifier);
    final state = ref.watch(bookingWizardProvider);
    if (step >= 0 && step <= 4 && state.currentStep != step) {
      // set desired step
      notifier.reset();
      // advance to step iteratively
      for (var i = 0; i < step; i++) {
        notifier.nextStep();
      }
    }
    return const BookingWizardScreen();
  }
}
