import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/booking/state/booking_actions.dart';
import 'package:salonvault/models/reschedule_option.dart';

class RescheduleDialog extends ConsumerStatefulWidget {
  final String bookingId;
  const RescheduleDialog({super.key, required this.bookingId});

  @override
  ConsumerState<RescheduleDialog> createState() => _RescheduleDialogState();
}

class _RescheduleDialogState extends ConsumerState<RescheduleDialog> {
  List<RescheduleOption> _options = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final actions = ref.read(bookingActionsProvider);
    final opts = await actions.options(widget.bookingId);
    if (!mounted) return;
    setState(() {
      _options = opts;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Verschiebung vorschlagen'),
      content: _loading
          ? const SizedBox(height: 120, child: Center(child: CircularProgressIndicator()))
          : SizedBox(
              width: 360,
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: _options.length,
                separatorBuilder: (_, __) => const Divider(),
                itemBuilder: (_, i) {
                  final o = _options[i];
                  final subtitle = o.reason != null ? Text(o.reason!) : null;
                  return ListTile(
                    leading: const Icon(Icons.schedule),
                    title: Text(o.label),
                    subtitle: subtitle,
                    onTap: () => Navigator.pop(context, o.slot),
                  );
                },
              ),
            ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Abbrechen')),
      ],
    );
  }
}
