import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/core/utils/rbac.dart';
import 'package:salonvault/features/booking/reschedule_dialog.dart';
import 'package:salonvault/features/booking/state/booking_actions.dart';
import 'package:salonvault/features/booking/state/booking_state.dart';
import 'package:salonvault/models/booking.dart';
import 'package:salonvault/models/user.dart';

class StylistQueueScreen extends ConsumerWidget {
  const StylistQueueScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authStateProvider);
    final isAllowed = auth.user != null && RBAC.hasAnyRole(auth.user!.role, const [UserRole.stylist, UserRole.salonManager, UserRole.salonOwner, UserRole.owner, UserRole.platformAdmin]);
    final state = ref.watch(stylistQueueProvider);
    final notifier = ref.read(stylistQueueProvider.notifier);

    if (!isAllowed) {
      return const Scaffold(body: Center(child: Text('Kein Zugriff')));
    }

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Stylist Queue'),
          bottom: const TabBar(tabs: [
            Tab(text: 'Anfragen'),
            Tab(text: 'Bestätigte'),
            Tab(text: 'Reschedule benötigt'),
          ]),
          actions: [IconButton(onPressed: notifier.refresh, icon: const Icon(Icons.refresh))],
        ),
        body: state.isLoading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(children: [
                _QueueList(bookings: state.requests),
                _QueueList(bookings: state.confirmed),
                _QueueList(bookings: state.rescheduleNeeded),
              ]),
      ),
    );
  }
}

class _QueueList extends ConsumerWidget {
  final List<Booking> bookings;
  const _QueueList({required this.bookings});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (bookings.isEmpty) {
      return const Center(child: Text('Keine Einträge'));
    }
    return RefreshIndicator(
      onRefresh: () => ref.read(stylistQueueProvider.notifier).refresh(),
      child: ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: bookings.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) => _BookingCard(booking: bookings[i]),
      ),
    );
  }
}

class _BookingCard extends ConsumerWidget {
  final Booking booking;
  const _BookingCard({required this.booking});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final actions = ref.read(bookingActionsProvider);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              Expanded(child: Text('#${booking.id}  ${_fmt(booking.slot)}')),
              Chip(label: Text(booking.status.name)),
            ],
          ),
          const SizedBox(height: 6),
          Text('Service: ${booking.serviceId}'),
          Text('Kunde: ${booking.userId}'),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: _actionsFor(context, ref, actions, booking)),
        ]),
      ),
    );
  }

  String _fmt(DateTime t) => '${t.day.toString().padLeft(2, '0')}.${t.month.toString().padLeft(2, '0')}.${t.year}  ${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}'
      .toString();

  List<Widget> _actionsFor(BuildContext context, WidgetRef ref, BookingActions actions, Booking booking) {
    final widgets = <Widget>[];
    final status = booking.status;
    if (status == BookingStatus.pending) {
      widgets.addAll([
        FilledButton.icon(
          onPressed: () async {
            await actions.confirm(booking.id);
            await ref.read(stylistQueueProvider.notifier).refresh();
          },
          icon: const Icon(Icons.check),
          label: const Text('Bestätigen'),
        ),
        OutlinedButton.icon(
          onPressed: () async {
            await actions.decline(booking.id);
            await ref.read(stylistQueueProvider.notifier).refresh();
          },
          icon: const Icon(Icons.close),
          label: const Text('Ablehnen'),
        ),
        OutlinedButton.icon(
          onPressed: () async {
            final slot = await showDialog<DateTime>(
              context: context,
              builder: (_) => RescheduleDialog(bookingId: booking.id),
            );
            if (slot != null) {
              await actions.suggestReschedule(booking.id, slot);
              await ref.read(stylistQueueProvider.notifier).refresh();
            }
          },
          icon: const Icon(Icons.schedule_send),
          label: const Text('Reschedule vorschlagen'),
        ),
      ]);
    } else if (status == BookingStatus.rescheduleRequested) {
      widgets.addAll([
        FilledButton.icon(
          onPressed: () async {
            final slot = await showDialog<DateTime>(
              context: context,
              builder: (_) => RescheduleDialog(bookingId: booking.id),
            );
            if (slot != null) {
              await actions.applyReschedule(booking.id, slot);
              await ref.read(stylistQueueProvider.notifier).refresh();
            }
          },
          icon: const Icon(Icons.event_available),
          label: const Text('Termin festlegen'),
        ),
      ]);
    }
    return widgets;
  }
}
