import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/features/booking/state/booking_actions.dart';
import 'package:salonvault/features/booking/reschedule_dialog.dart';
import 'package:salonvault/features/gallery_ai/widgets/booking_attach_picker.dart';
import 'package:salonvault/models/booking.dart';

class BookingDetailScreen extends ConsumerStatefulWidget {
  final String bookingId;
  const BookingDetailScreen({super.key, required this.bookingId});

  @override
  ConsumerState<BookingDetailScreen> createState() => _BookingDetailScreenState();
}

class _BookingDetailScreenState extends ConsumerState<BookingDetailScreen> {
  Booking? _booking;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final actions = ref.read(bookingActionsProvider);
    final b = await actions.getById(widget.bookingId);
    setState(() {
      _booking = b;
      _loading = false;
      _error = b == null ? 'Termin nicht gefunden' : null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final booking = _booking;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Termin-Details'),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : booking == null
              ? Center(child: Text(_error ?? 'Termin nicht gefunden'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      _StatusBanner(status: booking.status),
                      const SizedBox(height: 12),
                      _Section(title: 'Service', child: Text(booking.serviceId)),
                      const SizedBox(height: 8),
                      _Section(title: 'Stylist', child: Text(booking.stylistId ?? '-')),
                      const SizedBox(height: 8),
                      _Section(title: 'Zeit', child: Text(_fmt(booking.slot))),
                      const SizedBox(height: 8),
                      if (booking.images.isNotEmpty)
                        _Section(
                          title: 'Anhänge',
                          child: Wrap(
                            spacing: 8,
                            children: booking.images.map((e) => Chip(label: Text(e))).toList(),
                          ),
                        ),
                      const SizedBox(height: 16),
                      Wrap(
                        spacing: 12,
                        runSpacing: 8,
                        children: [
                          OutlinedButton.icon(
                            onPressed: () async {
                              final selected = await showDialog<DateTime>(
                                context: context,
                                builder: (ctx) => RescheduleDialog(bookingId: booking.id),
                              );
                              if (selected != null) {
                                final updated = await ref.read(bookingActionsProvider).applyReschedule(booking.id, selected);
                                if (updated != null) setState(() => _booking = updated);
                              }
                            },
                            icon: const Icon(Icons.schedule),
                            label: const Text('Termin verschieben'),
                          ),
                          OutlinedButton.icon(
                            onPressed: () async {
                              final refs = await showBookingAttachPicker(context, ref);
                              if (refs == null || refs.isEmpty) return;
                              final updated = await ref.read(bookingActionsProvider).attachMedia(booking.id, refs.map((e) => e.id).toList());
                              if (updated != null) setState(() => _booking = updated);
                            },
                            icon: const Icon(Icons.attachment),
                            label: const Text('Bilder anhängen'),
                          ),
                          FilledButton.icon(
                            onPressed: () => context.push('/chat'),
                            icon: const Icon(Icons.chat),
                            label: const Text('Mit Stylist chatten'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
    );
  }

  String _fmt(DateTime t) => '${t.day.toString().padLeft(2, '0')}.${t.month.toString().padLeft(2, '0')}.${t.year}  ${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}'
      .toString();
}

class _StatusBanner extends StatelessWidget {
  final BookingStatus status;
  const _StatusBanner({required this.status});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    late final Color bg;
    late final String text;
    switch (status) {
      case BookingStatus.pending:
        bg = Colors.orange.shade200;
        text = 'Wartet auf Bestätigung';
        break;
      case BookingStatus.confirmed:
        bg = Colors.green.shade200;
        text = 'Bestätigt';
        break;
      case BookingStatus.cancelled:
        bg = Colors.red.shade200;
        text = 'Storniert';
        break;
      case BookingStatus.completed:
        bg = Colors.blueGrey.shade200;
        text = 'Abgeschlossen';
        break;
      case BookingStatus.declined:
        bg = Colors.red.shade300;
        text = 'Abgelehnt';
        break;
      case BookingStatus.rescheduleRequested:
        bg = Colors.amber.shade200;
        text = 'Verschiebung vorgeschlagen';
        break;
    }
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: Colors.black87),
          const SizedBox(width: 8),
          Text(text, style: TextStyle(color: colorScheme.onSecondaryContainer, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final Widget child;
  const _Section({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          child,
        ]),
      ),
    );
  }
}
