import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/core/errors/result.dart';
import 'package:salonvault/models/booking.dart';
import 'package:salonvault/models/reschedule_option.dart';
import 'package:salonvault/services/booking_service.dart';
import 'package:salonvault/core/providers/booking_provider.dart';

final bookingRepositoryProvider = Provider<BookingRepository>((ref) {
  final svc = ref.read(bookingServiceProvider);
  return BookingRepository(svc);
});

class BookingRepository {
  final BookingService _service;
  BookingRepository(this._service);

  Future<Result<Booking>> getById(String id) => _service.getBooking(id);

  Future<Result<List<Booking>>> userBookings(String userId) => _service.getUserBookings(userId);

  Future<Result<List<Booking>>> stylistBookings(String stylistId, {BookingStatus? status}) =>
      _service.getStylistBookings(stylistId, status: status);

  Future<Result<Booking>> confirm(String bookingId) => _service.confirmBooking(bookingId);

  Future<Result<Booking>> decline(String bookingId, {String? reason}) =>
      _service.declineBooking(bookingId, reason: reason);

  Future<Result<List<RescheduleOption>>> rescheduleOptions(String bookingId) =>
      _service.getRescheduleOptions(bookingId);

  Future<Result<Booking>> suggestReschedule(String bookingId, DateTime newSlot) =>
      _service.suggestReschedule(bookingId, newSlot);

  Future<Result<Booking>> applyReschedule(String bookingId, DateTime newSlot) =>
      _service.applyReschedule(bookingId, newSlot);

  Future<Result<Booking>> attachMedia(String bookingId, List<String> mediaRefs) =>
      _service.attachMedia(bookingId, mediaRefs);
}
