import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/booking/data/booking_repository.dart';
import 'package:salonvault/models/booking.dart';
import 'package:salonvault/models/reschedule_option.dart';

class BookingActions {
  final Ref ref;
  BookingActions(this.ref);

  BookingRepository get _repo => ref.read(bookingRepositoryProvider);

  Future<Booking?> getById(String id) async {
    final res = await _repo.getById(id);
    return res.fold((f) => null, (b) => b);
  }

  Future<List<RescheduleOption>> options(String id) async {
    final res = await _repo.rescheduleOptions(id);
    return res.fold((f) => [], (v) => v);
  }

  Future<Booking?> confirm(String id) async {
    final res = await _repo.confirm(id);
    return res.fold((f) => null, (b) => b);
  }

  Future<Booking?> decline(String id, {String? reason}) async {
    final res = await _repo.decline(id, reason: reason);
    return res.fold((f) => null, (b) => b);
  }

  Future<Booking?> suggestReschedule(String id, DateTime slot) async {
    final res = await _repo.suggestReschedule(id, slot);
    return res.fold((f) => null, (b) => b);
  }

  Future<Booking?> applyReschedule(String id, DateTime slot) async {
    final res = await _repo.applyReschedule(id, slot);
    return res.fold((f) => null, (b) => b);
  }

  Future<Booking?> attachMedia(String id, List<String> refs) async {
    final res = await _repo.attachMedia(id, refs);
    return res.fold((f) => null, (b) => b);
  }
}

final bookingActionsProvider = Provider((ref) => BookingActions(ref));
