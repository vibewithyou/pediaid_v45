import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:state_notifier/state_notifier.dart';
import 'package:salonvault/core/errors/result.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/features/booking/data/booking_repository.dart';
import 'package:salonvault/models/booking.dart';
import 'package:salonvault/models/reschedule_option.dart';

class BookingDetailState {
  final Booking? booking;
  final bool isLoading;
  final String? error;

  const BookingDetailState({this.booking, this.isLoading = false, this.error});

  BookingDetailState copyWith({Booking? booking, bool? isLoading, String? error}) =>
      BookingDetailState(
        booking: booking ?? this.booking,
        isLoading: isLoading ?? false,
        error: error,
      );
}

class BookingDetailController extends StateNotifier<BookingDetailState> {
  final BookingRepository _repo;
  final String bookingId;
  BookingDetailController(this._repo, this.bookingId) : super(const BookingDetailState(isLoading: true)) {
    _load();
  }

  Future<void> _load() async {
    final res = await _repo.getById(bookingId);
    res.fold(
      (f) => state = BookingDetailState(error: f.message),
      (b) => state = BookingDetailState(booking: b),
    );
  }

  Future<void> refresh() => _load();

  Future<void> confirm() async {
    final id = state.booking?.id;
    if (id == null) return;
    final res = await _repo.confirm(id);
    res.fold((f) => state = state.copyWith(error: f.message), (b) => state = state.copyWith(booking: b));
  }

  Future<void> decline({String? reason}) async {
    final id = state.booking?.id;
    if (id == null) return;
    final res = await _repo.decline(id, reason: reason);
    res.fold((f) => state = state.copyWith(error: f.message), (b) => state = state.copyWith(booking: b));
  }

  Future<List<RescheduleOption>> loadRescheduleOptions() async {
    final id = state.booking?.id;
    if (id == null) return [];
    final res = await _repo.rescheduleOptions(id);
    return res.fold((f) => [], (opts) => opts);
  }

  Future<void> suggestReschedule(DateTime slot) async {
    final id = state.booking?.id;
    if (id == null) return;
    final res = await _repo.suggestReschedule(id, slot);
    res.fold((f) => state = state.copyWith(error: f.message), (b) => state = state.copyWith(booking: b));
  }

  Future<void> applyReschedule(DateTime slot) async {
    final id = state.booking?.id;
    if (id == null) return;
    final res = await _repo.applyReschedule(id, slot);
    res.fold((f) => state = state.copyWith(error: f.message), (b) => state = state.copyWith(booking: b));
  }

  Future<void> attachMedia(List<String> mediaRefs) async {
    final id = state.booking?.id;
    if (id == null) return;
    final res = await _repo.attachMedia(id, mediaRefs);
    res.fold((f) => state = state.copyWith(error: f.message), (b) => state = state.copyWith(booking: b));
  }
}

// Stylist Queue
class StylistQueueState {
  final List<Booking> requests;
  final List<Booking> confirmed;
  final List<Booking> rescheduleNeeded;
  final bool isLoading;
  final String? error;

  const StylistQueueState({
    this.requests = const [],
    this.confirmed = const [],
    this.rescheduleNeeded = const [],
    this.isLoading = false,
    this.error,
  });

  StylistQueueState copyWith({
    List<Booking>? requests,
    List<Booking>? confirmed,
    List<Booking>? rescheduleNeeded,
    bool? isLoading,
    String? error,
  }) => StylistQueueState(
        requests: requests ?? this.requests,
        confirmed: confirmed ?? this.confirmed,
        rescheduleNeeded: rescheduleNeeded ?? this.rescheduleNeeded,
        isLoading: isLoading ?? false,
        error: error,
      );
}

class StylistQueueNotifier extends Notifier<StylistQueueState> {
  BookingRepository get _repo => ref.read(bookingRepositoryProvider);

  @override
  StylistQueueState build() {
    _load();
    return const StylistQueueState(isLoading: true);
  }

  Future<void> _load() async {
    final user = ref.read(authStateProvider).user;
    if (user == null) {
      state = const StylistQueueState(error: 'Not logged in');
      return;
    }
    final stylistId = user.id;
    final reqRes = await _repo.stylistBookings(stylistId, status: BookingStatus.pending);
    final confRes = await _repo.stylistBookings(stylistId, status: BookingStatus.confirmed);
    final reschRes = await _repo.stylistBookings(stylistId, status: BookingStatus.rescheduleRequested);

    String? err;
    List<Booking> requests = const [];
    List<Booking> confirmed = const [];
    List<Booking> rescheduleNeeded = const [];

    reqRes.fold((f) => err = f.message, (v) => requests = v);
    confRes.fold((f) => err ??= f.message, (v) => confirmed = v);
    reschRes.fold((f) => err ??= f.message, (v) => rescheduleNeeded = v);

    if (err != null) {
      state = StylistQueueState(error: err);
      return;
    }
    state = StylistQueueState(
      requests: requests,
      confirmed: confirmed,
      rescheduleNeeded: rescheduleNeeded,
    );
  }

  Future<void> refresh() => _load();
}

final stylistQueueProvider = NotifierProvider<StylistQueueNotifier, StylistQueueState>(StylistQueueNotifier.new);
