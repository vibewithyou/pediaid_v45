import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _handleLogin() async {
    final l = AppLocalizations.of(context);
    final email = _emailController.text.trim();
    final password = _passwordController.text;
    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(l.translate('error_fill_fields'))),
      );
      return;
    }
    // Basic email format check
    final emailRegex = RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+\$');
    if (!emailRegex.hasMatch(email)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(l.translate('error_invalid_email'))),
      );
      return;
    }
    // Password length check
    if (password.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(l.translate('error_password_length'))),
      );
      return;
    }

    setState(() => _isLoading = true);
    await ref.read(authStateProvider.notifier).login(email, password);
    setState(() => _isLoading = false);

    if (mounted) {
      final authState = ref.read(authStateProvider);
      if (authState.error != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${l.translate('error_login_failed')}: ${authState.error}')),
        );
      } else if (authState.user != null) {
        context.go('/home');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Icon(Icons.content_cut, size: 80, color: AppColors.gold),
                const SizedBox(height: 24),
                Text(
                  'SalonManager',
                  style: Theme.of(context).textTheme.displayMedium,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  'Your beauty, our expertise',
                  style: Theme.of(context).textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 48),
                LuxuryInput(
                  controller: _emailController,
                  hintText: l.translate('email_hint'),
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 16),
                LuxuryInput(
                  controller: _passwordController,
                  hintText: l.translate('password_hint'),
                  obscureText: true,
                ),
                const SizedBox(height: 24),
                LuxuryButton(
                  onPressed: _isLoading ? null : _handleLogin,
                  filled: true,
                  child: _isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(l.translate('login')),
                ),
                const SizedBox(height: 16),
                LuxuryButton(
                  onPressed: () => context.push('/register'),
                  filled: false,
                  label: l.translate('create_account_btn'),
                ),
                const SizedBox(height: 16),
                LuxuryButton(
                  onPressed: () => context.push('/password-reset'),
                  filled: false,
                  label: l.translate('forgot_password'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
