import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/widgets/luxury_input.dart';
import 'package:salonvault/core/widgets/luxury_button.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _handleRegister() async {
    final l = AppLocalizations.of(context);
    final name = _nameController.text.trim();
    final email = _emailController.text.trim();
    final password = _passwordController.text;
    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(l.translate('error_fill_fields'))),
      );
      return;
    }
    final emailRegex = RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+\$');
    if (!emailRegex.hasMatch(email)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(l.translate('error_invalid_email'))),
      );
      return;
    }
    if (password.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(l.translate('error_password_length'))),
      );
      return;
    }

    setState(() => _isLoading = true);
    await ref.read(authStateProvider.notifier).register(
      name,
      email,
      password,
    );
    setState(() => _isLoading = false);

    if (mounted) {
      final authState = ref.read(authStateProvider);
      if (authState.error != null) {
        final errorText = '${l.translate('error_registration_failed')}: ${authState.error}';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(errorText)),
        );
      } else if (authState.user != null) {
        context.go('/home');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
        title: Text(l.translate('create_account')),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                LuxuryInput(
                  controller: _nameController,
                  hintText: l.translate('full_name'),
                ),
                const SizedBox(height: 16),
                LuxuryInput(
                  controller: _emailController,
                  hintText: l.translate('email_hint'),
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 16),
                LuxuryInput(
                  controller: _passwordController,
                  hintText: l.translate('password_hint'),
                  obscureText: true,
                ),
                const SizedBox(height: 32),
                LuxuryButton(
                  onPressed: _isLoading ? null : _handleRegister,
                  filled: true,
                  child: _isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(l.translate('register')),
                ),
                const SizedBox(height: 16),
                LuxuryButton(
                  onPressed: () => context.pop(),
                  filled: false,
                  label: l.translate('already_have_account_btn'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
