import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';

/// Types of snackbars supported by [showLuxurySnackBar].
enum SnackType { success, error, info }

/// Displays a custom snackbar with a luxurious look and feel. The
/// color adapts to the [SnackType]. Use this helper whenever you
/// need to show feedback to the user. This function is backend
/// independent and can be used across the app.
void showLuxurySnackBar(BuildContext context, String message, SnackType type) {
  Color background;
  switch (type) {
    case SnackType.success:
      background = AppColors.successGreen;
      break;
    case SnackType.error:
      background = AppColors.errorRed;
      break;
    case SnackType.info:
    default:
      background = AppColors.gold;
      break;
  }
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message, style: const TextStyle(color: Colors.black)),
      backgroundColor: background,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
  );
}