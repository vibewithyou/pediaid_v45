import 'package:salonvault/models/user.dart';

/// Simple RBAC helper utilities
class RBAC {
  static bool isStaff(UserRole role) {
    return role == UserRole.owner ||
        role == UserRole.platformAdmin ||
        role == UserRole.salonOwner ||
        role == UserRole.salonManager ||
        role == UserRole.stylist;
  }

  static bool hasAnyRole(UserRole role, List<UserRole> allowed) {
    return allowed.contains(role);
  }
}
