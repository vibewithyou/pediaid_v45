import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/core/utils/rbac.dart';
import 'package:salonvault/core/theme/app_theme.dart';
import 'package:salonvault/core/l10n/app_localizations.dart';

class ShellScreen extends ConsumerStatefulWidget {
  final Widget child;

  const ShellScreen({super.key, required this.child});

  @override
  ConsumerState<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends ConsumerState<ShellScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
    
    switch (index) {
      case 0:
        context.go('/home');
        break;
      case 1:
        context.go('/map');
        break;
      case 2:
        context.go('/booking');
        break;
      case 3:
        context.go('/loyalty');
        break;
      case 4:
        context.go('/profile');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final auth = ref.watch(authStateProvider);
    final user = auth.user;
    return Scaffold(
      body: widget.child,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          backgroundColor: Theme.of(context).colorScheme.surface,
          selectedItemColor: AppColors.gold,
          unselectedItemColor: AppColors.textGrey,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600),
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home, semanticLabel: localizations.translate('nav_home')),
              label: localizations.translate('nav_home'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.map, semanticLabel: localizations.translate('nav_map')),
              label: localizations.translate('nav_map'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today, semanticLabel: localizations.translate('nav_booking')),
              label: localizations.translate('nav_booking'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.card_giftcard, semanticLabel: localizations.translate('nav_loyalty')),
              label: localizations.translate('nav_loyalty'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person, semanticLabel: localizations.translate('nav_profile')),
              label: localizations.translate('nav_profile'),
            ),
          ],
        ),
      ),
      floatingActionButton: user != null && RBAC.isStaff(user.role)
          ? FloatingActionButton.extended(
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  showDragHandle: true,
                  builder: (_) => SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Wrap(
                        runSpacing: 8,
                        children: [
                          _manageTile(context, Icons.dashboard, localizations.translate('manage_dashboard'), '/manage/dashboard'),
                          _manageTile(context, Icons.schedule, localizations.translate('manage_scheduling'), '/manage/scheduling'),
                          _manageTile(context, Icons.point_of_sale, localizations.translate('manage_pos'), '/manage/pos'),
                          _manageTile(context, Icons.inventory_2, localizations.translate('manage_inventory'), '/manage/inventory'),
                          _manageTile(context, Icons.people, localizations.translate('manage_customers'), '/manage/customers'),
                          _manageTile(context, Icons.campaign, localizations.translate('manage_campaigns'), '/manage/campaigns'),
                          _manageTile(context, Icons.analytics, localizations.translate('manage_reports'), '/manage/reports'),
                          _manageTile(context, Icons.settings, localizations.translate('manage_settings'), '/manage/settings'),
                        ],
                      ),
                    ),
                  ),
                );
              },
              backgroundColor: AppColors.gold,
              foregroundColor: AppColors.black,
              icon: Icon(Icons.manage_accounts, semanticLabel: localizations.translate('manage')),
              label: Text(localizations.translate('manage')),
            )
          : null,
    );
  }

  Widget _manageTile(BuildContext context, IconData icon, String label, String route) {
    return ListTile(
      leading: Icon(icon, color: AppColors.gold, semanticLabel: label),
      title: Text(label),
      trailing: const Icon(Icons.chevron_right),
      onTap: () {
        Navigator.of(context).pop();
        context.go(route);
      },
    );
  }
}
