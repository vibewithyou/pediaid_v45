import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:salonvault/core/providers/auth_provider.dart';
import 'package:salonvault/features/auth/login_screen.dart';
import 'package:salonvault/features/auth/register_screen.dart';
import 'package:salonvault/features/auth/password_reset_screen.dart';
import 'package:salonvault/features/salon_profile/select_salon_screen.dart';
import 'package:salonvault/features/salon_profile/salon_home_screen.dart';
import 'package:salonvault/features/search_map/map_search_screen.dart';
import 'package:salonvault/features/booking/booking_wizard_screen.dart';
import 'package:salonvault/features/booking/booking_entry_screen.dart';
import 'package:salonvault/features/booking/booking_detail_screen.dart';
import 'package:salonvault/features/booking/stylist_queue_screen.dart';
import 'package:salonvault/features/loyalty/loyalty_screen.dart';
import 'package:salonvault/features/loyalty/profile_screen.dart';
import 'package:salonvault/features/pos/pos_checkout_screen.dart';
import 'package:salonvault/features/legal/impressum_screen.dart';
import 'package:salonvault/features/legal/privacy_screen.dart';
import 'package:salonvault/features/legal/terms_screen.dart';
import 'package:salonvault/features/legal/withdrawal_screen.dart';
import 'package:salonvault/features/manage/legal/legal_editor_screen.dart';
import 'package:salonvault/features/help/faq_screen.dart';
import 'package:salonvault/core/routing/shell_screen.dart';
import 'package:salonvault/core/utils/rbac.dart';
import 'package:salonvault/models/user.dart';
import 'package:salonvault/features/manage/manage_dashboard_screen.dart';
import 'package:salonvault/features/manage/scheduling/scheduling_screen.dart';
import 'package:salonvault/features/manage/inventory/inventory_screen.dart';
import 'package:salonvault/features/manage/customers/customers_screen.dart';
import 'package:salonvault/features/manage/campaigns/campaigns_screen.dart';
import 'package:salonvault/features/manage/reports/reports_screen.dart';
import 'package:salonvault/features/manage/settings/settings_screen.dart';
import 'package:salonvault/features/manage/loyalty/loyalty_management_screen.dart';
import 'package:salonvault/features/manage/services/services_screen.dart';
import 'package:salonvault/features/manage/promotions/promotions_screen.dart';
import 'package:salonvault/features/manage/scheduling/staff_management_screen.dart';
import 'package:salonvault/features/manage/loyalty/gift_cards_screen.dart';
import 'package:salonvault/features/manage/inventory/suppliers_screen.dart';
import 'package:salonvault/features/manage/inventory/purchase_orders_screen.dart';
import 'package:salonvault/features/manage/templates/salon_designer_screen.dart';
import 'package:salonvault/features/manage/templates/notification_templates_screen.dart';
import 'package:salonvault/features/salon_templates/views/salon_branding_editor.dart';
import 'package:salonvault/features/salon_templates/views/salon_layout_editor.dart';
import 'package:salonvault/features/salon_templates/views/about_team_editor.dart';
import 'package:salonvault/features/salon_templates/views/salon_gallery_editor.dart';
import 'package:salonvault/features/profile/invoice_screen.dart';
import 'package:salonvault/features/gallery_ai/views/gallery_hub_screen.dart';
import 'package:salonvault/features/gallery_ai/views/media_detail_screen.dart';
import 'package:salonvault/features/gallery_ai/views/inspirations_screen.dart';
import 'package:salonvault/features/onboarding/onboarding_screen.dart';
import 'package:salonvault/features/chat/views/conversations_list_screen.dart';
import 'package:salonvault/features/chat/views/conversation_detail_screen.dart';
import 'package:salonvault/features/notifications/notifications_screen.dart';
import 'package:salonvault/features/stylist_dashboard/views/stylist_dashboard_screen.dart';
import 'package:salonvault/features/stylist_dashboard/views/customer_quick_view.dart';
import 'package:salonvault/features/landing/landing_screen.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

    return GoRouter(
    // Show the landing page first for unauthenticated users
    initialLocation: '/landing',
    redirect: (context, state) {
      final isAuthenticated = authState.user != null;
      final loc = state.matchedLocation;
      // Routes that are always public (no auth required)
      const publicRoutes = [
        '/landing',
        '/impressum',
        '/privacy',
        '/inspirations',
        '/gallery',
        '/onboarding',
      ];
      final isAuthRoute = loc.startsWith('/login') ||
          loc.startsWith('/register') ||
          loc.startsWith('/password-reset');
      final isPublic = publicRoutes.any((r) => loc.startsWith(r));

      if (!isAuthenticated && !isAuthRoute && !isPublic) {
        return '/login';
      }
      if (isAuthenticated && isAuthRoute) {
        return '/home';
      }
      return null;
    },
    routes: [
        // Public landing page
        GoRoute(
        path: '/landing',
        name: 'landing',
        builder: (context, state) => const LandingScreen(),
      ),
        // Onboarding flow (public)
        GoRoute(
        path: '/onboarding',
          name: 'onboarding',
        builder: (context, state) => const OnboardingScreen(),
      ),
        GoRoute(
        path: '/login',
          name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/register',
          name: 'register',
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(
        path: '/password-reset',
          name: 'password_reset',
        builder: (context, state) => const PasswordResetScreen(),
      ),
      ShellRoute(
        builder: (context, state, child) => ShellScreen(child: child),
        routes: [
          // Stylist-focused routes
          GoRoute(
            path: '/stylist',
            name: 'stylist_dashboard',
            builder: (context, state) => const StylistDashboardScreen(),
            redirect: (context, state) {
              final user = authState.user;
              if (user == null) return '/login';
              final allowed = [UserRole.stylist, UserRole.salonManager, UserRole.salonOwner, UserRole.owner, UserRole.platformAdmin];
              return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
            },
          ),
          GoRoute(
            path: '/stylist/customer/:id',
            name: 'customer_quick_view',
            builder: (context, state) => CustomerQuickView(customerId: state.pathParameters['id']!),
            redirect: (context, state) {
              final user = authState.user;
              if (user == null) return '/login';
              final allowed = [UserRole.stylist, UserRole.salonManager, UserRole.salonOwner, UserRole.owner, UserRole.platformAdmin];
              return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
            },
          ),
          GoRoute(
            path: '/home',
              name: 'home',
            builder: (context, state) => const SelectSalonScreen(),
          ),
          GoRoute(
            path: '/salon/:id',
              name: 'salon',
            builder: (context, state) => SalonHomeScreen(
              salonId: state.pathParameters['id']!,
            ),
          ),
          GoRoute(
            path: '/map',
              name: 'map',
            builder: (context, state) => const MapSearchScreen(),
          ),
          GoRoute(
            path: '/booking',
              name: 'booking',
            builder: (context, state) => const BookingWizardScreen(),
          ),
          GoRoute(
            path: '/booking/:id/detail',
            name: 'booking_detail',
            builder: (context, state) => BookingDetailScreen(bookingId: state.pathParameters['id']!),
          ),
            GoRoute(
              path: '/booking/step/:step',
              name: 'booking_step',
              builder: (context, state) {
                final s = int.tryParse(state.pathParameters['step'] ?? '0') ?? 0;
                return BookingEntryScreen(step: s);
              },
            ),
          GoRoute(
            path: '/loyalty',
              name: 'loyalty',
            builder: (context, state) => const LoyaltyScreen(),
          ),
          GoRoute(
            path: '/chat',
              name: 'chat_list',
            builder: (context, state) => const ConversationsListScreen(),
          ),
          GoRoute(
            path: '/chat/:conversationId',
              name: 'chat_detail',
            builder: (context, state) => ConversationDetailScreen(conversationId: state.pathParameters['conversationId']!),
          ),
          GoRoute(
            path: '/gallery',
              name: 'gallery',
            builder: (context, state) => const GalleryHubScreen(),
          ),
          GoRoute(
            path: '/gallery/:id',
              name: 'media_detail',
            builder: (context, state) => MediaDetailScreen(id: state.pathParameters['id']!),
          ),
          GoRoute(
            path: '/inspirations',
              name: 'inspirations',
            builder: (context, state) => const InspirationsScreen(),
          ),
          GoRoute(
            path: '/profile',
              name: 'profile',
            builder: (context, state) => const ProfileScreen(),
          ),
          GoRoute(
            path: '/notifications',
            name: 'notifications',
            builder: (context, state) => const NotificationsScreen(),
          ),
          GoRoute(
            path: '/pos',
              name: 'pos',
            builder: (context, state) => const POSCheckoutScreen(),
          ),
            GoRoute(
              path: '/invoices/:id',
              name: 'invoice',
              builder: (context, state) => InvoiceScreen(invoiceId: state.pathParameters['id']!),
            ),
            // Manage routes (role-gated)
            GoRoute(
              path: '/manage',
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                if (!RBAC.isStaff(user.role)) return '/home';
                return '/manage/dashboard';
              },
            ),
            GoRoute(
              path: '/manage/stylist-queue',
              name: 'stylist_queue',
              builder: (context, state) => const StylistQueueScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                final allowed = [UserRole.stylist, UserRole.salonManager, UserRole.salonOwner, UserRole.owner, UserRole.platformAdmin];
                return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/dashboard',
              name: 'manage_dashboard',
              builder: (context, state) => const ManageDashboardScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/scheduling',
              name: 'manage_scheduling',
              builder: (context, state) => const SchedulingScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/pos',
              name: 'manage_pos',
              redirect: (context, state) => '/pos',
            ),
            GoRoute(
              path: '/manage/inventory',
              name: 'manage_inventory',
              builder: (context, state) => const InventoryScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/customers',
              name: 'manage_customers',
              builder: (context, state) => const CustomersScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/campaigns',
              name: 'manage_campaigns',
              builder: (context, state) => const CampaignsScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/reports',
              name: 'manage_reports',
              builder: (context, state) => const ReportsScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/settings',
              name: 'manage_settings',
              builder: (context, state) => const SettingsScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),

            // Legal editor for managing Impressum, Datenschutz, AGB und Widerruf
            GoRoute(
              path: '/manage/legal',
              name: 'manage_legal',
              builder: (context, state) => const LegalEditorScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                // Only salon owners and salon managers may edit legal texts.
                final allowed = [UserRole.salonOwner, UserRole.salonManager];
                return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/loyalty',
              name: 'manage_loyalty',
              builder: (context, state) => const LoyaltyManagementScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),

            // Gift cards & bundles management under loyalty
            GoRoute(
              path: '/manage/loyalty/gifts',
              name: 'manage_loyalty_gifts',
              builder: (context, state) => const GiftCardsScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),

            // Notification templates management
            GoRoute(
              path: '/manage/templates/notifications',
              name: 'manage_notification_templates',
              builder: (context, state) => const NotificationTemplatesScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),

            // Services management (price list)
            GoRoute(
              path: '/manage/services',
              name: 'manage_services',
              builder: (context, state) => const ServicesScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),

            // Promotions management
            GoRoute(
              path: '/manage/promotions',
              name: 'manage_promotions',
              builder: (context, state) => const PromotionsScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),

            // Staff extras: absences, time tracking, rules
            GoRoute(
              path: '/manage/staff',
              name: 'manage_staff',
              builder: (context, state) => const StaffManagementScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),

            // Salon designer (branding & layout editor access)
            GoRoute(
              path: '/manage/designer',
              name: 'manage_designer',
              builder: (context, state) => const SalonDesignerScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                // Only salon managers, owners and above may edit the salon template
                final allowed = [UserRole.salonManager, UserRole.salonOwner, UserRole.owner, UserRole.platformAdmin];
                return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
              },
            ),
          GoRoute(
            path: '/impressum',
              name: 'impressum',
            builder: (context, state) => const ImpressumScreen(),
          ),
            GoRoute(
              path: '/manage/inventory/suppliers',
              name: 'inventory_suppliers',
              builder: (context, state) => const SuppliersScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),
            GoRoute(
              path: '/manage/inventory/orders',
              name: 'inventory_orders',
              builder: (context, state) => const PurchaseOrdersScreen(),
              redirect: (context, state) {
                final user = authState.user;
                if (user == null) return '/login';
                return RBAC.isStaff(user.role) ? null : '/home';
              },
            ),
          GoRoute(
            path: '/privacy',
              name: 'privacy',
            builder: (context, state) => const PrivacyScreen(),
          ),

          // Additional public legal pages
          GoRoute(
            path: '/terms',
            name: 'terms',
            builder: (context, state) => const TermsScreen(),
          ),
          GoRoute(
            path: '/withdrawal',
            name: 'withdrawal',
            builder: (context, state) => const WithdrawalScreen(),
          ),

          // Help / FAQ page
          GoRoute(
            path: '/help',
            name: 'help',
            builder: (context, state) => const FaqScreen(),
          ),
          // Template/Branding deep links
          GoRoute(
            path: '/settings/branding',
            name: 'settings_branding',
            builder: (context, state) => const SalonBrandingEditor(),
            redirect: (context, state) {
              final user = authState.user;
              if (user == null) return '/login';
              final allowed = [UserRole.salonOwner, UserRole.salonManager, UserRole.owner, UserRole.platformAdmin];
              return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
            },
          ),
          GoRoute(
            path: '/settings/layout',
            name: 'settings_layout',
            builder: (context, state) => const SalonLayoutEditor(),
            redirect: (context, state) {
              final user = authState.user;
              if (user == null) return '/login';
              final allowed = [UserRole.salonOwner, UserRole.salonManager, UserRole.owner, UserRole.platformAdmin];
              return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
            },
          ),
          GoRoute(
            path: '/settings/about',
            name: 'settings_about',
            builder: (context, state) => const AboutTeamEditor(),
            redirect: (context, state) {
              final user = authState.user;
              if (user == null) return '/login';
              // Only salon owners and salon managers (and higher roles) may edit the About/Team section.
              final allowed = [UserRole.salonOwner, UserRole.salonManager, UserRole.owner, UserRole.platformAdmin];
              return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
            },
          ),
          GoRoute(
            path: '/settings/gallery',
            name: 'settings_gallery',
            builder: (context, state) => const SalonGalleryEditor(),
            redirect: (context, state) {
              final user = authState.user;
              if (user == null) return '/login';
              // Only salon owners and salon managers (and higher roles) may edit the gallery.
              final allowed = [UserRole.salonOwner, UserRole.salonManager, UserRole.owner, UserRole.platformAdmin];
              return RBAC.hasAnyRole(user.role, allowed) ? null : '/home';
            },
          ),
        ],
      ),
    ],
  );
});
