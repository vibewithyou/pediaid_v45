class Env {
  static const String apiBaseUrl = 'https://api.salonmanager.example/api/v1';
  static const String apiTimeout = '30000';
  static const bool isProduction = false;
  
  // TODO: Replace with actual Laravel API URL when backend is ready
  static const bool useMockData = true;
}
