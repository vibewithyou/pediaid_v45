import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';

/// A horizontal stepper widget that follows the luxury design language.
///
/// Displays a series of numbered circles connected by lines. The current
/// step is filled with the primary colour (gold/champagne), completed
/// steps are also filled, and upcoming steps are outlined. The connecting
/// lines are coloured based on whether the preceding step is completed.
class LuxuryStepper extends StatelessWidget {
  /// Zero‑based index of the current step.
  final int currentStep;

  /// Total number of steps in the wizard.
  final int totalSteps;

  const LuxuryStepper({
    required this.currentStep,
    required this.totalSteps,
    Key? key,
  })  : assert(totalSteps > 0),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.colorScheme.primary;
    final onPrimary = theme.colorScheme.onPrimary;

    // Build a list of widgets representing circles and connecting lines.
    final items = <Widget>[];
    for (var i = 0; i < totalSteps; i++) {
      final isCompleted = i < currentStep;
      final isActive = i == currentStep;
      items.add(Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: (isCompleted || isActive) ? primary : Colors.transparent,
          border: Border.all(color: primary, width: 2),
        ),
        child: Center(
          child: Text(
            '${i + 1}',
            style: theme.textTheme.labelMedium?.copyWith(
              color: (isCompleted || isActive) ? onPrimary : primary,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ));
      // Add a connecting line except after the last item
      if (i < totalSteps - 1) {
        final lineCompleted = i < currentStep;
        items.add(Expanded(
          child: Container(
            height: 2,
            color: lineCompleted ? primary : AppColors.mediumGrey,
          ),
        ));
      }
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: items,
      ),
    );
  }
}