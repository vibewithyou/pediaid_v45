import 'package:flutter/material.dart';
import 'package:salonvault/core/theme/app_theme.dart';

/// A custom button that reflects the luxury styling of SalonManager.
///
/// This widget renders a rounded rectangle with a gold border. When
/// [filled] is true the button is filled with the primary colour (gold
/// in dark mode, champagne in light mode). Otherwise only the outline
/// is coloured and the background is transparent. The text colour is
/// chosen automatically based on the [filled] state.
class LuxuryButton extends StatefulWidget {
  /// The text label of the button. Ignored if [child] is provided.
  final String? label;

  /// A custom child widget to display inside the button. If provided
  /// [label] will be ignored. Useful for including loaders or icons.
  final Widget? child;

  final VoidCallback? onPressed;
  final bool filled;
  final EdgeInsetsGeometry padding;

  const LuxuryButton({
    this.label,
    this.child,
    required this.onPressed,
    this.filled = true,
    this.padding = const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
    super.key,
  }) : assert(label != null || child != null, 'Either label or child must be provided');
  @override
  State<LuxuryButton> createState() => _LuxuryButtonState();
}

class _LuxuryButtonState extends State<LuxuryButton> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.colorScheme.primary;
    final onPrimary = theme.colorScheme.onPrimary;
    // Wrap the entire button in a Semantics widget so that assistive
    // technologies can properly announce it as a button. The label
    // defaults to the provided text when [label] is not null. If a
    // custom child is supplied instead of a label, fall back to a
    // generic description. This improves accessibility for screen
    // readers and other ATs.
    return Semantics(
      button: true,
      enabled: widget.onPressed != null,
      label: widget.label ?? 'action button',
      child: MouseRegion(
        onEnter: (_) => setState(() => _hovering = true),
        onExit: (_) => setState(() => _hovering = false),
        child: AnimatedScale(
          scale: _hovering ? 1.02 : 1.0,
          duration: const Duration(milliseconds: 150),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            curve: Curves.easeOut,
            decoration: BoxDecoration(
              color: widget.filled ? primary : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: primary, width: 1.5),
              boxShadow: _hovering
                  ? [
                      BoxShadow(
                        color: primary.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ]
                  : [],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: widget.onPressed,
                child: Container(
                  padding: widget.padding,
                  alignment: Alignment.center,
                  child: widget.child ??
                      Text(
                        widget.label!,
                        style: theme.textTheme.labelLarge?.copyWith(
                          color: widget.filled ? onPrimary : primary,
                          letterSpacing: 1.1,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}