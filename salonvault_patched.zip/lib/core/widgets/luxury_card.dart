import 'package:flutter/material.dart';

/// A reusable card widget following the luxury design language.
///
/// It supports an optional leading icon or image, a title and an optional
/// subtitle. The card has rounded corners, a subtle shadow and uses the
/// surface colour of the current theme.
class LuxuryCard extends StatefulWidget {
  final Widget? leading;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  const LuxuryCard({
    this.leading,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
    super.key,
  });

  @override
  State<LuxuryCard> createState() => _LuxuryCardState();
}

class _LuxuryCardState extends State<LuxuryCard> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Semantics(
      button: widget.onTap != null,
      // Provide a descriptive label combining the title and subtitle if present.
      label: widget.subtitle != null ? '${widget.title}, ${widget.subtitle}' : widget.title,
      child: MouseRegion(
        onEnter: (_) => setState(() => _hovering = true),
        onExit: (_) => setState(() => _hovering = false),
        child: AnimatedScale(
          scale: _hovering ? 1.02 : 1.0,
          duration: const Duration(milliseconds: 150),
          child: InkWell(
            onTap: widget.onTap,
            child: Container(
              decoration: BoxDecoration(
                color: theme.cardTheme.color,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: theme.brightness == Brightness.dark
                        ? theme.colorScheme.primary.withOpacity(_hovering ? 0.3 : 0.2)
                        : Colors.black.withOpacity(_hovering ? 0.25 : 0.15),
                    blurRadius: _hovering ? 10 : 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.leading != null) ...[
                    Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: SizedBox(width: 32, height: 32, child: widget.leading),
                    ),
                  ],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.title,
                          style: theme.textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (widget.subtitle != null) ...[
                          const SizedBox(height: 4),
                          Text(
                            widget.subtitle!,
                            style: theme.textTheme.bodyMedium,
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (widget.trailing != null) ...[
                    Padding(
                      padding: const EdgeInsets.only(left: 16.0),
                      child: widget.trailing!,
                    )
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}