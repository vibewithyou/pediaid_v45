import 'package:flutter/material.dart';

/// A chip styled according to the luxury design language.
///
/// When [selected] is true the chip is filled with the primary
/// colour; otherwise only a border is visible. It uses a subtle
/// animation for state changes. Use [onSelected] to toggle
/// selection.
class LuxuryChip extends StatefulWidget {
  final String label;
  final bool selected;
  final ValueChanged<bool> onSelected;

  const LuxuryChip({
    required this.label,
    required this.selected,
    required this.onSelected,
    Key? key,
  }) : super(key: key);

  @override
  State<LuxuryChip> createState() => _LuxuryChipState();
}

class _LuxuryChipState extends State<LuxuryChip> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.colorScheme.primary;
    final onPrimary = theme.colorScheme.onPrimary;
    return MouseRegion(
      onEnter: (_) => setState(() => _hovering = true),
      onExit: (_) => setState(() => _hovering = false),
      child: AnimatedScale(
        scale: _hovering ? 1.05 : 1.0,
        duration: const Duration(milliseconds: 150),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
          decoration: BoxDecoration(
            color: widget.selected ? primary : Colors.transparent,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: primary, width: 1.0),
            boxShadow: _hovering
                ? [
                    BoxShadow(
                      color: primary.withOpacity(0.3),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    )
                  ]
                : [],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: InkWell(
            borderRadius: BorderRadius.circular(24),
            onTap: () => widget.onSelected(!widget.selected),
            child: Text(
              widget.label,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: widget.selected ? onPrimary : primary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }
}