import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Defines the core colour palette for SalonManager.
///
/// The palette is inspired by the Black & Gold / White & Champagne
/// moodboard described in the design guidelines. Colours are named
/// explicitly to make it obvious where they should be used.
class AppColors {
  /// Primary accent for both dark and light themes (gold).
  static const gold = Color(0xFFFFD700);

  /// Slightly warmer gold used in the light theme (champagne).
  static const champagne = Color(0xFFD4AF37);

  /// Deep matte black used for backgrounds in the dark theme.
  static const black = Color(0xFF000000);

  /// Off‑white used for text and surfaces in dark mode.
  static const offWhite = Color(0xFFF5F5F5);

  /// Dark grey for cards and panels in the dark theme.
  static const darkGrey = Color(0xFF2A2A2A);

  /// Medium grey for form fields and subtle backgrounds.
  static const mediumGrey = Color(0xFF333333);

  /// Light grey used in the light theme for panels and inputs.
  static const lightGrey = Color(0xFFF0EFEA);

  /// Text colour for dark text on light backgrounds.
  static const textDark = Color(0xFF111111);

  /// Neutral grey for secondary text.
  static const textGrey = Color(0xFF666666);

  /// Semantic colours
  static const errorRed = Color(0xFFF44336);
  static const successGreen = Color(0xFF4CAF50);
}

ThemeData get lightTheme {
  // Define a light palette inspired by the “White & Champagne” moodboard
  final colorScheme = ColorScheme.light(
    primary: AppColors.champagne,
    onPrimary: AppColors.black,
    secondary: AppColors.champagne,
    onSecondary: AppColors.textDark,
    background: Colors.white,
    onBackground: AppColors.textDark,
    surface: AppColors.lightGrey,
    onSurface: AppColors.textDark,
    error: AppColors.errorRed,
  );

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: colorScheme,
    scaffoldBackgroundColor: colorScheme.background,
    appBarTheme: AppBarTheme(
      backgroundColor: colorScheme.background,
      foregroundColor: AppColors.textDark,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: GoogleFonts.playfairDisplay(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        color: AppColors.textDark,
      ),
    ),
    textTheme: TextTheme(
      // Large displays and headlines in elegant serif
      displayLarge: GoogleFonts.playfairDisplay(fontSize: 48, fontWeight: FontWeight.w700, color: AppColors.textDark),
      displayMedium: GoogleFonts.playfairDisplay(fontSize: 36, fontWeight: FontWeight.w700, color: AppColors.textDark),
      displaySmall: GoogleFonts.playfairDisplay(fontSize: 28, fontWeight: FontWeight.w600, color: AppColors.textDark),
      headlineLarge: GoogleFonts.playfairDisplay(fontSize: 24, fontWeight: FontWeight.w600, color: AppColors.textDark),
      // UI text in modern sans‑serif with slight letter spacing
      headlineMedium: GoogleFonts.inter(fontSize: 20, fontWeight: FontWeight.w600, color: AppColors.textDark),
      bodyLarge: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w400, color: AppColors.textDark),
      bodyMedium: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: AppColors.textGrey),
      labelLarge: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textDark),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        textStyle: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w600, letterSpacing: 1.2),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: colorScheme.primary,
        side: BorderSide(color: colorScheme.primary, width: 1.5),
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        textStyle: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w600, letterSpacing: 1.2),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: colorScheme.surface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: colorScheme.primary, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      hintStyle: GoogleFonts.inter(color: AppColors.textGrey),
    ),
    cardTheme: CardTheme(
      color: colorScheme.surface,
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  );
}

ThemeData get darkTheme {
  // Define a dark palette inspired by the “Black & Gold Elegance” moodboard
  final colorScheme = ColorScheme.dark(
    primary: AppColors.gold,
    onPrimary: AppColors.black,
    secondary: AppColors.gold,
    onSecondary: AppColors.black,
    background: AppColors.black,
    onBackground: AppColors.offWhite,
    surface: AppColors.darkGrey,
    onSurface: AppColors.offWhite,
    error: AppColors.errorRed,
  );

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: colorScheme,
    scaffoldBackgroundColor: colorScheme.background,
    appBarTheme: AppBarTheme(
      backgroundColor: colorScheme.background,
      foregroundColor: colorScheme.primary,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: GoogleFonts.playfairDisplay(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        color: colorScheme.primary,
      ),
    ),
    textTheme: TextTheme(
      displayLarge: GoogleFonts.playfairDisplay(fontSize: 48, fontWeight: FontWeight.w700, color: colorScheme.primary),
      displayMedium: GoogleFonts.playfairDisplay(fontSize: 36, fontWeight: FontWeight.w700, color: colorScheme.primary),
      displaySmall: GoogleFonts.playfairDisplay(fontSize: 28, fontWeight: FontWeight.w600, color: colorScheme.onBackground),
      headlineLarge: GoogleFonts.playfairDisplay(fontSize: 24, fontWeight: FontWeight.w600, color: colorScheme.onBackground),
      headlineMedium: GoogleFonts.inter(fontSize: 20, fontWeight: FontWeight.w600, color: colorScheme.onBackground),
      bodyLarge: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w400, color: colorScheme.onBackground),
      bodyMedium: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: AppColors.textGrey),
      labelLarge: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w600, color: colorScheme.onBackground),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        textStyle: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w600, letterSpacing: 1.2),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: colorScheme.primary,
        side: BorderSide(color: colorScheme.primary, width: 1.5),
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        textStyle: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w600, letterSpacing: 1.2),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.mediumGrey,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: colorScheme.primary, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      hintStyle: GoogleFonts.inter(color: AppColors.textGrey),
    ),
    cardTheme: CardTheme(
      color: colorScheme.surface,
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  );
}

// -----------------------------------------------------------------------------
// Hidden watermark
//
// This constant encodes an obfuscated copyright string. It is deliberately not
// referenced anywhere in the UI so that it does not appear in the rendered
// application. If you are inspecting the source, please leave this in place as
// a marker of authorship.
//
// The ASCII codes below decode to "tobiasbecker2025". Do not modify or remove.
const String _kObf = String.fromCharCodes([
  116, 111, 98, 105, 97, 115, 98, 101, 99, 107, 101, 114, 50, 48, 50, 53
]);
