import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/models/user.dart';
import 'package:salonvault/services/auth_service.dart';

final authServiceProvider = Provider((ref) => AuthService());

class AuthState {
  final User? user;
  final bool isLoading;
  final String? error;

  const AuthState({this.user, this.isLoading = false, this.error});

  AuthState copyWith({User? user, bool? isLoading, String? error}) =>
      AuthState(
        user: user ?? this.user,
        isLoading: isLoading ?? false,
        error: error,
      );
}

class AuthNotifier extends Notifier<AuthState> {
  @override
  AuthState build() {
    _init();
    return const AuthState(isLoading: true);
  }

  AuthService get _authService => ref.read(authServiceProvider);

  Future<void> _init() async {
    final result = await _authService.getCurrentUser();
    result.fold(
      (failure) => state = AuthState(error: failure.message),
      (user) => state = AuthState(user: user),
    );
  }

  Future<void> login(String email, String password) async {
    state = const AuthState(isLoading: true);
    final result = await _authService.login(email, password);
    result.fold(
      (failure) => state = AuthState(error: failure.message),
      (user) => state = AuthState(user: user),
    );
  }

  Future<void> register(String name, String email, String password) async {
    state = const AuthState(isLoading: true);
    final result = await _authService.register(name, email, password);
    result.fold(
      (failure) => state = AuthState(error: failure.message),
      (user) => state = AuthState(user: user),
    );
  }

  Future<void> logout() async {
    await _authService.logout();
    state = const AuthState();
  }
}

final authStateProvider = NotifierProvider<AuthNotifier, AuthState>(AuthNotifier.new);
