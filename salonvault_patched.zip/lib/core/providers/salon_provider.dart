import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/models/salon.dart';
import 'package:salonvault/models/service.dart';
import 'package:salonvault/models/stylist.dart';
import 'package:salonvault/services/salon_service.dart';

final salonServiceProvider = Provider((ref) => SalonServiceAPI());

final salonsProvider = FutureProvider<List<Salon>>((ref) async {
  final service = ref.read(salonServiceProvider);
  final result = await service.getAllSalons();
  return result.fold(
    (failure) => throw Exception(failure.message),
    (salons) => salons,
  );
});

final salonDetailProvider = FutureProvider.family<Salon, String>((ref, salonId) async {
  final service = ref.read(salonServiceProvider);
  final result = await service.getSalonById(salonId);
  return result.fold(
    (failure) => throw Exception(failure.message),
    (salon) => salon,
  );
});

final salonServicesProvider = FutureProvider.family<List<SalonService>, String>((ref, salonId) async {
  final service = ref.read(salonServiceProvider);
  final result = await service.getServicesBySalon(salonId);
  return result.fold(
    (failure) => throw Exception(failure.message),
    (services) => services,
  );
});

final salonStylistsProvider = FutureProvider.family<List<Stylist>, String>((ref, salonId) async {
  final service = ref.read(salonServiceProvider);
  final result = await service.getStylistsBySalon(salonId);
  return result.fold(
    (failure) => throw Exception(failure.message),
    (stylists) => stylists,
  );
});

class SelectedSalonNotifier extends Notifier<String?> {
  @override
  String? build() => null;
  
  void select(String? salonId) => state = salonId;
}

final selectedSalonProvider = NotifierProvider<SelectedSalonNotifier, String?>(SelectedSalonNotifier.new);
