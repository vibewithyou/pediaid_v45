import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/models/loyalty_transaction.dart';
import 'package:salonvault/services/loyalty_service.dart';

final loyaltyServiceProvider = Provider((ref) => LoyaltyService());

final userPointsProvider = FutureProvider.family<int, String>((ref, userId) async {
  final service = ref.read(loyaltyServiceProvider);
  final result = await service.getUserPoints(userId);
  return result.fold(
    (failure) => throw Exception(failure.message),
    (points) => points,
  );
});

final userTransactionsProvider = FutureProvider.family<List<LoyaltyTransaction>, String>((ref, userId) async {
  final service = ref.read(loyaltyServiceProvider);
  final result = await service.getUserTransactions(userId);
  return result.fold(
    (failure) => throw Exception(failure.message),
    (transactions) => transactions,
  );
});
