import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/models/booking.dart';
import 'package:salonvault/services/booking_service.dart';

final bookingServiceProvider = Provider((ref) => BookingService());

class BookingWizardState {
  final int currentStep;
  final String? salonId;
  final String? serviceId;
  final String? stylistId;
  final DateTime? selectedSlot;
  final String? notes;
  final List<String> images;

  BookingWizardState({
    this.currentStep = 0,
    this.salonId,
    this.serviceId,
    this.stylistId,
    this.selectedSlot,
    this.notes,
    this.images = const [],
  });

  BookingWizardState copyWith({
    int? currentStep,
    String? salonId,
    String? serviceId,
    String? stylistId,
    DateTime? selectedSlot,
    String? notes,
    List<String>? images,
  }) => BookingWizardState(
    currentStep: currentStep ?? this.currentStep,
    salonId: salonId ?? this.salonId,
    serviceId: serviceId ?? this.serviceId,
    stylistId: stylistId ?? this.stylistId,
    selectedSlot: selectedSlot ?? this.selectedSlot,
    notes: notes ?? this.notes,
    images: images ?? this.images,
  );
}

class BookingWizardNotifier extends Notifier<BookingWizardState> {
  @override
  BookingWizardState build() => BookingWizardState();

  void nextStep() {
    if (state.currentStep < 4) {
      state = state.copyWith(currentStep: state.currentStep + 1);
    }
  }

  void previousStep() {
    if (state.currentStep > 0) {
      state = state.copyWith(currentStep: state.currentStep - 1);
    }
  }

  void setService(String serviceId) {
    state = state.copyWith(serviceId: serviceId);
  }

  void setStylist(String? stylistId) {
    state = state.copyWith(stylistId: stylistId);
  }

  void setSlot(DateTime slot) {
    state = state.copyWith(selectedSlot: slot);
  }

  void setNotes(String notes) {
    state = state.copyWith(notes: notes);
  }

  void addImage(String imagePath) {
    if (state.images.length < 5) {
      state = state.copyWith(images: [...state.images, imagePath]);
    }
  }

  void removeImage(String imagePath) {
    state = state.copyWith(
      images: state.images.where((img) => img != imagePath).toList(),
    );
  }

  void reset() {
    state = BookingWizardState();
  }
}

final bookingWizardProvider = NotifierProvider<BookingWizardNotifier, BookingWizardState>(BookingWizardNotifier.new);
