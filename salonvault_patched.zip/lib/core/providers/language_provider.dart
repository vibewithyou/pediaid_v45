import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Manages the current locale of the app and persists it using SharedPreferences.
///
/// On first build, the notifier attempts to load a previously saved
/// language code from SharedPreferences. If none exists, it defaults
/// to German (`de`). The locale can be changed by calling
/// [setLocale], which updates both the provider state and the
/// persisted preference.
class LocaleNotifier extends Notifier<Locale> {
  @override
  Locale build() {
    // Default to German until loaded from preferences.
    _loadLocale();
    return const Locale('de');
  }

  Future<void> _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString('locale') ?? 'de';
    state = Locale(code);
  }

  Future<void> setLocale(Locale locale) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('locale', locale.languageCode);
    state = locale;
  }
}

/// Provider that exposes the current [Locale] used in the app and allows
/// updating it through its [LocaleNotifier].
final localeProvider = NotifierProvider<LocaleNotifier, Locale>(LocaleNotifier.new);