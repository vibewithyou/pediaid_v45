class RescheduleOption {
  final DateTime slot;
  final String label;
  final String? reason; // optional reason or hint

  const RescheduleOption({required this.slot, required this.label, this.reason});
}
