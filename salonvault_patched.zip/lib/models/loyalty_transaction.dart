class LoyaltyTransaction {
  final String id;
  final String userId;
  final String salonId;
  final int points;
  final String description;
  final DateTime date;
  final DateTime createdAt;
  final DateTime updatedAt;

  const LoyaltyTransaction({
    required this.id,
    required this.userId,
    required this.salonId,
    required this.points,
    required this.description,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
  });

  factory LoyaltyTransaction.fromJson(Map<String, dynamic> json) => LoyaltyTransaction(
    id: json['id'] as String,
    userId: json['user_id'] as String,
    salonId: json['salon_id'] as String,
    points: json['points'] as int,
    description: json['description'] as String,
    date: DateTime.parse(json['date'] as String),
    createdAt: DateTime.parse(json['created_at'] as String),
    updatedAt: DateTime.parse(json['updated_at'] as String),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'user_id': userId,
    'salon_id': salonId,
    'points': points,
    'description': description,
    'date': date.toIso8601String(),
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  LoyaltyTransaction copyWith({
    String? id,
    String? userId,
    String? salonId,
    int? points,
    String? description,
    DateTime? date,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => LoyaltyTransaction(
    id: id ?? this.id,
    userId: userId ?? this.userId,
    salonId: salonId ?? this.salonId,
    points: points ?? this.points,
    description: description ?? this.description,
    date: date ?? this.date,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
