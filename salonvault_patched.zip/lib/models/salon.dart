class Salon {
  final String id;
  final String name;
  final String address;
  final double lat;
  final double lng;
  final double rating;
  final int reviewCount;
  final String? description;
  final List<String> images;
  final String? phone;
  final String? email;
  final Map<String, String>? openingHours;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Salon({
    required this.id,
    required this.name,
    required this.address,
    required this.lat,
    required this.lng,
    required this.rating,
    required this.reviewCount,
    this.description,
    required this.images,
    this.phone,
    this.email,
    this.openingHours,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Salon.fromJson(Map<String, dynamic> json) => Salon(
    id: json['id'] as String,
    name: json['name'] as String,
    address: json['address'] as String,
    lat: (json['lat'] as num).toDouble(),
    lng: (json['lng'] as num).toDouble(),
    rating: (json['rating'] as num).toDouble(),
    reviewCount: json['review_count'] as int,
    description: json['description'] as String?,
    images: (json['images'] as List).cast<String>(),
    phone: json['phone'] as String?,
    email: json['email'] as String?,
    openingHours: json['opening_hours'] != null 
      ? Map<String, String>.from(json['opening_hours']) 
      : null,
    createdAt: DateTime.parse(json['created_at'] as String),
    updatedAt: DateTime.parse(json['updated_at'] as String),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'address': address,
    'lat': lat,
    'lng': lng,
    'rating': rating,
    'review_count': reviewCount,
    'description': description,
    'images': images,
    'phone': phone,
    'email': email,
    'opening_hours': openingHours,
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  Salon copyWith({
    String? id,
    String? name,
    String? address,
    double? lat,
    double? lng,
    double? rating,
    int? reviewCount,
    String? description,
    List<String>? images,
    String? phone,
    String? email,
    Map<String, String>? openingHours,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => Salon(
    id: id ?? this.id,
    name: name ?? this.name,
    address: address ?? this.address,
    lat: lat ?? this.lat,
    lng: lng ?? this.lng,
    rating: rating ?? this.rating,
    reviewCount: reviewCount ?? this.reviewCount,
    description: description ?? this.description,
    images: images ?? this.images,
    phone: phone ?? this.phone,
    email: email ?? this.email,
    openingHours: openingHours ?? this.openingHours,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
