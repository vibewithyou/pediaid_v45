// Extended to support management flows
// TODO(API): Align enum values with backend status strings
enum BookingStatus {
  pending,
  confirmed,
  cancelled,
  completed,
  declined,
  rescheduleRequested,
}

class Booking {
  final String id;
  final String userId;
  final String salonId;
  final String serviceId;
  final String? stylistId;
  final DateTime slot;
  final String? notes;
  final List<String> images;
  final BookingStatus status;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Booking({
    required this.id,
    required this.userId,
    required this.salonId,
    required this.serviceId,
    this.stylistId,
    required this.slot,
    this.notes,
    required this.images,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
    id: json['id'] as String,
    userId: json['user_id'] as String,
    salonId: json['salon_id'] as String,
    serviceId: json['service_id'] as String,
    stylistId: json['stylist_id'] as String?,
    slot: DateTime.parse(json['slot'] as String),
    notes: json['notes'] as String?,
    images: (json['images'] as List).cast<String>(),
    status: BookingStatus.values.firstWhere((e) => e.name == json['status']),
    createdAt: DateTime.parse(json['created_at'] as String),
    updatedAt: DateTime.parse(json['updated_at'] as String),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'user_id': userId,
    'salon_id': salonId,
    'service_id': serviceId,
    'stylist_id': stylistId,
    'slot': slot.toIso8601String(),
    'notes': notes,
    'images': images,
    'status': status.name,
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  Booking copyWith({
    String? id,
    String? userId,
    String? salonId,
    String? serviceId,
    String? stylistId,
    DateTime? slot,
    String? notes,
    List<String>? images,
    BookingStatus? status,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => Booking(
    id: id ?? this.id,
    userId: userId ?? this.userId,
    salonId: salonId ?? this.salonId,
    serviceId: serviceId ?? this.serviceId,
    stylistId: stylistId ?? this.stylistId,
    slot: slot ?? this.slot,
    notes: notes ?? this.notes,
    images: images ?? this.images,
    status: status ?? this.status,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
