class Stylist {
  final String id;
  final String salonId;
  final String userId;
  final String name;
  final String? avatar;
  final String? bio;
  final List<String> specialties;
  final double rating;
  final int reviewCount;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Stylist({
    required this.id,
    required this.salonId,
    required this.userId,
    required this.name,
    this.avatar,
    this.bio,
    required this.specialties,
    required this.rating,
    required this.reviewCount,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Stylist.fromJson(Map<String, dynamic> json) => Stylist(
    id: json['id'] as String,
    salonId: json['salon_id'] as String,
    userId: json['user_id'] as String,
    name: json['name'] as String,
    avatar: json['avatar'] as String?,
    bio: json['bio'] as String?,
    specialties: (json['specialties'] as List).cast<String>(),
    rating: (json['rating'] as num).toDouble(),
    reviewCount: json['review_count'] as int,
    createdAt: DateTime.parse(json['created_at'] as String),
    updatedAt: DateTime.parse(json['updated_at'] as String),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'salon_id': salonId,
    'user_id': userId,
    'name': name,
    'avatar': avatar,
    'bio': bio,
    'specialties': specialties,
    'rating': rating,
    'review_count': reviewCount,
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  Stylist copyWith({
    String? id,
    String? salonId,
    String? userId,
    String? name,
    String? avatar,
    String? bio,
    List<String>? specialties,
    double? rating,
    int? reviewCount,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => Stylist(
    id: id ?? this.id,
    salonId: salonId ?? this.salonId,
    userId: userId ?? this.userId,
    name: name ?? this.name,
    avatar: avatar ?? this.avatar,
    bio: bio ?? this.bio,
    specialties: specialties ?? this.specialties,
    rating: rating ?? this.rating,
    reviewCount: reviewCount ?? this.reviewCount,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
