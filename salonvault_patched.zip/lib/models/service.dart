class SalonService {
  final String id;
  final String salonId;
  final String name;
  final String? description;
  final int durationMinutes;
  final double price;
  final String? category;
  final DateTime createdAt;
  final DateTime updatedAt;

  const SalonService({
    required this.id,
    required this.salonId,
    required this.name,
    this.description,
    required this.durationMinutes,
    required this.price,
    this.category,
    required this.createdAt,
    required this.updatedAt,
  });

  factory SalonService.fromJson(Map<String, dynamic> json) => SalonService(
    id: json['id'] as String,
    salonId: json['salon_id'] as String,
    name: json['name'] as String,
    description: json['description'] as String?,
    durationMinutes: json['duration_minutes'] as int,
    price: (json['price'] as num).toDouble(),
    category: json['category'] as String?,
    createdAt: DateTime.parse(json['created_at'] as String),
    updatedAt: DateTime.parse(json['updated_at'] as String),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'salon_id': salonId,
    'name': name,
    'description': description,
    'duration_minutes': durationMinutes,
    'price': price,
    'category': category,
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  SalonService copyWith({
    String? id,
    String? salonId,
    String? name,
    String? description,
    int? durationMinutes,
    double? price,
    String? category,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => SalonService(
    id: id ?? this.id,
    salonId: salonId ?? this.salonId,
    name: name ?? this.name,
    description: description ?? this.description,
    durationMinutes: durationMinutes ?? this.durationMinutes,
    price: price ?? this.price,
    category: category ?? this.category,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
