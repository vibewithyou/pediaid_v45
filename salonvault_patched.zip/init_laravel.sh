#!/bin/bash

# This script builds and starts the application stack.
# It will automatically create a Laravel application in a Docker volume,
# run migrations and build the Flutter web frontend.

set -e

COMPOSE_FILE=docker/docker-compose.yml

echo "Building Docker images..."
docker compose -f $COMPOSE_FILE build

echo "Starting MySQL and PHP-FPM containers..."
docker compose -f $COMPOSE_FILE up -d mysql backend

# Wait for MySQL to accept connections
echo "Waiting for MySQL to accept connections..."
until docker exec salonvault-mysql mysqladmin ping -h "mysql" --silent; do
  sleep 2
done

# Create Laravel project if the volume is empty
LARAVEL_MOUNTPOINT=$(docker volume inspect laravel_app -f '{{ .Mountpoint }}')
if [ ! -f "$LARAVEL_MOUNTPOINT/artisan" ]; then
  echo "Creating new Laravel application..."
  docker run --rm -v laravel_app:/var/www/html composer create-project --prefer-dist laravel/laravel .
fi

echo "Running Laravel key generation and migrations..."
docker compose -f $COMPOSE_FILE exec backend php artisan key:generate --force
docker compose -f $COMPOSE_FILE exec backend php artisan migrate --force

echo "Building Flutter web frontend..."
docker compose -f $COMPOSE_FILE up -d frontend

echo "Starting NGINX and phpMyAdmin..."
docker compose -f $COMPOSE_FILE up -d nginx-backend phpmyadmin

echo "All services are up and running."
