# Docker Setup for SalonVault

This guide explains how to build and run the Flutter frontend and a Laravel backend using Docker.

## Prerequisites

* [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running.

## Running the Application

All of the Docker configuration lives in the `docker/` directory and an initialization script in the project root.

1. **Build the images**. From the root of the project run:

   ```bash
   docker compose -f docker/docker-compose.yml build
   ```

2. **Initialize Laravel and start services**. The provided script builds the Flutter web frontend, creates a new Laravel project in a volume if one doesn’t already exist, runs database migrations and starts all services (MySQL, PHP‑FPM, NGINX, phpMyAdmin and the Flutter web server):

   ```bash
   bash ./init_laravel.sh
   ```

   The first run will take a little while as it installs dependencies and creates a new Laravel application.

3. **Access your application**:

   * Flutter frontend: open **http://localhost:8080** in your browser.
   * Laravel backend (served via NGINX): **http://localhost:8000**
   * phpMyAdmin: **http://localhost:8081** (login with user `laravel` and password `laravel`).

4. **Stop the services**:

   To stop all containers run:

   ```bash
   docker compose -f docker/docker-compose.yml down
   ```

## Customising Laravel

The Laravel code lives inside a Docker volume named `laravel_app` created on first run. To edit the backend locally:

1. Copy the contents of the volume to a directory on your host:

   ```bash
   docker run --rm -v laravel_app:/src -v $(pwd)/backend_local:/dest alpine sh -c "cp -r /src/* /dest"
   ```

2. In `docker/docker-compose.yml` change the volume for the backend service from `laravel_app` to `./backend_local:/var/www/html`. Rebuild and restart the backend container.

3. You can now edit Laravel code under `backend_local/` on your host and changes will reflect immediately.

## Connecting Flutter to Laravel

Configure your API base URL in your Flutter code to point at the backend, for example:

```dart
const apiBaseUrl = 'http://localhost:8000';
```

If you need cross‑origin requests, ensure the `HandleCors` middleware is enabled in Laravel (it is by default in recent versions).
