import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:salonvault/features/chat/data/chat_repository.dart';
import 'package:salonvault/features/chat/models/participant.dart';
import 'package:salonvault/features/chat/state/chat_state.dart';
import 'package:salonvault/features/chat/views/conversation_detail_screen.dart';

void main() {
  testWidgets('ConversationDetailScreen builds', (tester) async {
    final repo = MockChatRepository();
    late final String convId;
    () async {
      final c = await repo.createConversation(
        participants: const [
          Participant(id: 'u1', type: ChatActorType.user, displayName: 'Me'),
          Participant(id: 's1', type: ChatActorType.stylist, displayName: 'Anna'),
        ],
      );
      convId = c.id;
    }();

    await tester.pumpWidget(
      ProviderScope(
        overrides: [chatRepositoryProvider.overrideWithValue(repo), myChatKeyProvider.overrideWith((ref) => 'user:u1')],
        child: MaterialApp(home: ConversationDetailScreen(conversationId: convId)),
      ),
    );

    await tester.pump();
    expect(find.byType(ConversationDetailScreen), findsOneWidget);
  });
}
