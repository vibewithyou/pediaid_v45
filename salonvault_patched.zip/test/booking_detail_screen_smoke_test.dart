import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/booking/booking_detail_screen.dart';
import 'package:salonvault/features/booking/data/booking_repository.dart';
import 'package:salonvault/services/booking_service.dart';
import 'package:salonvault/core/providers/booking_provider.dart';

void main() {
  testWidgets('BookingDetailScreen renders status and actions', (tester) async {
    final svc = BookingService();
    final res = await svc.createBooking(
      userId: 'u1',
      salonId: 's1',
      serviceId: 'svc1',
      stylistId: 'sty1',
      slot: DateTime.now().add(const Duration(days: 2)),
    );
    final booking = res.data!;

    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          bookingServiceProvider.overrideWithValue(svc),
          bookingRepositoryProvider.overrideWith((ref) => BookingRepository(svc)),
        ],
        child: MaterialApp(home: BookingDetailScreen(bookingId: booking.id)),
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('Termin-Details'), findsOneWidget);
    expect(find.textContaining('Service'), findsOneWidget);
    expect(find.byIcon(Icons.schedule), findsOneWidget); // reschedule
    expect(find.byIcon(Icons.attachment), findsOneWidget); // attach
    expect(find.byIcon(Icons.chat), findsOneWidget); // chat
  });
}
