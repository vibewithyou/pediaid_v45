import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:salonvault/features/gallery_ai/views/gallery_hub_screen.dart';
import 'package:salonvault/features/gallery_ai/views/inspirations_screen.dart';

void main() {
  testWidgets('GalleryHubScreen builds', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: MaterialApp(home: GalleryHubScreen())));
    expect(find.text('Galerie'), findsOneWidget);
    // Tab labels exist
    expect(find.text('Öffentlich'), findsOneWidget);
    expect(find.text('Meine'), findsOneWidget);
  });

  testWidgets('InspirationsScreen builds', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: MaterialApp(home: InspirationsScreen())));
    expect(find.text('Inspirationen (KI)'), findsOneWidget);
  });
}
