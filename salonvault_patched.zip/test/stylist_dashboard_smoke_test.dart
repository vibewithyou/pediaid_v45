import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:salonvault/features/stylist_dashboard/views/stylist_dashboard_screen.dart';
import 'package:salonvault/features/stylist_dashboard/views/customer_quick_view.dart';

void main() {
  testWidgets('StylistDashboardScreen renders core sections', (tester) async {
    await tester.pumpWidget(const ProviderScope(
      child: MaterialApp(
        home: StylistDashboardScreen(),
      ),
    ));

    expect(find.byKey(const Key('stylist_dashboard_body')), findsOneWidget);
    expect(find.byKey(const Key('today_appointments_card')), findsOneWidget);
    expect(find.byKey(const Key('quick_actions_card')), findsOneWidget);
  });

  testWidgets('CustomerQuickView shows card after load', (tester) async {
    await tester.pumpWidget(const ProviderScope(
      child: MaterialApp(
        home: CustomerQuickView(customerId: 'c1'),
      ),
    ));

    // initial loading
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    // wait for async repo
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pumpAndSettle();

    expect(find.byKey(const Key('customer_mini_card')), findsOneWidget);
  });
}
