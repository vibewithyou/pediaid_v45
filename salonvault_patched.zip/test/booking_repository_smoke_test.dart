import 'package:flutter_test/flutter_test.dart';
import 'package:salonvault/models/booking.dart';
import 'package:salonvault/services/booking_service.dart';

void main() {
  test('BookingService management flows smoke', () async {
    final svc = BookingService();
    final createRes = await svc.createBooking(
      userId: 'u1',
      salonId: 's1',
      serviceId: 'svc1',
      stylistId: 'sty1',
      slot: DateTime.now().add(const Duration(days: 1)),
    );
    expect(createRes.isSuccess, true);
    final b = createRes.data!;
    expect(b.status, BookingStatus.pending);

    final confRes = await svc.confirmBooking(b.id);
    expect(confRes.isSuccess, true);
    expect(confRes.data!.status, BookingStatus.confirmed);

    final attachRes = await svc.attachMedia(b.id, ['m1', 'm2']);
    expect(attachRes.isSuccess, true);
    expect(attachRes.data!.images.length, 2);

    final optsRes = await svc.getRescheduleOptions(b.id);
    expect(optsRes.isSuccess, true);
    expect(optsRes.data!.isNotEmpty, true);

    final suggRes = await svc.suggestReschedule(b.id, optsRes.data!.first.slot);
    expect(suggRes.isSuccess, true);
    expect(suggRes.data!.status, BookingStatus.rescheduleRequested);

    final applyRes = await svc.applyReschedule(b.id, optsRes.data!.first.slot);
    expect(applyRes.isSuccess, true);
    expect(applyRes.data!.status, BookingStatus.confirmed);
  });
}
