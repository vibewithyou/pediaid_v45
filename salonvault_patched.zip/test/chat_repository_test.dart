import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:salonvault/features/chat/data/chat_repository.dart';
import 'package:salonvault/features/chat/models/attachment.dart';
import 'package:salonvault/features/chat/models/participant.dart';

void main() {
  test('MockChatRepository creates conversation and streams messages', () async {
    final repo = MockChatRepository();
    final me = const Participant(id: 'u1', type: ChatActorType.user, displayName: 'Me');
    final stylist = const Participant(id: 's1', type: ChatActorType.stylist, displayName: 'Anna');
    final conv = await repo.createConversation(participants: [me, stylist]);

    final messages = <int>[];
    final sub = repo.watchMessages(conv.id).listen((list) => messages.add(list.length));

    await repo.sendMessage(conversationId: conv.id, senderType: ChatActorType.user, senderId: 'u1', text: 'Hi');
    await Future<void>.delayed(const Duration(milliseconds: 10));

    expect(messages.isNotEmpty, true);
    expect(messages.last, 1);

    await sub.cancel();
  });
}
