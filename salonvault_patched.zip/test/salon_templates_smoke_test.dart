import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:salonvault/features/salon_templates/data/template_repository.dart';
import 'package:salonvault/features/salon_templates/entities.dart';
import 'package:salonvault/features/salon_templates/views/salon_branding_editor.dart';
import 'package:salonvault/features/salon_templates/views/salon_layout_editor.dart';

void main() {
  test('InMemoryTemplateRepository returns default template', () async {
    final repo = InMemoryTemplateRepository();
    final t = await repo.getTemplate('test-salon');
    expect(t.tokens.primary, const Color(0xFFFFD700));
    expect(t.blocks.isNotEmpty, true);
  });

  testWidgets('SalonBrandingEditor builds without selected salon', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: MaterialApp(home: SalonBrandingEditor())));
    expect(find.text('Branding'), findsOneWidget);
  });

  testWidgets('SalonLayoutEditor builds without selected salon', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: MaterialApp(home: SalonLayoutEditor())));
    expect(find.text('Layout'), findsOneWidget);
  });
}
